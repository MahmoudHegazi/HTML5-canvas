(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"RECOVER_RECOVER_exper_1_1_5_atlas_", frames: [[2690,2063,60,65],[2752,2063,59,63],[3176,2075,58,63],[0,1669,428,159],[2144,802,640,480],[1284,1271,640,480],[1284,1076,190,189],[2786,991,640,480],[3696,1698,305,220],[1502,789,640,480],[0,798,640,480],[642,798,640,480],[3428,991,640,480],[360,1830,59,70],[483,2061,58,68],[1405,1896,106,38],[422,2061,59,67],[3236,2075,58,62],[543,2061,62,63],[2813,2063,58,63],[430,1669,150,45],[3824,2055,149,87],[3956,967,61,12],[2144,789,76,11],[4075,654,17,14],[4075,670,17,14],[1131,1567,149,87],[3208,1879,129,49],[1781,1949,58,70],[4075,517,17,69],[2293,789,47,8],[2732,1284,47,87],[2222,789,69,8],[1860,1753,62,97],[1781,2050,162,154],[2449,1284,281,170],[2542,0,823,800],[3208,1962,283,111],[1502,0,1038,787],[1163,1753,416,141],[636,2019,279,104],[3687,1920,291,133],[2303,1943,304,116],[2345,1785,361,156],[1607,1949,172,166],[1100,1896,303,129],[3493,1962,172,166],[0,1988,267,114],[0,1830,358,156],[917,2019,166,167],[746,1720,415,155],[2786,802,430,168],[0,0,1500,796],[2878,2021,193,135],[430,1720,314,205],[0,1280,664,387],[3667,2055,155,122],[1945,2050,200,106],[1405,1949,200,169],[1581,1753,277,194],[360,1927,274,132],[1926,1284,521,365],[2956,1473,385,404],[1085,2027,224,114],[636,1927,86,70],[2609,1943,86,70],[2786,972,372,15],[2303,2061,385,35],[1284,798,188,276],[2708,1785,168,276],[1131,1280,134,130],[3977,291,85,205],[666,1280,463,438],[2449,1473,505,310],[3343,1473,351,330],[3343,1805,342,155],[2732,1373,47,87],[355,2061,65,126],[2878,1785,57,76],[1860,1895,286,153],[3218,802,127,169],[1926,1651,417,242],[2148,1895,153,241],[1163,1656,80,93],[4003,1698,86,144],[3977,498,96,155],[269,1988,84,144],[1311,2027,72,127],[1131,1412,88,153],[4003,1844,87,142],[3977,811,96,154],[3980,1988,88,137],[2345,1651,84,129],[3977,655,96,154],[3890,920,64,64],[3705,920,183,61],[746,1877,352,140],[3977,0,75,289],[3073,2021,101,101],[2878,1879,328,140],[4075,588,14,64],[1474,798,25,44],[3705,0,270,918],[3367,0,336,989],[3696,1473,349,223],[4075,412,14,103],[4054,0,42,99],[4064,203,19,102],[4064,307,18,103],[4054,101,36,100],[1221,1412,56,144]]}
];


// symbols:



(lib._1 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._32222 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._32313460_439147829890073_4611852169237233664_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._33063562_443189839485872_4791495228001353728_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._3349926 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib._33896722_446523232485866_2610207923934068736_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib._33990821_446960665775456_6534134141988896768_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib._33990841_446958909108965_6130106053058101248_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib._34012877_446523042485885_371141279532187648_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib._34038674_446523102485879_1476294467110567936_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib._34113001_446960302442159_7177812322180661248_n = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib._4 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.صيصيصي = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib._6 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib._7 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib._8 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib._9 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Image_0 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Image_1 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Image_2 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Image_3 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Image_4 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Image_5 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Image_6 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Image_7 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Mesh = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_0 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_1 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_2 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.arrow = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Back3 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Back4 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.backkk = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.backkk2 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.backkk23232pngcopy = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.backkk2sa = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.backkk3 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.backkk4 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.backkk44 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.backkk55 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.backkk6 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.backkk66 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.backkk7 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.backkk77 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.backkk8 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.backkk9 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.backkkdwdw = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.backkksda = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap107 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1235 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1236 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1238 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1239 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1240 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1241 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1244 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap158 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.expr_1_2_10 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_controll1pngcopy = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_controllsqsqq = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_controllsqsqss = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_tools٣١ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_tools٣٢ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_tools٣٤ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_tools٣٥ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_tools٣٦ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_tools٣٧pngcopy = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_Tools_cup0٢ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_Tools_cup0٣ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_Tools_cup0٨ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_Tools_cup٢١ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.Front = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.Front1١ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.Front2 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.Front4 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.Front3 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.Layer0 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.Layer0_1 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.Layer0copy = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.Layer1 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.Layer10 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.Layer2 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.Layer3 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.Layer4 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.Layer5 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.Layer6 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.Layer7 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.Layer8 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.Layer9 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.question = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.scor = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.sdsds = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.soop = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.star = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.start = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.tools0٥ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.tools0٦ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.tube0٢pngcopy = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.tube0٤ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.Untitled2 = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.Vlaby_board0٣ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.Vlaby_board0٤ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.Vlaby_board0٥ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.Vlaby_board0٦ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.Vlaby_board0٧ = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.Vlaby_board0peثn = function() {
	this.spriteSheet = ss["RECOVER_RECOVER_exper_1_1_5_atlas_"];
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk();
	this.instance.parent = this;
	this.instance.setTransform(-411.4,-399.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-411.4,-399.9,823,800);


(lib.Tween76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk();
	this.instance.parent = this;
	this.instance.setTransform(-411.4,-399.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-411.4,-399.9,823,800);


(lib.Tween65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk();
	this.instance.parent = this;
	this.instance.setTransform(-411.4,-399.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-411.4,-399.9,823,800);


(lib.Tween64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk();
	this.instance.parent = this;
	this.instance.setTransform(-411.4,-399.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-411.4,-399.9,823,800);


(lib.Tween51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.question();
	this.instance.parent = this;
	this.instance.setTransform(-20,-20,0.625,0.625);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-20,40,40);


(lib.Tween50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.question();
	this.instance.parent = this;
	this.instance.setTransform(-20,-20,0.625,0.625);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-20,40,40);


(lib.Tween43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk23232pngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-519,-387);

	this.instance_1 = new lib.backkk();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-387,-400);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-519,-400,1038,800);


(lib.Tween42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk23232pngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-519,-387);

	this.instance_1 = new lib.backkk();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-387,-400);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-519,-400,1038,800);


(lib.Tween41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.start();
	this.instance.parent = this;
	this.instance.setTransform(-164,-70);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-164,-70,328,140);


(lib.Tween40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.start();
	this.instance.parent = this;
	this.instance.setTransform(-164,-70);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-164,-70,328,140);


(lib.Tween39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.expr_1_2_10();
	this.instance.parent = this;
	this.instance.setTransform(-127.5,-133.8,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127.5,-133.8,255.1,267.7);


(lib.Tween38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.expr_1_2_10();
	this.instance.parent = this;
	this.instance.setTransform(-127.5,-133.8,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127.5,-133.8,255.1,267.7);


(lib.Tween35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("الدرس الثاني : القوى المصاحبة للحركة", "63px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 113;
	this.text.lineWidth = 1091;
	this.text.parent = this;
	this.text.setTransform(53.7,102.8,0.647,0.647);

	this.text_1 = new cjs.Text(" الوحدة الثانية : القوى والحركة", "63px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 113;
	this.text_1.lineWidth = 1047;
	this.text_1.parent = this;
	this.text_1.setTransform(53.7,176.1,0.647,0.647);

	this.text_2 = new cjs.Text("الفصل الدراسي الثاني", "63px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 113;
	this.text_2.lineWidth = 869;
	this.text_2.parent = this;
	this.text_2.setTransform(125.6,-25.5,0.647,0.647);

	this.text_3 = new cjs.Text("للصف الأول الأعدادي", "63px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 113;
	this.text_3.lineWidth = 876;
	this.text_3.parent = this;
	this.text_3.setTransform(123.2,-117.8,0.647,0.647);

	this.text_4 = new cjs.Text("انتقال السوائل ونفاذها عبر الأغشية المسامية", "64px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 115;
	this.text_4.lineWidth = 1332;
	this.text_4.parent = this;
	this.text_4.setTransform(0,-249.2,0.647,0.647);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-432,-250.5,864.1,501.1);


(lib.Tween34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("الدرس الثاني : القوى المصاحبة للحركة", "63px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 113;
	this.text.lineWidth = 1091;
	this.text.parent = this;
	this.text.setTransform(53.7,102.8,0.647,0.647);

	this.text_1 = new cjs.Text(" الوحدة الثانية : القوى والحركة", "63px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 113;
	this.text_1.lineWidth = 1047;
	this.text_1.parent = this;
	this.text_1.setTransform(53.7,176.1,0.647,0.647);

	this.text_2 = new cjs.Text("الفصل الدراسي الثاني", "63px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 113;
	this.text_2.lineWidth = 869;
	this.text_2.parent = this;
	this.text_2.setTransform(125.6,-25.5,0.647,0.647);

	this.text_3 = new cjs.Text("للصف الأول الأعدادي", "63px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 113;
	this.text_3.lineWidth = 876;
	this.text_3.parent = this;
	this.text_3.setTransform(123.2,-117.8,0.647,0.647);

	this.text_4 = new cjs.Text("انتقال السوائل ونفاذها عبر الأغشية المسامية", "64px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 115;
	this.text_4.lineWidth = 1332;
	this.text_4.parent = this;
	this.text_4.setTransform(0,-249.2,0.647,0.647);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-432,-250.5,864.1,501.1);


(lib.Tween33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk23232pngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-519,-387);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-519,-387,1038,787);


(lib.Tween32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk23232pngcopy();
	this.instance.parent = this;
	this.instance.setTransform(-519,-387);

	this.instance_1 = new lib.backkk();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-387,-400);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-519,-400,1038,800);


(lib.Tween31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.expr_1_2_10();
	this.instance.parent = this;
	this.instance.setTransform(-127.5,-133.8,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127.5,-133.8,255.1,267.7);


(lib.Tween30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.expr_1_2_10();
	this.instance.parent = this;
	this.instance.setTransform(-127.5,-133.8,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127.5,-133.8,255.1,267.7);


(lib.Tween27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Unit Two: Force and Motion", "63px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 113;
	this.text.lineWidth = 1091;
	this.text.parent = this;
	this.text.setTransform(42.7,85.7,0.647,0.647);

	this.text_1 = new cjs.Text("Lesson Two: Fundamental forces in nature", "63px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 113;
	this.text_1.lineWidth = 1191;
	this.text_1.parent = this;
	this.text_1.setTransform(13.2,159,0.647,0.647);

	this.text_2 = new cjs.Text("Second Term", "63px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 113;
	this.text_2.lineWidth = 869;
	this.text_2.parent = this;
	this.text_2.setTransform(114.6,-42.6,0.647,0.647);

	this.text_3 = new cjs.Text("Preparatory Stage - year 1", "63px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 113;
	this.text_3.lineWidth = 876;
	this.text_3.parent = this;
	this.text_3.setTransform(112.2,-134.9,0.647,0.647);

	this.text_4 = new cjs.Text("Fluid transport and penetration through porous membranes", "48px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 87;
	this.text_4.lineWidth = 1332;
	this.text_4.parent = this;
	this.text_4.setTransform(0,-253.3,0.647,0.647);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-432,-254.6,864.1,509.4);


(lib.Tween26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Unit Two: Force and Motion", "63px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 113;
	this.text.lineWidth = 1091;
	this.text.parent = this;
	this.text.setTransform(42.7,85.7,0.647,0.647);

	this.text_1 = new cjs.Text("Lesson Two: Fundamental forces in nature", "63px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 113;
	this.text_1.lineWidth = 1191;
	this.text_1.parent = this;
	this.text_1.setTransform(13.2,159,0.647,0.647);

	this.text_2 = new cjs.Text("Second Term", "63px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 113;
	this.text_2.lineWidth = 869;
	this.text_2.parent = this;
	this.text_2.setTransform(114.6,-42.6,0.647,0.647);

	this.text_3 = new cjs.Text("Preparatory Stage - year 1", "63px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 113;
	this.text_3.lineWidth = 876;
	this.text_3.parent = this;
	this.text_3.setTransform(112.2,-134.9,0.647,0.647);

	this.text_4 = new cjs.Text("Fluid transport and penetration through porous membranes", "48px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 87;
	this.text_4.lineWidth = 1332;
	this.text_4.parent = this;
	this.text_4.setTransform(0,-253.3,0.647,0.647);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-432,-254.6,864.1,509.4);


(lib.Tween22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.question();
	this.instance.parent = this;
	this.instance.setTransform(-72.5,-69.3,0.557,0.557);

	this.instance_1 = new lib.question();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-81.5,152.7,0.557,0.557);

	this.instance_2 = new lib.question();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-81.5,38.7,0.557,0.557);

	this.instance_3 = new lib.question();
	this.instance_3.parent = this;
	this.instance_3.setTransform(41.5,-188.3,0.625,0.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.5,-188.3,163,376.7);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.question();
	this.instance.parent = this;
	this.instance.setTransform(-72.5,-69.3,0.557,0.557);

	this.instance_1 = new lib.question();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-81.5,152.7,0.557,0.557);

	this.instance_2 = new lib.question();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-81.5,38.7,0.557,0.557);

	this.instance_3 = new lib.question();
	this.instance_3.parent = this;
	this.instance_3.setTransform(41.5,-188.3,0.625,0.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.5,-188.3,163,376.7);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.scor();
	this.instance.parent = this;
	this.instance.setTransform(-62.5,-20.8,0.683,0.683);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,-20.8,125.1,41.7);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-31,-48.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-48.5,62,97);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-31,-48.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-48.5,62,97);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-31,-48.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-48.5,62,97);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.scor();
	this.instance.parent = this;
	this.instance.setTransform(-62.5,-20.8,0.683,0.683);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,-20.8,125.1,41.7);


(lib.targ_sar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.star();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-34.5,0.684,0.684);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.targ_sar, new cjs.Rectangle(-34.5,-34.5,69.1,69.1), null);


(lib.Symbol83 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.start();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,328,140);


(lib.Symbol82copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,255,255,0.059)").s("rgba(0,255,255,0.059)").ss(2.8,1,1).dr(-660,-405,1320,810);
	this.shape.setTransform(664.3,409.3,1.007,1.01);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol82copy, new cjs.Rectangle(-1.4,-1.4,1331.4,821.3), null);


(lib.Symbol82 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,255,255,0.059)").s("rgba(0,255,255,0.059)").ss(2.8,1,1).dr(-660,-405,1320,810);
	this.shape.setTransform(664.3,409.3,1.007,1.01);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol82, new cjs.Rectangle(-1.4,-1.4,1331.4,821.3), null);


(lib.Symbol81 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.sdsds();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,352,140);


(lib.Symbol80copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk77();
	this.instance.parent = this;
	this.instance.setTransform(12,5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-3},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(12,5,267,114);


(lib.Symbol80 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk4();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-7},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,291,133);


(lib.Symbol68 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap158();
	this.instance.parent = this;
	this.instance.setTransform(-203.7,-142.7,0.782,0.782);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol68, new cjs.Rectangle(-203.7,-142.7,407.4,285.4), null);


(lib.Symbol67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.12,scaleY:1.12,x:-17,y:-7},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,283,111);


(lib.Symbol66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.08,scaleY:1.08,x:-11,y:-4},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,279,104);


(lib.Symbol65copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk9();
	this.instance.parent = this;
	this.instance.setTransform(267,0);

	this.instance_1 = new lib.backkk66();
	this.instance_1.parent = this;
	this.instance_1.setTransform(38,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1,scaleY:1,rotation:0,x:267,y:0}}]}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1.12,scaleY:1.12,rotation:21.2,x:297.2,y:-37.2}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(38,0,395,167);


(lib.Symbol65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk9();
	this.instance.parent = this;

	this.instance_1 = new lib.backkk8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(57,11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1,scaleY:1,rotation:0,x:0,y:0}}]}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1.12,scaleY:1.12,rotation:18.9,x:25.4,y:-35.1}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,415,167);


(lib.Symbol63copy9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(7,1,1).p("ADkjQInHGh");
	this.shape.setTransform(147.9,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(7,1,1).p("ADMi/ImXF/");
	this.shape_1.setTransform(-127.8,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_2
	this.instance = new lib._32222();
	this.instance.parent = this;
	this.instance.setTransform(-218,-78);

	this.instance_1 = new lib.backkksda();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-200,-83);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-218,-78,428,159);


(lib.Symbol63copy7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(7,1,1).p("ADGi0ImLFp");
	this.shape.setTransform(-128.4,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.instance = new lib.backkksda();
	this.instance.parent = this;
	this.instance.setTransform(-200,-83);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(7,1,1).p("AD2kuInrJd");
	this.shape_1.setTransform(-119.6,4.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-200,-83,430,168);


(lib.Symbol63copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(7,1,1).p("ADGi0ImLFp");
	this.shape.setTransform(-128.4,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3
	this.instance = new lib.backkkdwdw();
	this.instance.parent = this;
	this.instance.setTransform(-194,-75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-194,-75,415,155);


(lib.Symbol63copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(7,1,1).p("ADkjQInHGh");
	this.shape.setTransform(147.9,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(7,1,1).p("ADGi0ImLFp");
	this.shape_1.setTransform(-128.4,1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_2
	this.instance = new lib.backkk2sa();
	this.instance.parent = this;
	this.instance.setTransform(-210,-73);

	this.instance_1 = new lib.backkkdwdw();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-194,-75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-210,-73,416,141);


(lib.Symbol63copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk6();
	this.instance.parent = this;
	this.instance.setTransform(268,7);

	this.instance_1 = new lib.backkk44();
	this.instance_1.parent = this;
	this.instance_1.setTransform(38,31);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1,scaleY:1,x:268,y:7}}]}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1.205,scaleY:1.205,x:250,y:-10}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(38,7,402,166);


(lib.Symbol63copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk7();
	this.instance.parent = this;
	this.instance.setTransform(258,-8,1.105,1.105);

	this.instance_1 = new lib.backkk44();
	this.instance_1.parent = this;
	this.instance_1.setTransform(38,31);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1.105,scaleY:1.105,x:258,y:-8}}]}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:0.916,scaleY:0.916,x:270,y:8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(38,-8,410,183.4);


(lib.Symbol63copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk7();
	this.instance.parent = this;
	this.instance.setTransform(-10,-8,1.105,1.105);

	this.instance_1 = new lib.backkk55();
	this.instance_1.parent = this;
	this.instance_1.setTransform(70,15,0.989,0.989);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1.105,scaleY:1.105,x:-10,y:-8}}]}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:0.916,scaleY:0.916,x:6,y:8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-8,437,183.4);


(lib.Symbol63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backkk6();
	this.instance.parent = this;

	this.instance_1 = new lib.backkk55();
	this.instance_1.parent = this;
	this.instance_1.setTransform(70,15,0.989,0.989);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1,scaleY:1,x:0,y:0}}]}).to({state:[{t:this.instance_1},{t:this.instance,p:{scaleX:1.169,scaleY:1.169,x:-15,y:-14}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,427,169.3);


(lib.Symbol62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#330000").ss(1,1,1).p("AmujbINdAAIAAG3ItdAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#330000").s().p("AmuDcIAAm3INdAAIAAG3g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol62, new cjs.Rectangle(-44,-22.9,88.2,45.9), null);


(lib.Symbol60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(7,1,1).dr(-41.85,-41.9,83.7,83.8);
	this.shape.setTransform(0,0,0.757,0.757);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol60, new cjs.Rectangle(-35.2,-35.2,70.4,70.5), null);


(lib.Symbol55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Untitled2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.564,0.564);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol55, new cjs.Rectangle(0,0,196.9,125.8), null);


(lib.Symbol53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_92 = function() {
		//this.stop();
		 //createjs.Sound.play("mysound");
		 
		 this.on("tick", show);
		 
		 
		 function  show(event)
		{
			this.text_1.gotoAndStop(4);
			this.techer_1.gotoAndPlay(1);
			
		  // self.myChildren_mc.childrensChildren_mc.gotoAndStop(3); // W O R K S !!!
		} 
		 
		/*  this.parent.text_1.gotoAndStop(4);
		  
		    this.parent.tool3.gotoAndStop(1);*/
			//this.parent.tools.y= 100;
			//	this.parent.txt.text = "ffffffffffffffffff" ;
				
			//	this.tool3.visible = false;//
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(92).call(this.frame_92).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30));

	// Layer_1
	this.text = new cjs.Text("هذة الأداة ليست مطلوبة في التجربة الحالية", "26px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 42;
	this.text.lineWidth = 618;
	this.text.parent = this;
	this.text.setTransform(260,4.2,1,2.066);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({_off:false},0).wait(29));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("EgpBgJXMBSDAAAIAASvMhSDAAAg");
	this.shape.setTransform(257.3,37.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgpBAJYIAAyvMBSDAAAIAASvg");
	this.shape_1.setTransform(257.3,37.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(29));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol29copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],78), null, new cjs.Matrix2D(0.571,0,0,0.546,-16.2,-20.8)).s().p("AihDQIAAmfIFDAAIAAGfg");
	this.shape.setTransform(20.2,7.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29copy5, new cjs.Rectangle(4,-13,32.4,41.6), null);


(lib.Symbol29copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],78), null, new cjs.Matrix2D(0.571,0,0,0.546,-16.2,-20.8)).s().p("AihDQIAAmfIFDAAIAAGfg");
	this.shape.setTransform(20.2,7.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29copy4, new cjs.Rectangle(4,-13,32.4,41.6), null);


(lib.Symbol25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D1D1C5").ss(0.1,1,1).p("EhFhgmRMCLDAAAMAAABMjMiLDAAAg");
	this.shape.setTransform(445,245);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1D1C5").s().p("EhFhAmSMAAAhMjMCLDAAAMAAABMjg");
	this.shape_1.setTransform(445,245);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol25, new cjs.Rectangle(-1,-1,892,492), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],72), null, new cjs.Matrix2D(0.234,0,0,0.234,-64.4,-66.4)).s().p("AlPFoIAArPIKfAAIAALPg");
	this.shape.setTransform(33.6,36);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(0,0,67.3,71.9), null);


(lib.Symbol17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(2,1,1).p("AiCEnIEFpN");
	this.shape.setTransform(-6.4,13.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5C97B9","#EBF6F7","#5D99BC"],[0,0.463,1],4.2,1.5,-4.1,-2.1).s().p("AjhGQIFwtJQA2gLAdAvQjKGoimGiQgVAHgQAAQgmAAgIgsg");
	this.shape_1.setTransform(0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(51,51,51,0.02)").s().p("AjOmCIH6jtIgZRwQjwg+lOCtg");
	this.shape_2.setTransform(-0.1,-2.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17copy, new cjs.Rectangle(-30.1,-65,60,124.9), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(2,1,1).p("AiCEnIEFpN");
	this.shape.setTransform(-6.4,13.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5C97B9","#EBF6F7","#5D99BC"],[0,0.463,1],4.2,1.5,-4.1,-2.1).s().p("AjhGQIFwtJQA2gLAdAvQjKGoimGiQgVAHgQAAQgmAAgIgsg");
	this.shape_1.setTransform(0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(51,51,51,0.02)").s().p("AjOmCIH6jtIgZRwQjwg+lOCtg");
	this.shape_2.setTransform(-0.1,-2.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17, new cjs.Rectangle(-30.1,-65,60,124.9), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.293,-0.169,0.169,0.293,-165.4,11.2)).s().p("Ak7AYIACgBIHskbICJDtIh6BFIl0DXg");
	this.shape.setTransform(-1129.5,347.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.339,0,0,0.339,-125.7,-99.7)).s().p("AoEJ2IAAzqIQJAAIAADhIiCAAIgVgmIhBAmIliAAIAADMIhLArIACAEIgCABICIDrIF1jWICIAAIAAL4g");
	this.shape_1.setTransform(-1148.1,364.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-1199.8,301.9,103.4,125.9), null);


(lib.Symbol7copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5).call(this.frame_5).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhI/ANnIAA7NMCR/AAAIAAbNg");
	var mask_graphics_3 = new cjs.Graphics().p("EhKlAZwMAAAgzfMCVLAAAMAAAAzfg");
	var mask_graphics_4 = new cjs.Graphics().p("EhMMAl6MAAAhLzMCYZAAAMAAABLzg");
	var mask_graphics_5 = new cjs.Graphics().p("EhNzAyEMAAAhkHMCbnAAAMAAABkHg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:269.9,y:64}).wait(1).to({graphics:mask_graphics_3,x:272.9,y:137.4}).wait(1).to({graphics:mask_graphics_4,x:275.8,y:210.8}).wait(1).to({graphics:mask_graphics_5,x:278.7,y:284.1}).wait(1));

	// Layer_1
	this.text = new cjs.Text("قراءة المزيد عبر مدونة فلابي", "18px 'Arial'", "#0000FF");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.parent = this;
	this.text.setTransform(-24.2,500.4,1.755,1.755);

	this.text_1 = new cjs.Text("قراءة المزيد عبر مدونة فلابي", "18px 'Arial'", "#0000FF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 25;
	this.text_1.parent = this;
	this.text_1.setTransform(-24.2,318,1.755,1.755);

	this.text_2 = new cjs.Text("تطبيقات حياتية", "24px 'Arial'", "#666600");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 32;
	this.text_2.parent = this;
	this.text_2.setTransform(749.7,339.3,1.755,1.755);

	this.text_3 = new cjs.Text("أضف لمعلوماتك", "24px 'Arial'", "#666600");
	this.text_3.textAlign = "right";
	this.text_3.lineHeight = 32;
	this.text_3.parent = this;
	this.text_3.setTransform(749.7,119.1,1.755,1.755);

	this.text_4 = new cjs.Text("  ....... تستخدم الكثافة كثيرا في حياتنا", "22px 'Arial'", "#330000");
	this.text_4.textAlign = "right";
	this.text_4.lineHeight = 30;
	this.text_4.lineWidth = 498;
	this.text_4.parent = this;
	this.text_4.setTransform(702.2,416.7,1.755,1.755);

	this.text_5 = new cjs.Text("  .......  الكثافة هي كتلة وحدة الحجوم من المادة", "22px 'Arial'", "#330000");
	this.text_5.textAlign = "right";
	this.text_5.lineHeight = 30;
	this.text_5.lineWidth = 498;
	this.text_5.parent = this;
	this.text_5.setTransform(702.2,223.8,1.755,1.755);

	this.text_6 = new cjs.Text("روابط خارجية", "26px 'Arial'", "#E87E00");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 45;
	this.text_6.parent = this;
	this.text_6.setTransform(139.3,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.text_2,this.text_3,this.text_4,this.text_5,this.text_6,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},1).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhIOAHcIAAu3MCQdAAAIAAO3g");
	var mask_graphics_3 = new cjs.Graphics().p("EhJFANbIAA61MCSLAAAIAAa1g");
	var mask_graphics_4 = new cjs.Graphics().p("EhJ7ATaMAAAgmzMCT3AAAMAAAAmzg");
	var mask_graphics_5 = new cjs.Graphics().p("EhKyAZZMAAAgyxMCVlAAAMAAAAyxg");
	var mask_graphics_6 = new cjs.Graphics().p("EhLoAfYMAAAg+vMCXRAAAMAAAA+vg");
	var mask_graphics_7 = new cjs.Graphics().p("EhMfAlYMAAAhKvMCY/AAAMAAABKvg");
	var mask_graphics_8 = new cjs.Graphics().p("EhNVArXMAAAhWtMCarAAAMAAABWtg");
	var mask_graphics_9 = new cjs.Graphics().p("EhOLAxWMAAAhirMCcXAAAMAAABirg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:261,y:29}).wait(1).to({graphics:mask_graphics_3,x:255,y:67.3}).wait(1).to({graphics:mask_graphics_4,x:249,y:105.6}).wait(1).to({graphics:mask_graphics_5,x:243,y:144}).wait(1).to({graphics:mask_graphics_6,x:236.9,y:182.3}).wait(1).to({graphics:mask_graphics_7,x:230.9,y:220.6}).wait(1).to({graphics:mask_graphics_8,x:224.9,y:259}).wait(1).to({graphics:mask_graphics_9,x:218.9,y:297.1}).wait(1));

	// Layer_1
	this.text = new cjs.Text("نستنتج أن كثافة المواد التي تطفو فوق الماء\n أقل من كثافة الماء، وكثافة المواد التي \nتغوص في الماء أكبر من كثافة الماء", "30px 'Arial'", "#330000");
	this.text.textAlign = "center";
	this.text.lineHeight = 37;
	this.text.lineWidth = 537;
	this.text.parent = this;
	this.text.setTransform(243.5,135.8,1.755,1.755);

	this.text_1 = new cjs.Text("الاستنتاج", "26px 'Arial'", "#E87E00");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 45;
	this.text_1.parent = this;
	this.text_1.setTransform(298.7,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
			createjs.Sound.stop("water");
	}
	this.frame_1 = function() {
		this.stop();
		
			createjs.Sound.play("water")
		   var myInstance = createjs.Sound.play("water", {interrupt: createjs.Sound.INTERRUPT_ANY, loop:-1});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// tools_0٦
	this.instance = new lib.tools0٦();
	this.instance.parent = this;
	this.instance.setTransform(0,155,0.882,0.882);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// tools_0٥
	this.instance_1 = new lib.tools0٥();
	this.instance_1.parent = this;
	this.instance_1.setTransform(6,142,0.882,0.882);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(1));

	// Layer_0
	this.instance_2 = new lib.Layer0_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(9,0,0.882,0.882);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

	// tools_0٧
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5C97B9","#EBF6F7","#5D99BC"],[0,0.463,1],-4,-0.1,4.1,-0.1).s().p("AgoLOQANq+gNrdIBQAAIAAWbg");
	this.shape.setTransform(133.5,137.3);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6,0,138,212.6);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vlaby_board0٦();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.839,0.839);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-21},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.1,86.5);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vlaby_board0٣();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.839,0.839);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-17},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,11.8,86.5);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vlaby_board0٤();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.839,0.839);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:-8,y:-18},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,35.3,83.1);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vlaby_board0٥();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.839,0.839);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-18},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,16,85.6);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Vlaby_board0٧();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.839,0.839);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:5,y:-13},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.2,84);


(lib.sub_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("V", "39px 'Arial'", "#66CC00");
	this.text.textAlign = "right";
	this.text.lineHeight = 46;
	this.text.lineWidth = 26;
	this.text.parent = this;
	this.text.setTransform(12.3,-21.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3300FF").s("#3300FF").ss(6,1,1).dr(-36.75,-36.75,73.5,73.5);
	this.shape.setTransform(0,0,0.66,0.66);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.sub_5, new cjs.Rectangle(-27.2,-27.2,54.5,54.5), null);


(lib.sub_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("L", "39px 'Arial'");
	this.text.textAlign = "right";
	this.text.lineHeight = 46;
	this.text.lineWidth = 28;
	this.text.parent = this;
	this.text.setTransform(14.4,-21.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#669900").s("#669900").ss(6,1,1).dr(-36.75,-36.75,73.5,73.5);
	this.shape.setTransform(0,0,0.66,0.66);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.sub_4, new cjs.Rectangle(-27.2,-27.2,54.5,54.5), null);


(lib.sub_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("Y", "39px 'Arial'", "#669900");
	this.text.textAlign = "right";
	this.text.lineHeight = 46;
	this.text.lineWidth = 28;
	this.text.parent = this;
	this.text.setTransform(14.4,-21.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#663300").s("#663300").ss(6,1,1).dr(-36.75,-36.75,73.5,73.5);
	this.shape.setTransform(0,0,0.66,0.66);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.sub_3, new cjs.Rectangle(-27.2,-27.2,54.5,54.5), null);


(lib.sub_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("B", "39px 'Arial'", "#339900");
	this.text.textAlign = "right";
	this.text.lineHeight = 46;
	this.text.lineWidth = 26;
	this.text.parent = this;
	this.text.setTransform(12.3,-21.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#330000").s("#330000").ss(6,1,1).dr(-36.75,-36.75,73.5,73.5);
	this.shape.setTransform(0,0,0.66,0.66);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.sub_2, new cjs.Rectangle(-27.2,-27.2,54.5,54.5), null);


(lib.sub_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("A", "39px 'Arial'");
	this.text.textAlign = "right";
	this.text.lineHeight = 46;
	this.text.lineWidth = 26;
	this.text.parent = this;
	this.text.setTransform(12.3,-21.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3399CC").s("#3399CC").ss(6,1,1).dr(-36.75,-36.75,73.5,73.5);
	this.shape.setTransform(0,0,0.66,0.66);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.sub_1, new cjs.Rectangle(-27.2,-27.2,54.5,54.5), null);


(lib.point7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCC33").s().p("Am5BGQi3gdAAgpQAAgpC3gdQC3gdECAAQEDAAC3AdQC3AdAAApQAAApi3AdQi3AekDAAQkCAAi3geg");
	this.shape.setTransform(-62.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-125,-20,125,20);


(lib.mybeker2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],78), null, new cjs.Matrix2D(0.569,0,0,0.545,-16.2,-22.1)).s().p("AihDBIAAmBIFCAAIAAGBg");
	this.shape.setTransform(34.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],78), null, new cjs.Matrix2D(0.569,0,0,0.545,-16.2,-1.4)).s().p("AihAOIAAgbIFCAAIAAAbg");
	this.shape_1.setTransform(34.1,1.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18,0,32.3,41.5);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#9900FF").ss(1,1,1).p("Aglk9IBLAAIAAJ7IhLAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9900FF").s().p("AgkE+IAAp7IBJAAIAAJ7g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.7,-32.8,9.5,65.7);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#9900FF").ss(1,1,1).p("Aglk9IBLAAIAAJ7IhLAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9900FF").s().p("AgkE+IAAp7IBJAAIAAJ7g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.7,-32.8,9.5,65.7);


(lib.Symbolr1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(1));

	// Layer_2
	this.text = new cjs.Text("ورقة عباد الشمس الحمراء", "8px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 11;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(20.6,2.3,0.37,0.515);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(5));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgOCPIg0kdIBRAAIA0Edg");
	this.shape.setTransform(37,24.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AgICDQgjhzgdiSIBRAAQAYCHAoB+g");
	this.shape_1.setTransform(37.6,23);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AgCB2QguhWgeiVIBSAAQAUB+A3Btg");
	this.shape_2.setTransform(38.3,21.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AAFBqQg4g6ghiZIBTAAQAQB3BGBcg");
	this.shape_3.setTransform(38.9,20.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF0000").s().p("AALBeQhBgegkidIBTAAQANBvBVBMg");
	this.shape_4.setTransform(39.5,19.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,0,0,0.439)").s().p("AgOCPIg0kdIBRAAIA0Edg");
	this.shape_5.setTransform(37,24.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("ABICPIg0kdIBPAAIA0EdgAgNCPIg0kdIBOAAIA0EdgAhiCPIg0kdIBPAAIAzEdg");
	this.shape_6.setTransform(19.5,24.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("ADNAxIgZAAIhSAAIgJAAIhPAAIgHAAIhOAAIgGAAIhPAAIgbAAIAAgDIgShfIGJAAIASBig");
	this.shape_7.setTransform(20.6,5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],52), null, new cjs.Matrix2D(1,0,0.18,1,-822.5,-402.8)).s().p("AinCeIg5k7IABAEIAaAAIA0EcIBOAAIgzkcIAGAAIA0EcIBOAAIgzkcIAHAAIAzEcIBPAAIg0kcIAJAAIAzEcIBTAAIg0kcIAaAAIA4E3g");
	this.shape_8.setTransform(24.2,25.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(5));

	// Layer_3_copy
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#666666").ss(0.1,1,1).p("AgojDIAIgTIBJGWIgKAXg");
	this.shape_9.setTransform(3.3,21.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AgojDIAIgTIBJGWIgKAXg");
	this.shape_10.setTransform(3.3,21.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9}]}).wait(5));

	// Layer_3
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#666666").ss(0.1,1,1).p("Ai/gKIgJAVIGBAAIAQgVg");
	this.shape_11.setTransform(26.6,42.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#666666").s().p("AjIALIAJgVIGIAAIgQAVg");
	this.shape_12.setTransform(26.6,42.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.7,-0.6,49.5,45);


(lib.Symbolb1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(1));

	// Layer_2
	this.text = new cjs.Text("", "8px '_sans'");
	this.text.textAlign = "center";
	this.text.lineHeight = 11;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(20.6,2.3,0.37,0.515,0,-0.9,0);

	this.timeline.addTween(cjs.Tween.get(this.text).to({_off:true},1).wait(4));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0063ED").s().p("AgNCPIgzkdIBNAAIA0Edg");
	this.shape.setTransform(37.1,24.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0063ED").s().p("AhDh+IBNAAQATB+AnB7IhQAEQgih1gViIg");
	this.shape_1.setTransform(37.5,22.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0063ED").s().p("AhHhtIBOAAQAMBtA1BnIhTAHQgshagQiBg");
	this.shape_2.setTransform(37.8,21);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0063ED").s().p("AhKhdIBNAAQAGBdBCBUIhVAKQg1g/gLh8g");
	this.shape_3.setTransform(38.2,19.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0063ED").s().p("AhOhNIBOAAQAABMBPBBIhYAOQg+glgHh2g");
	this.shape_4.setTransform(38.6,17.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(0,99,237,0.569)").s().p("AgOCPIg0kdIBRAAIA0Edg");
	this.shape_5.setTransform(37,24.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0063ED").s().p("ABICPIg0kdIBPAAIA0EdgAgNCPIg0kdIBOAAIA0EdgAhiCPIg0kdIBPAAIAzEdg");
	this.shape_6.setTransform(19.5,24.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("ADNAxIgZAAIhSAAIgJAAIhPAAIgHAAIhOAAIgGAAIhPAAIgbAAIAAgDIgShfIGJAAIASBig");
	this.shape_7.setTransform(20.6,5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],52), null, new cjs.Matrix2D(1,0,0.18,1,-822.5,-402.8)).s().p("AinCeIg5k7IABAEIAaAAIA0EcIBOAAIgzkcIAGAAIA0EcIBOAAIgzkcIAHAAIAzEcIBPAAIg0kcIAJAAIAzEcIBTAAIg0kcIAaAAIA4E3g");
	this.shape_8.setTransform(24.2,25.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(5));

	// Layer_3_copy
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#666666").ss(0.1,1,1).p("AgojDIAIgTIBJGWIgKAXg");
	this.shape_9.setTransform(3.3,21.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AgojDIAIgTIBJGWIgKAXg");
	this.shape_10.setTransform(3.3,21.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9}]}).to({state:[]},1).wait(4));

	// Layer_3
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#666666").ss(0.1,1,1).p("Ai/gKIgJAVIGBAAIAQgVg");
	this.shape_11.setTransform(26.6,42.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#666666").s().p("AjIALIAJgVIGIAAIgQAVg");
	this.shape_12.setTransform(26.6,42.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).to({state:[]},1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.7,-0.6,49.5,45);


(lib.Symbol79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._9();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61.2,66.4);


(lib.Symbol78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._8();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,65.4,66.4);


(lib.Symbol77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._7();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61.2,65.4);


(lib.Symbol76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._6();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,62.2,70.7);


(lib.Symbol73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._5();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61.2,71.7);


(lib.Symbol72 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._4();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,62.2,73.8);


(lib.Symbol71copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61.2,66.4);


(lib.Symbol69copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,62.2,66.4);


(lib.Symbol68copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.054,1.054);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,63.3,68.6);


(lib.Symbol68_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Final_lab_controllsqsqq();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.318,0.318);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,27.4,22.3);


(lib.Symbol67_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Final_lab_controllsqsqss();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.318,0.318);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,27.4,22.3);


(lib.Symbol63_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_2 = new lib.Final_lab_controll1pngcopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,0,0.318,0.318);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({scaleX:0.29,x:3},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,71.2,36.3);


(lib.Symbol59copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(228,228,228,0.129)").s("rgba(214,214,214,0.859)").ss(0.1,1,1).rr(-1003.4,-511.7,2006.8,1023.4,24.8);
	this.shape.setTransform(589.3,411,0.587,0.803);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol59copy3, new cjs.Rectangle(-1,-1,1180.7,824), null);


(lib.Symbol59 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(228,228,228,0.129)").s("rgba(214,214,214,0.859)").ss(0.1,1,1).rr(-1003.4,-511.7,2006.8,1023.4,24.8);
	this.shape.setTransform(589.3,411,0.587,0.803);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol59, new cjs.Rectangle(-1,-1,1180.7,824), null);


(lib.Symbol55_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.Untitled2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.564,0.564);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol55_1, new cjs.Rectangle(0,0,196.9,125.8), null);


(lib.Symbol54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Untitled2();
	this.instance.parent = this;
	this.instance.setTransform(196.9,0,0.564,0.564,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol54, new cjs.Rectangle(0,0,196.9,125.8), null);


(lib.myput = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D0D065").ss(1,1,1).p("AVBAAQAABLmKA0QmKA1otAAQoqAAmLg1QmLg0AAhLQAAhKGLg1QGLg0IqAAQItAAGKA0QGKA1AABKg");
	this.shape.setTransform(62,9.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D0CF64").s().p("Au1B/QmKg0gBhLQABhKGKg1QGLg0IqAAQItAAGKA0QGKA1AABKQAABLmKA0QmKA1otAAQoqAAmLg1g");
	this.shape_1.setTransform(62,9.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF00").ss(1,1,1).p("AVBAAQAABLmKA0QmKA1otAAQoqAAmLg1QmLg0AAhLQAAhKGLg1QGLg0IqAAQItAAGKA0QGKA1AABKg");
	this.shape_2.setTransform(62,9.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("Au1B/QmKg0gBhLQABhKGKg1QGLg0IqAAQItAAGKA0QGKA1AABKQAABLmKA0QmKA1otAAQoqAAmLg1g");
	this.shape_3.setTransform(62,9.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

	// Layer_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.02)").s("rgba(153,153,0,0)").ss(1,1,1).de(-110,-59,220,118);
	this.shape_4.setTransform(77.7,-40.2,1.66,3.03);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.8,-220,367.1,359.6);


(lib.Symbol41copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.text = new cjs.Text("HCl", "19px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 23;
	this.text.lineWidth = 49;
	this.text.parent = this;
	this.text.setTransform(34.3,61.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape.setTransform(34.6,72);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).wait(1));

	// Layer_1
	this.instance = new lib.Front();
	this.instance.parent = this;
	this.instance.setTransform(11,13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Mesh_0();
	this.instance_1.parent = this;
	this.instance_1.setTransform(12,90.4);

	this.instance_2 = new lib.Mesh();
	this.instance_2.parent = this;
	this.instance_2.setTransform(17.6,16.2);

	this.instance_3 = new lib.Mesh_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(10.9,13.1);

	this.instance_4 = new lib.Mesh_2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,94.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol41copy3, new cjs.Rectangle(0,13,69,89.3), null);


(lib.Symbol31copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_43 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(43).call(this.frame_43).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0000FF").ss(0.1,1,1).p("AoSioIQlAAIAAFRIwlAAg");
	this.shape.setTransform(62,36.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0000FF").s().p("AoSCpIAAlRIQlAAIAAFRg");
	this.shape_1.setTransform(62,36.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(44));

	// Back_4
	this.instance = new lib.Back4();
	this.instance.parent = this;
	this.instance.setTransform(0,5,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(44));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,5,123.7,71.7);


(lib.Symbol31copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Front_4
	this.instance = new lib.Front4();
	this.instance.parent = this;
	this.instance.setTransform(2,0,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Back_4
	this.instance_1 = new lib.Back4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,5,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31copy3, new cjs.Rectangle(0,0,127.9,76.7), null);


(lib.Symbol31copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_43 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(43).call(this.frame_43).wait(1));

	// Front_4
	this.instance = new lib.Front4();
	this.instance.parent = this;
	this.instance.setTransform(2,0,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(44));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AoVAIIAAgPIQrAAIAAAPg");
	var mask_graphics_2 = new cjs.Graphics().p("AoVARIAAghIQrAAIAAAhg");
	var mask_graphics_3 = new cjs.Graphics().p("AoVAZIAAgxIQrAAIAAAxg");
	var mask_graphics_4 = new cjs.Graphics().p("AoVAiIAAhDIQrAAIAABDg");
	var mask_graphics_5 = new cjs.Graphics().p("AoVAqIAAhTIQrAAIAABTg");
	var mask_graphics_6 = new cjs.Graphics().p("AoVAzIAAhlIQrAAIAABlg");
	var mask_graphics_7 = new cjs.Graphics().p("AoVA7IAAh1IQrAAIAAB1g");
	var mask_graphics_8 = new cjs.Graphics().p("AoVBEIAAiHIQrAAIAACHg");
	var mask_graphics_9 = new cjs.Graphics().p("AoVBMIAAiXIQrAAIAACXg");
	var mask_graphics_10 = new cjs.Graphics().p("AoVBVIAAipIQrAAIAACpg");
	var mask_graphics_11 = new cjs.Graphics().p("AoVBdIAAi5IQrAAIAAC5g");
	var mask_graphics_12 = new cjs.Graphics().p("AoVBmIAAjLIQrAAIAADLg");
	var mask_graphics_13 = new cjs.Graphics().p("AoVBuIAAjbIQrAAIAADbg");
	var mask_graphics_14 = new cjs.Graphics().p("AoVB3IAAjtIQrAAIAADtg");
	var mask_graphics_15 = new cjs.Graphics().p("AoVB/IAAj9IQrAAIAAD9g");
	var mask_graphics_16 = new cjs.Graphics().p("AoVCIIAAkPIQrAAIAAEPg");
	var mask_graphics_17 = new cjs.Graphics().p("AoVCQIAAkfIQrAAIAAEfg");
	var mask_graphics_18 = new cjs.Graphics().p("AoVCZIAAkxIQrAAIAAExg");
	var mask_graphics_19 = new cjs.Graphics().p("AoVChIAAlBIQrAAIAAFBg");
	var mask_graphics_20 = new cjs.Graphics().p("AoVCqIAAlTIQrAAIAAFTg");
	var mask_graphics_21 = new cjs.Graphics().p("AoVCyIAAljIQrAAIAAFjg");
	var mask_graphics_22 = new cjs.Graphics().p("AoVC7IAAl1IQrAAIAAF1g");
	var mask_graphics_23 = new cjs.Graphics().p("AoVDDIAAmFIQrAAIAAGFg");
	var mask_graphics_24 = new cjs.Graphics().p("AoVDMIAAmXIQrAAIAAGXg");
	var mask_graphics_25 = new cjs.Graphics().p("AoVDUIAAmnIQrAAIAAGng");
	var mask_graphics_26 = new cjs.Graphics().p("AoVDdIAAm5IQrAAIAAG5g");
	var mask_graphics_27 = new cjs.Graphics().p("AoVDlIAAnJIQrAAIAAHJg");
	var mask_graphics_28 = new cjs.Graphics().p("AoVDuIAAnbIQrAAIAAHbg");
	var mask_graphics_29 = new cjs.Graphics().p("AoVD3IAAntIQrAAIAAHtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:62.6,y:51.5}).wait(1).to({graphics:mask_graphics_2,x:62.6,y:50.6}).wait(1).to({graphics:mask_graphics_3,x:62.6,y:49.7}).wait(1).to({graphics:mask_graphics_4,x:62.6,y:48.9}).wait(1).to({graphics:mask_graphics_5,x:62.6,y:48}).wait(1).to({graphics:mask_graphics_6,x:62.6,y:47.2}).wait(1).to({graphics:mask_graphics_7,x:62.6,y:46.3}).wait(1).to({graphics:mask_graphics_8,x:62.6,y:45.5}).wait(1).to({graphics:mask_graphics_9,x:62.6,y:44.6}).wait(1).to({graphics:mask_graphics_10,x:62.6,y:43.8}).wait(1).to({graphics:mask_graphics_11,x:62.6,y:42.9}).wait(1).to({graphics:mask_graphics_12,x:62.6,y:42.1}).wait(1).to({graphics:mask_graphics_13,x:62.6,y:41.2}).wait(1).to({graphics:mask_graphics_14,x:62.6,y:40.4}).wait(1).to({graphics:mask_graphics_15,x:62.6,y:39.5}).wait(1).to({graphics:mask_graphics_16,x:62.6,y:38.7}).wait(1).to({graphics:mask_graphics_17,x:62.6,y:37.8}).wait(1).to({graphics:mask_graphics_18,x:62.6,y:37}).wait(1).to({graphics:mask_graphics_19,x:62.6,y:36.1}).wait(1).to({graphics:mask_graphics_20,x:62.6,y:35.3}).wait(1).to({graphics:mask_graphics_21,x:62.6,y:34.4}).wait(1).to({graphics:mask_graphics_22,x:62.6,y:33.6}).wait(1).to({graphics:mask_graphics_23,x:62.6,y:32.7}).wait(1).to({graphics:mask_graphics_24,x:62.6,y:31.9}).wait(1).to({graphics:mask_graphics_25,x:62.6,y:31}).wait(1).to({graphics:mask_graphics_26,x:62.6,y:30.2}).wait(1).to({graphics:mask_graphics_27,x:62.6,y:29.3}).wait(1).to({graphics:mask_graphics_28,x:62.6,y:28.5}).wait(1).to({graphics:mask_graphics_29,x:62.6,y:27.6}).wait(15));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0000FF").ss(0.1,1,1).p("AoVj2IQrAAIAAHtIwrAAg");
	this.shape.setTransform(62.6,27.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0000FF").s().p("AoVD3IAAnsIQrAAIAAHsg");
	this.shape_1.setTransform(62.6,27.6);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(43));

	// Layer_6 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_30 = new cjs.Graphics().p("AqrAYIAAgvIVXAAIAAAvg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AqrAuIAAhbIVXAAIAABbg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AqrBDIAAiFIVXAAIAACFg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AqrBYIAAivIVXAAIAACvg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AqrBuIAAjbIVXAAIAADbg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AqrCDIAAkFIVXAAIAAEFg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AqrCYIAAkvIVXAAIAAEvg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AqrCtIAAlZIVXAAIAAFZg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AqrDDIAAmFIVXAAIAAGFg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AqrDYIAAmvIVXAAIAAGvg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AqrDtIAAnZIVXAAIAAHZg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AqrECIAAoDIVXAAIAAIDg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AqrEYIAAovIVXAAIAAIvg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AqrEtIAApZIVXAAIAAJZg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(30).to({graphics:mask_1_graphics_30,x:63.5,y:2.5}).wait(1).to({graphics:mask_1_graphics_31,x:63.5,y:4.6}).wait(1).to({graphics:mask_1_graphics_32,x:63.5,y:6.8}).wait(1).to({graphics:mask_1_graphics_33,x:63.5,y:8.9}).wait(1).to({graphics:mask_1_graphics_34,x:63.5,y:11}).wait(1).to({graphics:mask_1_graphics_35,x:63.5,y:13.2}).wait(1).to({graphics:mask_1_graphics_36,x:63.5,y:15.3}).wait(1).to({graphics:mask_1_graphics_37,x:63.5,y:17.4}).wait(1).to({graphics:mask_1_graphics_38,x:63.5,y:19.5}).wait(1).to({graphics:mask_1_graphics_39,x:63.5,y:21.7}).wait(1).to({graphics:mask_1_graphics_40,x:63.5,y:23.8}).wait(1).to({graphics:mask_1_graphics_41,x:63.5,y:25.9}).wait(1).to({graphics:mask_1_graphics_42,x:63.5,y:28.1}).wait(1).to({graphics:mask_1_graphics_43,x:63.5,y:30.2}).wait(1));

	// Layer_5_copy
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0000FF").ss(6,1,1).p("Agfj9QBOgigTIf");
	this.shape_2.setTransform(119.2,30.5);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(30).to({_off:false},0).wait(14));

	// Layer_5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#0000FF").ss(6,1,1).p("AAkj9QhYgiAVIf");
	this.shape_3.setTransform(4.5,30.5);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(30).to({_off:false},0).wait(14));

	// Back_4
	this.instance_1 = new lib.Back4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,5,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127.9,76.7);


(lib.Symbol31copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Front_4
	this.instance = new lib.Front4();
	this.instance.parent = this;
	this.instance.setTransform(2,0,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0000FF").ss(0.1,1,1).p("AokivIRJAAIAAFfIxJAAg");
	this.shape.setTransform(62.4,34.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0000FF").s().p("AokCwIAAlfIRJAAIAAFfg");
	this.shape_1.setTransform(62.4,34.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Back_4
	this.instance_1 = new lib.Back4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,5,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31copy, new cjs.Rectangle(0,0,127.9,76.7), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Front_1١
	this.instance = new lib.Front1١();
	this.instance.parent = this;
	this.instance.setTransform(14,0,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(14,0,28.6,53.1), null);


(lib.Symbol8copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.293,-0.169,0.169,0.293,-165.4,11.2)).s().p("Ak7AYIACgBIHskbICJDtIh6BFIl0DXg");
	this.shape.setTransform(-1129.5,347.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.339,0,0,0.339,-125.7,-99.7)).s().p("AoEJ2IAAzqIQJAAIAADhIiCAAIgVgmIhBAmIliAAIAADMIhLArIACAEIgCABICIDrIF1jWICIAAIAAL4g");
	this.shape_1.setTransform(-1148.1,364.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8copy2, new cjs.Rectangle(-1199.8,301.9,103.4,125.9), null);


(lib.Symbol7copy9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2).call(this.frame_2).wait(7).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EhHYA00MAAAhpnMCOxAAAMAAABpng");
	var mask_graphics_2 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_3 = new cjs.Graphics().p("EhHYAIkIAAxHMCOxAAAIAARHg");
	var mask_graphics_4 = new cjs.Graphics().p("EhHYAPqIAA/TMCOxAAAIAAfTg");
	var mask_graphics_5 = new cjs.Graphics().p("EhHYAWxMAAAgthMCOxAAAMAAAAthg");
	var mask_graphics_6 = new cjs.Graphics().p("EhHYAd4MAAAg7vMCOxAAAMAAAA7vg");
	var mask_graphics_7 = new cjs.Graphics().p("EhHYAk+MAAAhJ7MCOxAAAMAAABJ7g");
	var mask_graphics_8 = new cjs.Graphics().p("EhHYAsFMAAAhYJMCOxAAAMAAABYJg");
	var mask_graphics_9 = new cjs.Graphics().p("EhHYAzMMAAAhmXMCOxAAAMAAABmXg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:267,y:298.5}).wait(1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_2,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_3,x:267,y:34.6}).wait(1).to({graphics:mask_graphics_4,x:267,y:78.6}).wait(1).to({graphics:mask_graphics_5,x:267,y:122.6}).wait(1).to({graphics:mask_graphics_6,x:267,y:166.6}).wait(1).to({graphics:mask_graphics_7,x:267,y:210.6}).wait(1).to({graphics:mask_graphics_8,x:267,y:254.6}).wait(1).to({graphics:mask_graphics_9,x:267,y:298.5}).wait(1));

	// Layer_1
	this.text = new cjs.Text("Stand.\nPins.\nIron nail.\nLong insulated copper wire.\nDry battery.", "26px 'Arial'", "#330000");
	this.text.lineHeight = 37;
	this.text.lineWidth = 359;
	this.text.parent = this;
	this.text.setTransform(-29.5,178.5,1.755,1.755);

	this.text_1 = new cjs.Text("-\n-\n-\n-\n-", "26px 'Arial'", "#330000");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 45;
	this.text_1.lineWidth = 23;
	this.text_1.parent = this;
	this.text_1.setTransform(-38.2,179.1,1,1.363);

	this.text_2 = new cjs.Text("Tools of Experiment", "26px 'Arial'", "#E87E00");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 45;
	this.text_2.parent = this;
	this.text_2.setTransform(346.8,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.text_2,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text,p:{lineHeight:36.95}}]}).to({state:[]},1).to({state:[{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text,p:{lineHeight:34.25}}]},1).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,0,666.4,570.8);


(lib.Symbol7copy8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhIWAHRIAAuhMCQtAAAIAAOhg");
	var mask_graphics_3 = new cjs.Graphics().p("EhJUANEIAA6HMCSpAAAIAAaHg");
	var mask_graphics_4 = new cjs.Graphics().p("EhKRAS4MAAAglvMCUjAAAMAAAAlvg");
	var mask_graphics_5 = new cjs.Graphics().p("EhLPAYsMAAAgxXMCWfAAAMAAAAxXg");
	var mask_graphics_6 = new cjs.Graphics().p("EhMNAefMAAAg89MCYbAAAMAAAA89g");
	var mask_graphics_7 = new cjs.Graphics().p("EhNLAkTMAAAhIlMCaXAAAMAAABIlg");
	var mask_graphics_8 = new cjs.Graphics().p("EhOJAqHMAAAhUNMCcTAAAMAAABUNg");
	var mask_graphics_9 = new cjs.Graphics().p("EhPHAv6MAAAhfzMCePAAAMAAABfzg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:267,y:27.8}).wait(1).to({graphics:mask_graphics_3,x:267,y:65}).wait(1).to({graphics:mask_graphics_4,x:267,y:102.1}).wait(1).to({graphics:mask_graphics_5,x:267,y:139.3}).wait(1).to({graphics:mask_graphics_6,x:267,y:176.5}).wait(1).to({graphics:mask_graphics_7,x:267.1,y:213.6}).wait(1).to({graphics:mask_graphics_8,x:267.1,y:250.8}).wait(1).to({graphics:mask_graphics_9,x:267,y:288}).wait(1));

	// Layer_1
	this.text = new cjs.Text("Put the stand in the middle of the laboratory table .\nPut the pins on stand,then attach the nail to the stand.\nPlace the battery near the stand, and then coil the wire in a spiral shape around the nail.\nConnect the two ends of the wire with battery, and then observe what happens.", "34px 'Arial'");
	this.text.lineHeight = 56;
	this.text.lineWidth = 1002;
	this.text.parent = this;
	this.text.setTransform(-49.3,113.7,0.809,1);

	this.text_1 = new cjs.Text("-\n-\n-\n\n-", "26px 'Arial'", "#330000");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 38;
	this.text_1.lineWidth = 23;
	this.text_1.parent = this;
	this.text_1.setTransform(-71.2,104.7,1,1.494);

	this.text_2 = new cjs.Text("Steps of the experiment     ", "26px 'Arial'", "#E87E00");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 45;
	this.text_2.parent = this;
	this.text_2.setTransform(132.9,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.text_2,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhHYAGpIAAtRMCOxAAAIAANRg");
	var mask_graphics_3 = new cjs.Graphics().p("EhHYAL2IAA3rMCOxAAAIAAXrg");
	var mask_graphics_4 = new cjs.Graphics().p("EhHYARCMAAAgiDMCOxAAAMAAAAiDg");
	var mask_graphics_5 = new cjs.Graphics().p("EhHYAWPMAAAgsdMCOxAAAMAAAAsdg");
	var mask_graphics_6 = new cjs.Graphics().p("EhHYAbbMAAAg21MCOxAAAMAAAA21g");
	var mask_graphics_7 = new cjs.Graphics().p("EhHYAgnMAAAhBNMCOxAAAMAAABBNg");
	var mask_graphics_8 = new cjs.Graphics().p("EhHYAl0MAAAhLnMCOxAAAMAAABLng");
	var mask_graphics_9 = new cjs.Graphics().p("EhHYArAMAAAhV/MCOxAAAMAAABV/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:267,y:23.9}).wait(1).to({graphics:mask_graphics_3,x:267,y:57.1}).wait(1).to({graphics:mask_graphics_4,x:267,y:90.4}).wait(1).to({graphics:mask_graphics_5,x:267,y:123.6}).wait(1).to({graphics:mask_graphics_6,x:267,y:156.9}).wait(1).to({graphics:mask_graphics_7,x:267,y:190.1}).wait(1).to({graphics:mask_graphics_8,x:267,y:223.4}).wait(1).to({graphics:mask_graphics_9,x:267,y:256.6}).wait(1));

	// Layer_1
	this.text = new cjs.Text("Videos will be available soon ...\nFollow us", "22px 'Arial'", "#330000");
	this.text.lineHeight = 39;
	this.text.parent = this;
	this.text.setTransform(-134.5,135.8,1.755,1.755);

	this.text_1 = new cjs.Text("Videos", "26px 'Arial'", "#E87E00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 45;
	this.text_1.parent = this;
	this.text_1.setTransform(139.3,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhIOAHcIAAu3MCQdAAAIAAO3g");
	var mask_graphics_3 = new cjs.Graphics().p("EhJFANbIAA61MCSLAAAIAAa1g");
	var mask_graphics_4 = new cjs.Graphics().p("EhJ7ATaMAAAgmzMCT3AAAMAAAAmzg");
	var mask_graphics_5 = new cjs.Graphics().p("EhKyAZZMAAAgyxMCVlAAAMAAAAyxg");
	var mask_graphics_6 = new cjs.Graphics().p("EhLoAfYMAAAg+vMCXRAAAMAAAA+vg");
	var mask_graphics_7 = new cjs.Graphics().p("EhMfAlYMAAAhKvMCY/AAAMAAABKvg");
	var mask_graphics_8 = new cjs.Graphics().p("EhNVArXMAAAhWtMCarAAAMAAABWtg");
	var mask_graphics_9 = new cjs.Graphics().p("EhOLAxWMAAAhirMCcXAAAMAAABirg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:261,y:29}).wait(1).to({graphics:mask_graphics_3,x:255,y:67.3}).wait(1).to({graphics:mask_graphics_4,x:249,y:105.6}).wait(1).to({graphics:mask_graphics_5,x:243,y:144}).wait(1).to({graphics:mask_graphics_6,x:236.9,y:182.3}).wait(1).to({graphics:mask_graphics_7,x:230.9,y:220.6}).wait(1).to({graphics:mask_graphics_8,x:224.9,y:259}).wait(1).to({graphics:mask_graphics_9,x:218.9,y:297.1}).wait(1));

	// Layer_1
	this.text = new cjs.Text("when an electric current passes through the coil, it works as magnet.", "25px 'Arial'", "#330000");
	this.text.lineHeight = 31;
	this.text.lineWidth = 443;
	this.text.parent = this;
	this.text.setTransform(-63.4,135.8,1.755,1.755);

	this.text_1 = new cjs.Text("Conclusion", "26px 'Arial'", "#E87E00");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 45;
	this.text_1.parent = this;
	this.text_1.setTransform(261.9,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_1_graphics_2 = new cjs.Graphics().p("EhHYAGpIAAtRMCOxAAAIAANRg");
	var mask_1_graphics_3 = new cjs.Graphics().p("EhHYAL2IAA3rMCOxAAAIAAXrg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EhHYARCMAAAgiDMCOxAAAMAAAAiDg");
	var mask_1_graphics_5 = new cjs.Graphics().p("EhHYAWPMAAAgsdMCOxAAAMAAAAsdg");
	var mask_1_graphics_6 = new cjs.Graphics().p("EhHYAbbMAAAg21MCOxAAAMAAAA21g");
	var mask_1_graphics_7 = new cjs.Graphics().p("EhHYAgnMAAAhBNMCOxAAAMAAABBNg");
	var mask_1_graphics_8 = new cjs.Graphics().p("EhHYAl0MAAAhLnMCOxAAAMAAABLng");
	var mask_1_graphics_9 = new cjs.Graphics().p("EhHYArAMAAAhV/MCOxAAAMAAABV/g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_1_graphics_2,x:267,y:23.9}).wait(1).to({graphics:mask_1_graphics_3,x:267,y:57.1}).wait(1).to({graphics:mask_1_graphics_4,x:267,y:90.4}).wait(1).to({graphics:mask_1_graphics_5,x:267,y:123.6}).wait(1).to({graphics:mask_1_graphics_6,x:267,y:156.9}).wait(1).to({graphics:mask_1_graphics_7,x:267,y:190.1}).wait(1).to({graphics:mask_1_graphics_8,x:267,y:223.4}).wait(1).to({graphics:mask_1_graphics_9,x:267,y:256.6}).wait(1));

	// Layer_1
	this.text_7 = new cjs.Text("Links will be available soon ...\nFollow us", "22px 'Arial'", "#330000");
	this.text_7.lineHeight = 39;
	this.text_7.parent = this;
	this.text_7.setTransform(-138.5,135.8,1.755,1.755);

	this.text_8 = new cjs.Text("The Links", "26px 'Arial'", "#E87E00");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 45;
	this.text_8.parent = this;
	this.text_8.setTransform(139.3,3.5,1.755,1.755);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape_1.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text_7,this.text_8,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_8},{t:this.text_7}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhHYAGpIAAtRMCOxAAAIAANRg");
	var mask_graphics_3 = new cjs.Graphics().p("EhHYAL2IAA3rMCOxAAAIAAXrg");
	var mask_graphics_4 = new cjs.Graphics().p("EhHYARCMAAAgiDMCOxAAAMAAAAiDg");
	var mask_graphics_5 = new cjs.Graphics().p("EhHYAWPMAAAgsdMCOxAAAMAAAAsdg");
	var mask_graphics_6 = new cjs.Graphics().p("EhHYAbbMAAAg21MCOxAAAMAAAA21g");
	var mask_graphics_7 = new cjs.Graphics().p("EhHYAgnMAAAhBNMCOxAAAMAAABBNg");
	var mask_graphics_8 = new cjs.Graphics().p("EhHYAl0MAAAhLnMCOxAAAMAAABLng");
	var mask_graphics_9 = new cjs.Graphics().p("EhHYArAMAAAhV/MCOxAAAMAAABV/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:267,y:23.9}).wait(1).to({graphics:mask_graphics_3,x:267,y:57.1}).wait(1).to({graphics:mask_graphics_4,x:267,y:90.4}).wait(1).to({graphics:mask_graphics_5,x:267,y:123.6}).wait(1).to({graphics:mask_graphics_6,x:267,y:156.9}).wait(1).to({graphics:mask_graphics_7,x:267,y:190.1}).wait(1).to({graphics:mask_graphics_8,x:267,y:223.4}).wait(1).to({graphics:mask_graphics_9,x:267,y:256.6}).wait(1));

	// Layer_1
	this.text = new cjs.Text("The tests will be available soon ...\nFollow us", "22px 'Arial'", "#330000");
	this.text.lineHeight = 39;
	this.text.parent = this;
	this.text.setTransform(-142.5,135.8,1.755,1.755);

	this.text_1 = new cjs.Text("The Tests", "26px 'Arial'", "#E87E00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 45;
	this.text_1.parent = this;
	this.text_1.setTransform(139.3,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhHYAHSIAAujMCOxAAAIAAOjg");
	var mask_graphics_3 = new cjs.Graphics().p("EhHYANIIAA6PMCOxAAAIAAaPg");
	var mask_graphics_4 = new cjs.Graphics().p("EhHYAS9MAAAgl5MCOxAAAMAAAAl5g");
	var mask_graphics_5 = new cjs.Graphics().p("EhHYAYyMAAAgxjMCOxAAAMAAAAxjg");
	var mask_graphics_6 = new cjs.Graphics().p("EhHYAeoMAAAg9PMCOxAAAMAAAA9Pg");
	var mask_graphics_7 = new cjs.Graphics().p("EhHYAkdMAAAhI5MCOxAAAMAAABI5g");
	var mask_graphics_8 = new cjs.Graphics().p("EhHYAqSMAAAhUjMCOxAAAMAAABUjg");
	var mask_graphics_9 = new cjs.Graphics().p("EhHYAwHMAAAhgNMCOxAAAMAAABgNg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:267,y:28}).wait(1).to({graphics:mask_graphics_3,x:267,y:65.3}).wait(1).to({graphics:mask_graphics_4,x:267,y:102.7}).wait(1).to({graphics:mask_graphics_5,x:267,y:140}).wait(1).to({graphics:mask_graphics_6,x:267,y:177.4}).wait(1).to({graphics:mask_graphics_7,x:267,y:214.7}).wait(1).to({graphics:mask_graphics_8,x:267,y:252}).wait(1).to({graphics:mask_graphics_9,x:267,y:289.3}).wait(1));

	// Layer_1
	this.text = new cjs.Text("Activities will be available soon ...\nFollow us", "22px 'Arial'", "#330000");
	this.text.lineHeight = 39;
	this.text.parent = this;
	this.text.setTransform(-155.6,140,1.755,1.755);

	this.text_1 = new cjs.Text("Activities", "26px 'Arial'", "#E87E00");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 45;
	this.text_1.parent = this;
	this.text_1.setTransform(251.6,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_graphics_2 = new cjs.Graphics().p("EhIWAHRIAAuhMCQtAAAIAAOhg");
	var mask_graphics_3 = new cjs.Graphics().p("EhJUANEIAA6HMCSpAAAIAAaHg");
	var mask_graphics_4 = new cjs.Graphics().p("EhKRAS4MAAAglvMCUjAAAMAAAAlvg");
	var mask_graphics_5 = new cjs.Graphics().p("EhLPAYsMAAAgxXMCWfAAAMAAAAxXg");
	var mask_graphics_6 = new cjs.Graphics().p("EhMNAefMAAAg89MCYbAAAMAAAA89g");
	var mask_graphics_7 = new cjs.Graphics().p("EhNLAkTMAAAhIlMCaXAAAMAAABIlg");
	var mask_graphics_8 = new cjs.Graphics().p("EhOJAqHMAAAhUNMCcTAAAMAAABUNg");
	var mask_graphics_9 = new cjs.Graphics().p("EhPHAv6MAAAhfzMCePAAAMAAABfzg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_graphics_2,x:267,y:27.8}).wait(1).to({graphics:mask_graphics_3,x:267,y:65}).wait(1).to({graphics:mask_graphics_4,x:267,y:102.1}).wait(1).to({graphics:mask_graphics_5,x:267,y:139.3}).wait(1).to({graphics:mask_graphics_6,x:267,y:176.5}).wait(1).to({graphics:mask_graphics_7,x:267.1,y:213.6}).wait(1).to({graphics:mask_graphics_8,x:267.1,y:250.8}).wait(1).to({graphics:mask_graphics_9,x:267,y:288}).wait(1));

	// Layer_1
	this.text = new cjs.Text("-\n-\n-\n-", "26px 'Arial'", "#330000");
	this.text.textAlign = "right";
	this.text.lineHeight = 43;
	this.text.lineWidth = 23;
	this.text.parent = this;
	this.text.setTransform(735.3,171.7,1,1.494);

	this.text_1 = new cjs.Text("ضع الكأس في منتصف المنضدة ، ثم ثبت الجدار المنفذ عليه\nضع كمية من المحلول المخفف في أحد جانبي الكأس\nضع كمية من المحلول المركز في الجانب الأخر \nانتظر بعض الوقت ولاحظ ما يحدث", "24px 'Arial'", "#330000");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 35;
	this.text_1.lineWidth = 537;
	this.text_1.parent = this;
	this.text_1.setTransform(703.6,178.5,1.755,1.755);

	this.text_2 = new cjs.Text("خطوات التجربة", "26px 'Arial'", "#E87E00");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 45;
	this.text_2.parent = this;
	this.text_2.setTransform(298.7,3.5,1.755,1.755);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text,this.text_1,this.text_2,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text}]},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var shape0 = new createjs.Shape(new createjs.Graphics().beginFill("#A5A890").drawRect(-1220,0,3673.8,1206));
		
		
		 this.addChild(shape0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy, null, null);


(lib.Symbol1iil = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFF00").ss(1,1,1).p("Az8kdMArJAAAIAAI7MguZAAAg");
	this.shape.setTransform(-12.4,-2.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("A3MEeIDQo7MArJAAAIAAI7g");
	this.shape_1.setTransform(-12.4,-2.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1iil, new cjs.Rectangle(-161.9,-32,299.1,59.3), null);


(lib.myhod2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Front4();
	this.instance.parent = this;
	this.instance.setTransform(2,0,0.44,0.422);

	this.instance_1 = new lib.Back4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,5,0.44,0.422);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.myhod2, new cjs.Rectangle(0,0,127.9,76.7), null);


(lib.mc_answer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{good:5,bad:11});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16));

	// txt
	this.txt_answer = new cjs.Text("answer", "bold 32px 'Georgia'", "#FFFFFF");
	this.txt_answer.name = "txt_answer";
	this.txt_answer.textAlign = "center";
	this.txt_answer.lineHeight = 38;
	this.txt_answer.lineWidth = 339;
	this.txt_answer.parent = this;
	this.txt_answer.setTransform(-1.2,-20.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_answer).wait(16));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660099").s().p("A6yD/QiWAAAAiWIAAjRQAAiWCWAAMA1lAAAQCWAAAACWIAADRQAACWiWAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FF00").s().p("A6yD/QiWAAAAiWIAAjRQAAiWCWAAMA1lAAAQCWAAAACWIAADRQAACWiWAAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("A6yD/QiWAAAAiWIAAjRQAAiWCWAAMA1lAAAQCWAAAACWIAADRQAACWiWAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},5).to({state:[{t:this.shape_2}]},6).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-186.5,-25.5,373,51);


(lib.Pathcopy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFE38B","#F4CE6E","#E6B349","#DA9E2C","#D28F18","#CE860B","#CC8307","#FFE38B","#FFE189","#FDDC80","#FBD272","#F8C45E","#F4B548","#CC8307"],[0,0.024,0.059,0.094,0.125,0.161,0.196,0.561,0.639,0.686,0.725,0.761,0.784,1],-33.2,23.3,-6.1,4.4).s().p("Ag2ADQgWgBAAgCQAAgBAWgBQAYgCAeAAQAfAAAYACQAWABAAABQAAACgWABQgWACghAAQggAAgWgCg");
	this.shape.setTransform(7.7,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Pathcopy3, new cjs.Rectangle(0,0,15.5,1), null);


(lib.Pathcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9100").s().p("AiPCQQg9g7AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A7Qg9A8hUAAQhUAAg7g8g");
	this.shape.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Pathcopy2, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.Pathcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFE38B","#F4CE6E","#E6B349","#DA9E2C","#D28F18","#CE860B","#CC8307","#FFE38B","#FFE189","#FDDC80","#FBD272","#F8C45E","#F4B548","#CC8307"],[0,0.024,0.059,0.094,0.125,0.161,0.196,0.561,0.639,0.686,0.725,0.761,0.784,1],-33.2,23.3,-6.1,4.4).s().p("Ag2ADQgWgBAAgCQAAgBAWgBQAYgCAeAAQAfAAAYACQAWABAAABQAAACgWABQgWACghAAQggAAgWgCg");
	this.shape.setTransform(7.7,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Pathcopy, new cjs.Rectangle(0,0,15.5,1), null);


(lib.Path_17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9100").s().p("AiPCQQg9g7AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A7Qg9A8hUAAQhUAAg7g8g");
	this.shape.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_17copy, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.Path_16copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#555369").s().p("AgxAyQgVgUAAgeQAAgdAVgVQAUgUAdAAQAeAAAUAUQASASADAYQADAXgNAVIgJgGQALgSgDgTQgCgVgPgOQgSgSgZAAQgYAAgSASQgSASAAAYQAAAZASASQAOAOAUADQATADASgJIAFAJQgQAIgSAAQgcAAgVgVg");
	this.shape.setTransform(7.1,7.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_16copy, new cjs.Rectangle(0,0.1,14.3,14.2), null);


(lib.Path_15copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9100").s().p("AiPCQQg9g7AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A7Qg9A8hUAAQhUAAg7g8g");
	this.shape.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_15copy, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.Path_14copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AgIAMIgGgMIAFgnQAGACAAAFIgEAgIAWAog");
	this.shape.setTransform(1.5,4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_14copy, new cjs.Rectangle(0,0,3.1,8), null);


(lib.Path_13copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("Ag+BVIgJhhIBthIIAiAYIhrA9IgFBUg");
	this.shape.setTransform(7.2,8.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_13copy, new cjs.Rectangle(0,0,14.4,16.9), null);


(lib.Path_12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AgRAAIAjgFIAFADIgtAIQAAgFAFgBg");
	this.shape.setTransform(2.3,0.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_12copy, new cjs.Rectangle(0,0,4.6,1.3), null);


(lib.Path_11copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AAiBaIhvjDQAAgBAAgBQAAAAAAgBQAAAAABgBQAAAAABgBIAGgDIgMgPQADgBAJAEQAIADACADQCMD4ABAAIgTAAIAAAAQgFAAgYgngABSCBIAAAAIAAAAIAAAAg");
	this.shape.setTransform(8.2,12.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_11copy, new cjs.Rectangle(0,0,16.4,25.9), null);


(lib.Path_10copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AgygtQACgBAEAEIAZASIAAABIATAOIAAABIAnAlQACABAKARg");
	this.shape.setTransform(5.1,4.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_10copy, new cjs.Rectangle(0,0,10.2,9.3), null);


(lib.Path_9copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AAUARIgsgiQAFgCAEADIAlAfIACABIABgBIgEADg");
	this.shape.setTransform(2.5,1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_9copy, new cjs.Rectangle(0,0,5.1,3.7), null);


(lib.Path_8copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AgRAAIAjgFIAFAEIgtAHQABgFAEgBg");
	this.shape.setTransform(2.3,0.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_8copy, new cjs.Rectangle(0,0,4.6,1.3), null);


(lib.Path_7copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9100").s().p("AiPCQQg9g7AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A7Qg9A8hUAAQhUAAg7g8g");
	this.shape.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_7copy, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.Path_6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#000000"],[0,1],11.6,18.3,-17.3,-16.1).s().p("Ah4CXIhHhHIAAgBQgFgDAAgHIAAjMQAAgHAFgEQAEgEAGAAIDNAAQAGAAADADIABAAICaCZIABAMIAIBEQACAagSAUQgSATgbAAg");
	this.shape.setTransform(19.7,15.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_6copy, new cjs.Rectangle(0,0,39.4,30.3), null);


(lib.Path_5copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9100").s().p("AiPCQQg9g7AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A7Qg9A8hUAAQhUAAg7g8g");
	this.shape.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_5copy, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.Path_4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9100").s().p("AiPCQQg9g7AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A7Qg9A8hUAAQhUAAg7g8g");
	this.shape.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_4copy, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.Path_3copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5D5D4").s().p("AiJAaQg5gKAAgQQAAgOA5gLQA6gLBPAAQBRAAA5ALQA5ALAAAOQAAAQg5AKQg4AKhSAAQhQAAg5gKg");
	this.shape.setTransform(19.5,3.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3copy2, new cjs.Rectangle(0,0,39,7.3), null);


(lib.Path_3_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444058").s().p("AiuBzIAAjlIFdAAIAADlg");
	this.shape.setTransform(17.5,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3_1copy, new cjs.Rectangle(0,0,35,23), null);


(lib.Path_3_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AATASIgrgjQAEgCAEAEIAmAeIACAAIABAAIgEAEg");
	this.shape.setTransform(2.5,1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3_0copy, new cjs.Rectangle(0,0,5,3.8), null);


(lib.Path_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5D5D4").s().p("AiJAaQg5gKAAgQQAAgOA5gLQA6gLBPAAQBRAAA5ALQA5ALAAAOQAAAQg5AKQg4AKhSAAQhQAAg5gKg");
	this.shape.setTransform(19.5,3.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,39,7.3), null);


(lib.Path_2copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#35383B","#DBD8D9","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0,0.541,0.557,0.757,0.831,0.98],-7,-1.6,4.5,10.4).s().p("AggB3QgTgIgJgLQgLgOAAgbQgBgoADiNQAFCuADAPQADASAQAMQAQALAWACQAPABAYgGQAbgHALAAQgOADgbAJIghALIgLACQgKAAgKgEg");
	this.shape.setTransform(7.2,12.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2copy5, new cjs.Rectangle(0,0,14.5,24.5), null);


(lib.Path_2copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B3B3B3").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(27.4,24.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2copy4, new cjs.Rectangle(0,0,54.9,48.4), null);


(lib.Path_2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#35383B","#DBD8D9","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0,0.541,0.557,0.757,0.831,0.98],-7,-1.6,4.5,10.4).s().p("AggB3QgTgIgJgLQgLgOAAgbQgBgoADiNQAFCuADAPQADASAQAMQAQALAWACQAPABAYgGQAbgHALAAQgOADgbAJIghALIgLACQgKAAgKgEg");
	this.shape.setTransform(7.2,12.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2copy, new cjs.Rectangle(0,0,14.5,24.5), null);


(lib.Path_2_6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B3B3B3").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(27.4,24.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2_6copy, new cjs.Rectangle(0,0,54.9,48.4), null);


(lib.Path_2_5copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B3B3B3").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(27.4,24.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2_5copy, new cjs.Rectangle(0,0,54.9,48.4), null);


(lib.Path_2_4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AgZgTQAEgBAEADIAoAiIACABIABgBIgEAEg");
	this.shape.setTransform(2.6,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2_4copy, new cjs.Rectangle(0,0,5.3,4.1), null);


(lib.Path_2_3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B3B3B3").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(27.4,24.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2_3copy, new cjs.Rectangle(0,0,54.9,48.4), null);


(lib.Path_2_2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B3B3B3").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(27.4,24.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2_2copy, new cjs.Rectangle(0,0,54.9,48.4), null);


(lib.Path_2_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B3B3B3").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(27.4,24.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2_1copy, new cjs.Rectangle(0,0,54.9,48.4), null);


(lib.Path_2_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B3B3B3").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(27.4,24.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2_0copy, new cjs.Rectangle(0,0,54.9,48.4), null);


(lib.Path_1copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#AEB7C0","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0.063,0.471,0.922,0.941,0.98],0.2,0,0,0.2,0,10.5).s().p("AAgABQgngEgjADQgkAFgUABQghACgLgDQAMACA3gJQAlgHAxADQAYACAzAGQAgAFAZABQgzgBg8gGg");
	this.shape.setTransform(14.6,0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1copy3, new cjs.Rectangle(0.4,0,28.6,1.6), null);


(lib.Path_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#AEB7C0","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0.063,0.471,0.922,0.941,0.98],0.2,0,0,0.2,0,10.5).s().p("AAgABQgngEgjADQgkAFgUABQghACgLgDQAMACA3gJQAlgHAxADQAYACAzAGQAgAFAZABQgzgBg8gGg");
	this.shape.setTransform(14.6,0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1copy, new cjs.Rectangle(0.4,0,28.6,1.6), null);


(lib.Path_1_13copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgdAeQgMgNAAgRQAAgQAMgNQANgMAQAAQARAAANAMQAMANgBAQQABARgMANQgNAMgRgBQgQABgNgMg");
	this.shape.setTransform(4.2,4.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_13copy, new cjs.Rectangle(0,0,8.3,8.3), null);


(lib.Path_1_12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCC8C9").s().p("AoQDbQgIgJgJgGIgTgRQgUgigMgXIgNgbIgEgPQgQgtgMg1IgIgqIAAgBQgDggACgpQAtgpAVg7QBMAEA/AoIOoAAQAeAAATAaIBkCMQAMAQAAATQAAATgMAQIhkCOQgTAZgeAAIvDAAIgLAFQgWgFgXgCg");
	this.shape.setTransform(65.2,22.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_12copy, new cjs.Rectangle(0,0,130.4,45.3), null);


(lib.Path_1_11copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#555369").s().p("AgmAnQgRgRAAgWQAAgWARgQQAQgQAWgBQAXABAQAQQANAMADARQADAPgHAQIgKgEQAGgNgDgNQgCgNgKgKQgOgOgSAAQgRAAgOAOQgNANAAASQAAARANAPQAKAJANADQANACAMgEIAEAJQgKAFgLgBQgWAAgQgQg");
	this.shape.setTransform(5.6,5.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_11copy, new cjs.Rectangle(0,0,11.2,11.1), null);


(lib.Path_1_10copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCC8C9").s().p("AoQDbQgIgJgJgGIgTgRQgUgigMgXIgNgbIgEgPQgQgtgMg1IgIgqIAAgBQgDggACgpQAtgpAVg7QBMAEA/AoIOoAAQAeAAATAaIBkCMQAMAQAAATQAAATgMAQIhkCOQgTAZgeAAIvDAAIgLAFQgWgFgXgCg");
	this.shape.setTransform(65.2,22.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_10copy, new cjs.Rectangle(0,0,130.4,45.3), null);


(lib.Path_1_9copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AgGAWIAIghIAAgIIAFgCQAAAEgBAHIgCAGIgFAQIgBAKg");
	this.shape.setTransform(0.7,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_9copy, new cjs.Rectangle(0,0,1.4,4.4), null);


(lib.Path_1_8copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0AF8D").s().p("AgYgTQAEAAADACIAoAiIACAAIgEADg");
	this.shape.setTransform(2.5,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_8copy, new cjs.Rectangle(0,0,5.1,4), null);


(lib.Path_1_7copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AgGAAQAAgGAGAAQAHAAAAAGQAAAHgHAAQgGAAAAgHg");
	this.shape.setTransform(0.7,0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_7copy, new cjs.Rectangle(0,0,1.4,1.4), null);


(lib.Path_1_6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AgGAAQAAgCACgCQACgCACAAQAHAAAAAGQAAAHgHAAQgGAAAAgHg");
	this.shape.setTransform(0.7,0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_6copy, new cjs.Rectangle(0,0,1.4,1.4), null);


(lib.Path_1_5copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCC8C9").s().p("AoQDbQgIgJgJgGIgTgRQgUgigMgXIgNgbIgEgPQgQgtgMg1IgIgqIAAgBQgDggACgpQAtgpAVg7QBMAEA/AoIOoAAQAeAAATAaIBkCMQAMAQAAATQAAATgMAQIhkCOQgTAZgeAAIvDAAIgLAFQgWgFgXgCg");
	this.shape.setTransform(65.2,22.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_5copy, new cjs.Rectangle(0,0,130.4,45.3), null);


(lib.Path_1_4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Path_1_4copy, null, null);


(lib.Path_1_3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCC8C9").s().p("AoQDbQgIgJgJgGIgTgRQgUgigMgXIgNgbIgEgPQgQgtgMg1IgIgqIAAgBQgDggACgpQAtgpAVg7QBMAEA/AoIOoAAQAeAAATAaIBkCMQAMAQAAATQAAATgMAQIhkCOQgTAZgeAAIvDAAIgLAFQgWgFgXgCg");
	this.shape.setTransform(65.2,22.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_3copy, new cjs.Rectangle(0,0,130.4,45.3), null);


(lib.Path_1_2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCC8C9").s().p("AoQDbQgIgJgJgGIgTgRQgUgigMgXIgNgbIgEgPQgQgtgMg1IgIgqIAAgBQgDggACgpQAtgpAVg7QBMAEA/AoIOoAAQAeAAATAaIBkCMQAMAQAAATQAAATgMAQIhkCOQgTAZgeAAIvDAAIgLAFQgWgFgXgCg");
	this.shape.setTransform(65.2,22.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_2copy, new cjs.Rectangle(0,0,130.4,45.3), null);


(lib.Path_1_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCC8C9").s().p("AoQDbQgIgJgJgGIgTgRQgUgigMgXIgNgbIgEgPQgQgtgMg1IgIgqIAAgBQgDggACgpQAtgpAVg7QBMAEA/AoIOoAAQAeAAATAaIBkCMQAMAQAAATQAAATgMAQIhkCOQgTAZgeAAIvDAAIgLAFQgWgFgXgCg");
	this.shape.setTransform(65.2,22.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1_1copy, new cjs.Rectangle(0,0,130.4,45.3), null);


(lib.Path_0copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9100").s().p("AiPCQQg9g7AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A7Qg9A8hUAAQhUAAg7g8g");
	this.shape.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_0copy5, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.Path_0copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Path_0copy4, null, null);


(lib.Path_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Path_0copy, null, null);


(lib.Groupcopy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFE38B","#F4CE6E","#E6B349","#DA9E2C","#D28F18","#CE860B","#CC8307","#FFE38B","#FFE189","#FDDC80","#FBD272","#F8C45E","#F4B548","#CC8307"],[0,0.024,0.059,0.094,0.125,0.161,0.196,0.561,0.639,0.686,0.725,0.761,0.784,1],-19.2,0.5,1.8,-0.1).s().p("AgKCQQANjUAAgnQgBgVgUgPQAlAKAAAPIgOECIgFAEg");
	this.shape.setTransform(1.9,14.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Groupcopy3, new cjs.Rectangle(0,0,3.9,28.9), null);


(lib.Groupcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFE38B","#F4CE6E","#E6B349","#DA9E2C","#D28F18","#CE860B","#CC8307","#FFE38B","#FFE189","#FDDC80","#FBD272","#F8C45E","#F4B548","#CC8307"],[0,0.024,0.059,0.094,0.125,0.161,0.196,0.561,0.639,0.686,0.725,0.761,0.784,1],-19.2,0.5,1.8,-0.1).s().p("AgKCQQANjUAAgnQgBgVgUgPQAlAKAAAPIgOECIgFAEg");
	this.shape.setTransform(1.9,14.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Groupcopy2, new cjs.Rectangle(0,0,3.9,28.9), null);


(lib.Group_17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AghAQIBAgkIADAEIhCAlg");
	this.shape.setTransform(4.1,4.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A1A1A").s().p("AgjAHIAWgRIAGgBQABAAADgEIAagLIANAQIhBAkgAAQgNIglAUQgBABAAAAQgBABAAAAQAAABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAAAABAAIAmgVQAAAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAAAIgDgCIgBABg");
	this.shape_1.setTransform(3.6,3.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1A1A1A").s().p("AgJAGQgCgEABgEQABgFAEgCQAEgCAEABQAFACACAEQABACAAAEIgDABQgCAEgCABIgFABIgCACQgFgCgBgDgAgBgDQgEADACADQACAEAEgDQAEgBgCgEQgBgBAAAAQgBgBAAAAQgBAAAAgBQgBAAAAAAIgCABg");
	this.shape_2.setTransform(2.4,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1A1A1A").s().p("AgDADQgDgDAEgDQAEgCACAEQACAEgEABIgCABQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAAAg");
	this.shape_3.setTransform(2.4,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17copy, new cjs.Rectangle(0,0,7.5,6.2), null);


(lib.Group_16copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AgfABIAzg+IAMAIIAABzg");
	this.shape.setTransform(3.2,6.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16copy, new cjs.Rectangle(0,0,6.4,12.5), null);


(lib.Group_3copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AAAAWQgIgBgDgNIAIgZQAFgIAGAGIABAAQADADAAAGIgEAdQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQADADgFAAIgEAAg");
	this.shape.setTransform(1.2,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3copy3, new cjs.Rectangle(0,0,2.5,4.5), null);


(lib.Group_1copy7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A1EE").s().p("AipD9QgygDgHgvIADhMQgDhBgBhKQAAiWAOg0QAIgeCmgIQCqgKBFAiQAKAFADAIQADAGAAANIAJFDIADBMQgHAvgyADQglACiFAAQiFAAglgCg");
	this.shape.setTransform(22.8,25.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy7, new cjs.Rectangle(0.1,0,45.6,51.1), null);


(lib.Group_1copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AADALIgNgLQgEgEADgEIAAgBQAEgEAFADIANALQAEAEgDAFQgDACgCAAIgEgBg");
	this.shape.setTransform(1.3,1.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A1A1A").s().p("AgKALQgEgEAEgFIAMgMQAAAAABgBQAAAAABAAQAAgBABAAQABAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAEAFgEAEIgMAMQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_1.setTransform(1.3,1.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy6, new cjs.Rectangle(0,0,2.7,2.6), null);


(lib.Group_1copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A1EE").s().p("AipD9QgygDgHgvIADhMQgDhBgBhKQAAiWAOg0QAIgeCmgIQCqgKBFAiQAKAFADAIQADAGAAANIAJFDIADBMQgHAvgyADQglACiFAAQiFAAglgCg");
	this.shape.setTransform(22.8,25.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy4, new cjs.Rectangle(0.1,0,45.6,51.1), null);


(lib.Group_1_0copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AADALIgNgLQgFgEAEgEQAEgFAFAEIANAKQAFAEgEAFQgDACgCAAIgEgBg");
	this.shape.setTransform(1.3,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A1A1A").s().p("AgKALIAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAgBQABAAAAgBQAAAAAAgBQABAAAAgBIAMgMQAEgEAFAEIAAABQAAAAABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABIgMAMQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_1.setTransform(1.3,1.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_0copy3, new cjs.Rectangle(0,0,2.8,2.6), null);


(lib.ClipGroupcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	mask.setTransform(20.5,20.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#272525").s().p("AgsBLIAAiSQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAIAlAAQACgDACAAQADAAACADIAmAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIgmAAQgCADgDAAQgCAAgCgDIgjAAIAACQQAAABAAAAQgBAAAAABQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAAAAAgBg");
	this.shape.setTransform(12.5,25.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#272525").s().p("AgeAwQgNgNAAgSQAAgOAJgLQAJgMANgEIAAgXQgHgCAAgEQAAgHATAAQAKAAAFACQAFACAAADQAAAEgHACIAAAXQAOAEAIAMQAJALAAAOQAAASgNANQgNANgSAAQgRAAgNgNgAgMg4QgBABAAAAQgBAAgBABQAAAAAAAAQgBABAAAAQAAACAGABIACABIAAAcIgCAAQgNAEgIALQgJAJAAAOQAAARAMAMQAMAMAQAAQARAAAMgMQAMgMAAgRQAAgOgJgJQgIgLgNgEIgBAAIAAgcIABgBQAGgBAAgCQAAgBgEgCQgFgBgIAAQgGAAgGABg");
	this.shape_1.setTransform(14.9,22.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#272525").s().p("AgtAIQgDAAgCgCQgDgCAAgEQAAgDADgCQACgCADgBIBbAAQADABACACQADACAAADQAAAEgDACQgCACgDAAg");
	this.shape_2.setTransform(5.4,33.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#272525").s().p("ABDAdIAAgmQgCgMgHgEIgHgBIhoAAQgGgBgDAEQgGAGACAQIAAABIgCAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQgCgRAHgIQAFgFAHABIBnAAQAFgBAGADQAIAFACAOIAAAmQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAgBg");
	this.shape_3.setTransform(21.8,16.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#272525").s().p("AhHAmQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAABAAIATAAIAAhIIgGAAQgBAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAAAABAAQAAgBABAAIByAAQAAAAABABQAAAAAAAAQAAAAABABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAAAAAQgBABAAAAIgHAAIAABHIATAAQABAAAAAAQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQgBAAAAAAQAAAAgBAAIiLAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAgBgAguAlIBdgBIAAhHIhdAAg");
	this.shape_4.setTransform(31.6,26.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#272525").s().p("AgBAqQgIgBAAgHIAAhAQgEgCAAgDQAAgFANAAQAOAAAAAFQAAADgEACIAABAQAAADgDADQgCACgDAAgAgJgjIACACIACABIAABCQAAAFAEAAIADAAQAEAAAAgFIAAhCIACgBIACgCQAAgCgKAAQgJAAAAACg");
	this.shape_5.setTransform(34.4,23.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#272525").s().p("AgBAqQgDAAgCgCQgCgDAAgDIAAhAQgEgBAAgEQAAgFAMAAQAOAAAAAFQgBAEgEABIAABAQAAADgBADQgDACgDAAgAgJgjIADADIAABCQAAAFAFAAIADAAQAEAAABgFIAAhCIABgBIACgCQAAgCgKAAQgJAAAAACg");
	this.shape_6.setTransform(31.6,23.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#272525").s().p("AgBAqQgDAAgCgCQgDgDAAgDIAAhAQgDgCAAgDQAAgFAMAAQAOAAAAAFQAAAEgFABIAABAQABAHgIABgAgKgjIAFADIAABCQgBAFAFAAIADAAQAEAAAAgFIAAhCIABgBIAEgCQAAgCgLAAQgKAAAAACg");
	this.shape_7.setTransform(28.7,23.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAAAIIAAgPIAAgBQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAIAAAPQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAg");
	this.shape_8.setTransform(34.8,23);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0782C7").s().p("AgCAgIAAg+IAFAAIAAA4QAAAGgEAAg");
	this.shape_9.setTransform(34.7,24.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#8AC7ED").s().p("AAAAgQgFAAAAgGIAAg4IALAAIAAA4QAAAGgFAAg");
	this.shape_10.setTransform(34.4,24.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E5E6E7").s().p("AgFAoIAAhPQALAAAAAEQAAACgEACIAABBQAAAGgGAAg");
	this.shape_11.setTransform(35,23.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAEAoQgFAAAAgGIAAhBQgEgCAAgCQAAgEALAAIAABPg");
	this.shape_12.setTransform(33.9,23.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAAAIIAAgPQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIABABIAAAPIgBABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAg");
	this.shape_13.setTransform(31.9,23);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BC422A").s().p("AgCAcIAAg3IAFAAIAAAyQAAAFgEAAg");
	this.shape_14.setTransform(31.9,24.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D26835").s().p("AAAAcQgFAAAAgFIAAgyIALAAIAAAyQAAAFgFAAg");
	this.shape_15.setTransform(31.6,24.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E5E6E7").s().p("AgFAoIAAhPQALAAAAAEQAAACgEACIAABBQAAAGgFAAg");
	this.shape_16.setTransform(32.2,23.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAEAoQgFAAAAgGIAAhBQgBgBgBAAQAAAAgBgBQAAAAgBgBQAAAAAAgBQAAgEALAAIAABPg");
	this.shape_17.setTransform(31,23.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAAAIIAAgPIAAgBIABABIAAAPIgBABg");
	this.shape_18.setTransform(29.1,23);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#93377D").s().p("AgCAeIAAg7IAFAAIAAA2QAAAFgDAAg");
	this.shape_19.setTransform(29,24.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B6549B").s().p("AgBAeQgEAAAAgFIAAg2IALAAIAAA2QAAAFgFAAg");
	this.shape_20.setTransform(28.7,24.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E5E6E7").s().p("AgFAoIAAhPQALAAAAAEQAAACgEACIAABBQAAAGgFAAg");
	this.shape_21.setTransform(29.3,23.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAEAoQgFAAAAgGIAAhBQgEgCAAgCQAAgEALAAIAABPg");
	this.shape_22.setTransform(28.2,23.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#272525").s().p("AAAABIAAgBIABAAIAAABg");
	this.shape_23.setTransform(15,30.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BABCBE").s().p("AgHADIAAgFIANAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAIAAAAQAAABAAABQAAAAAAAAQgBABAAAAQgBAAAAAAg");
	this.shape_24.setTransform(15.8,33.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CFD0D2").s().p("AgNADQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAIAbAAQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAABQgBAAAAAAQAAABgBAAQAAAAgBAAg");
	this.shape_25.setTransform(15,33.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CFD0D2").s().p("AgIASIAAgjIAEAAIAAACQAFABAEAFQAEAFAAAFQAAAHgFAFQgEAFgHAAg");
	this.shape_26.setTransform(15.8,32.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#E5E6E7").s().p("AgLANQgFgFAAgHQAAgFAEgFQADgFAHgBIAAgCIAFAAIAAACQAGABAEAFQAEAFAAAFQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_27.setTransform(15,32.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#E7B643").s().p("AgCAAQAAgDACAAQADAAAAADQAAABAAABQgBABAAAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAgBAAgBg");
	this.shape_28.setTransform(15,29.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#D26835").s().p("AgCAHQgDgDABgDIAAAAIACgEQAAgBABgBQAAgBAAAAQABAAAAgBQAAAAAAABIAAABIAAACIADACQAEADgFAFIgCABIgCgBg");
	this.shape_29.setTransform(15,29.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#93377D").s().p("AgBACQAAgBAAAAQgBAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAAAQAAABgBAAQAAAAAAABIgCABIgBgBg");
	this.shape_30.setTransform(14.3,22.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#B6549B").s().p("AgBADQgDgDADgBQABgDADADQACABgCADIgDABIgBgBg");
	this.shape_31.setTransform(15.8,24.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#93377D").s().p("AgCACIgBgCIABgBQABgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAABQABAAAAAAQAAABgBAAQAAABgBAAIgCABIgCgBg");
	this.shape_32.setTransform(15.4,23.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#93377D").s().p("AgCAAQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_33.setTransform(13.4,23.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAg");
	this.shape_34.setTransform(18.5,24.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQgBAAAAAAg");
	this.shape_35.setTransform(18.1,24.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAIAOIgCgJIgBgBIgGgIIgFgFIAAAAIgCgBIgBgBIAAgCIABAAIABAAIABABIAAAAIAGAGIAAAAQAFAFACAEIAAABIABAAIADAJIgBACQgBAAAAAAQAAgBgBAAQAAAAAAAAQAAAAAAAAg");
	this.shape_36.setTransform(17,22.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#93377D").s().p("AgSgRIAlAAQAAAPgLAKQgKAKgQABg");
	this.shape_37.setTransform(16.8,25.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#B6549B").s().p("AgZAIQgLgKAAgPIBJAAQAAAPgLAKQgKAKgQABQgOgBgLgKg");
	this.shape_38.setTransform(14.9,25.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAJAPIgBgBIgDgIIAAgBIAAAAQgDgFgDgEIgFgFIAAAAIgCgBIgBgBIAAAAIAAgCQAAAAAAAAQAAgBAAAAQAAAAAAABQABAAAAAAIABAAIABABIABABIAFAFIAHAJIABABIAAABIADAJIgBABg");
	this.shape_39.setTransform(17.5,22.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#E5E6E7").s().p("AgUg6QASAAAAAFQAAAEgHABIAAAaQAMAEAKAKQAIALAAAOQAAASgNANQgLALgRABg");
	this.shape_40.setTransform(17,22.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgdAwQgMgNAAgSQAAgOAJgLQAJgKANgEIAAgaQgHgBAAgEQAAgFARAAQASAAAAAFQAAAEgHABIAAAaQAOAEAJAKQAIALAAAOQAAASgMANQgMALgSABQgQgBgNgLg");
	this.shape_41.setTransform(14.9,22.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#BC422A").s().p("AgDAAQAAgDADAAQAEAAAAADQAAAEgEAAQgDAAAAgEg");
	this.shape_42.setTransform(22.2,9.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#BC422A").s().p("AgHAAQAAgHAHAAQAEAAABADQADACAAACQAAAIgIAAQgHAAAAgIg");
	this.shape_43.setTransform(28.2,4.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#B6549B").s().p("AgHAIQgDgDAAgFQAAgEADgDQADgDAEAAQAFAAADADQADADAAAEQAAAFgDADQgDADgFAAQgEAAgDgDg");
	this.shape_44.setTransform(38.1,7.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#8AC7ED").s().p("AgDAAQAAgDADAAQAEAAAAADQAAAEgEAAQAAAAgBAAQAAgBgBAAQAAgBgBAAQAAgBAAgBg");
	this.shape_45.setTransform(36.1,17.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#D26835").s().p("AgCAAQAAAAAAAAQAAgBABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_46.setTransform(32.4,17.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#93377D").s().p("AgBAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_47.setTransform(1.7,4.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#93377D").s().p("AgEAAQABgDADAAQAEAAAAADQAAAEgEAAQgDAAgBgEg");
	this.shape_48.setTransform(2.7,10.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#93377D").s().p("AgDAAQAAgEADABQAEgBAAAEQAAAFgEAAQgDAAAAgFg");
	this.shape_49.setTransform(13.4,7.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#B6549B").s().p("AgIAAQAAgIAIAAQAIAAAAAIQAAAJgIAAQgIAAAAgJg");
	this.shape_50.setTransform(8.3,14.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#DBE7F0").s().p("Ah/B/Qg0g0AAhLQAAhJA0g2QA1g0BKAAQBLAAA0A0QA1A2AABJQAABLg1A0Qg0A1hLAAQhKAAg1g1g");
	this.shape_51.setTransform(20.5,20.4);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	this.shape_52.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_52).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroupcopy, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.ClipGroup_38copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlJBGIAAiLIKTAAIAACLg");
	mask.setTransform(33,7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDFEFF").s().p("Aj5BGQg6hBgWhKIKTAAIghBJQgSAogTAag");
	this.shape.setTransform(33,7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38copy, new cjs.Rectangle(0,0,66,14), null);


(lib.ClipGroup_38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlJBGIAAiLIKTAAIAACLg");
	mask.setTransform(33,7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDFEFF").s().p("Aj5BGQg6hBgWhKIKTAAIghBJQgSAogTAag");
	this.shape.setTransform(33,7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38, new cjs.Rectangle(0,0,66,14), null);


(lib.ClipGroup_37copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJClIAAlKIETAAIAAFKg");
	mask.setTransform(13.8,17);

	// Layer_3
	this.instance = new lib.Image_7();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_37copy, new cjs.Rectangle(0,0.4,27.5,33.1), null);


(lib.ClipGroup_37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJClIAAlKIETAAIAAFKg");
	mask.setTransform(13.8,17);

	// Layer_3
	this.instance = new lib.Image_7();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_37, new cjs.Rectangle(0,0.4,27.5,33.1), null);


(lib.ClipGroup_33copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.9,11.8);

	// Layer_3
	this.instance = new lib.Image_6();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_33copy, new cjs.Rectangle(0.1,0.4,61.7,22.8), null);


(lib.ClipGroup_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.9,11.8);

	// Layer_3
	this.instance = new lib.Image_6();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_33, new cjs.Rectangle(0.1,0.4,61.7,22.8), null);


(lib.ClipGroup_29copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.8,20.8);

	// Layer_3
	this.instance = new lib.Image_5();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29copy, new cjs.Rectangle(0.3,0.4,71,40.9), null);


(lib.ClipGroup_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.8,20.8);

	// Layer_3
	this.instance = new lib.Image_5();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29, new cjs.Rectangle(0.3,0.4,71,40.9), null);


(lib.ClipGroup_25copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(4.3,3.4);

	// Layer_3
	this.instance = new lib.Image_4();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25copy, new cjs.Rectangle(0.5,0.2,7.6,6.5), null);


(lib.ClipGroup_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(4.3,3.4);

	// Layer_3
	this.instance = new lib.Image_4();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25, new cjs.Rectangle(0.5,0.2,7.6,6.5), null);


(lib.ClipGroup_21copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAgIAAg/IBNAAIAAA/g");
	mask.setTransform(4,3.5);

	// Layer_3
	this.instance = new lib.Image_3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21copy, new cjs.Rectangle(0.1,0.3,7.8,6.4), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAgIAAg/IBNAAIAAA/g");
	mask.setTransform(4,3.5);

	// Layer_3
	this.instance = new lib.Image_3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(0.1,0.3,7.8,6.4), null);


(lib.ClipGroup_17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AYIAAgvIFpAAIAAAvg");
	mask.setTransform(18.1,2.7);

	// Layer_3
	this.instance = new lib.Image_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17copy, new cjs.Rectangle(0,0.3,36.2,4.8), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AYIAAgvIFpAAIAAAvg");
	mask.setTransform(18.1,2.7);

	// Layer_3
	this.instance = new lib.Image_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(0,0.3,36.2,4.8), null);


(lib.ClipGroup_13copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEiAAIAAA1g");
	mask.setTransform(14.7,2.7);

	// Layer_3
	this.instance = new lib.Image_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13copy, new cjs.Rectangle(0.1,0,29.1,5.5), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEiAAIAAA1g");
	mask.setTransform(14.7,2.7);

	// Layer_3
	this.instance = new lib.Image_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(0.1,0,29.1,5.5), null);


(lib.ClipGroup_9copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.6,20.8);

	// Layer_3
	this.instance = new lib.Image_0();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9copy, new cjs.Rectangle(0.1,0.4,71,40.9), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.6,20.8);

	// Layer_3
	this.instance = new lib.Image_0();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0.1,0.4,71,40.9), null);


(lib.ClipGroup_6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljBrIAAjVILHAAIAADVg");
	mask.setTransform(36,10.7);

	// Layer_3
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6copy, new cjs.Rectangle(0.4,0.1,71.1,21.3), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljBrIAAjVILHAAIAADVg");
	mask.setTransform(36,10.7);

	// Layer_3
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0.4,0.1,71.1,21.3), null);


(lib.ClipGroup_4copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiIAPQg4gGAAgJQAAgIA4gGQA5gGBPAAQBQAAA5AGQA4AGAAAIQAAAJg4AGQg5AGhQAAQhPAAg5gGg");
	mask.setTransform(19.3,2.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#292929","#292929","#323131","#494847","#656362","#848181","#A3A0A0","#BFBDBD","#D8D6D6","#EAE9E9","#F9F8F8","#FFFFFF"],[0,0.365,0.38,0.412,0.451,0.49,0.533,0.58,0.639,0.702,0.792,1],0,0,0,0,0,19.1).s().p("AjAAVIAAgpIGBAAIAAApg");
	this.shape.setTransform(19.3,2.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4copy2, new cjs.Rectangle(0,0,38.7,4.3), null);


(lib.ClipGroup_4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiIAPQg4gGAAgJQAAgIA4gGQA5gGBPAAQBQAAA5AGQA4AGAAAIQAAAJg4AGQg5AGhQAAQhPAAg5gGg");
	mask.setTransform(19.3,2.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#292929","#292929","#323131","#494847","#656362","#848181","#A3A0A0","#BFBDBD","#D8D6D6","#EAE9E9","#F9F8F8","#FFFFFF"],[0,0.365,0.38,0.412,0.451,0.49,0.533,0.58,0.639,0.702,0.792,1],0,0,0,0,0,19.1).s().p("AjAAVIAAgpIGBAAIAAApg");
	this.shape.setTransform(19.3,2.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4copy, new cjs.Rectangle(0,0,38.7,4.3), null);


(lib.ClipGroup_2copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJAPQg6gGAAgJQAAgIA6gGQA5gGBQAAQBRAAA6AGQA5AGAAAIQAAAJg5AGQg6AGhRAAQhQAAg5gGg");
	mask.setTransform(19.6,2.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#292929","#292929","#2E2E2E","#494747","#696666","#8C8989","#AEACAC","#CDCBCA","#E4E3E3","#F6F5F5","#FFFFFF"],[0,0.345,0.361,0.427,0.494,0.565,0.639,0.714,0.796,0.886,1],0,0,0,0,0,19.4).s().p("AjDAVIAAgpIGHAAIAAApg");
	this.shape.setTransform(19.6,2.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2copy2, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.ClipGroup_2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJAPQg6gGAAgJQAAgIA6gGQA5gGBQAAQBRAAA6AGQA5AGAAAIQAAAJg5AGQg6AGhRAAQhQAAg5gGg");
	mask.setTransform(19.6,2.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#292929","#292929","#2E2E2E","#494747","#696666","#8C8989","#AEACAC","#CDCBCA","#E4E3E3","#F6F5F5","#FFFFFF"],[0,0.345,0.361,0.427,0.494,0.565,0.639,0.714,0.796,0.886,1],0,0,0,0,0,19.4).s().p("AjDAVIAAgpIGHAAIAAApg");
	this.shape.setTransform(19.6,2.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2copy, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.ClipGroup_1copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	mask.setTransform(20.5,20.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#977DD1").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape.setTransform(20.3,26);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#977DD1").s().p("AgIAtIgIg5IAAgYQAAgQAQgBQARABAAAQIAAAYIgIA5QgBAJgIgBQgHABgBgJg");
	this.shape_1.setTransform(20.3,17.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#977DD1").s().p("AgHAPQgGgEADgGIAKgQQADgGAGADQACABABADQABADgCACIgKARQgBAEgEAAg");
	this.shape_2.setTransform(27.5,5.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#977DD1").s().p("AgOAJQgBgDAAgCQABgDADgBIARgKQACgBADAAQADABABADQABACAAADQgBACgDABIgQAKIgEABQgEAAgCgDg");
	this.shape_3.setTransform(32.8,10.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#977DD1").s().p("AgJAHQgHAAAAgHQAAgGAHAAIATAAQADAAACACQABABAAAAQAAABABAAQAAABAAABQAAAAAAAAQAAAHgHAAg");
	this.shape_4.setTransform(34.8,18);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#977DD1").s().p("AAGALIgRgKQgGgDADgFQAEgGAGADIAQAKQAGADgDAGQgCADgEAAg");
	this.shape_5.setTransform(32.8,25.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#977DD1").s().p("AgOAJQgDgGAGgDIAQgKQAHgDADAGQADAFgGADIgRAKIgDABQgEAAgCgDg");
	this.shape_6.setTransform(7.8,25.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#977DD1").s().p("AgJAHQgHAAAAgHQAAAAAAAAQAAgBAAgBQAAAAABgBQAAAAABgBQACgCADAAIATAAQAHAAAAAGQAAAHgHAAg");
	this.shape_7.setTransform(5.9,18);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#977DD1").s().p("AAFALIgQgKQgDgBgBgCQAAgDABgCQABgDADgBQADAAACABIARAKQADABABADQAAACgBADQgCADgEAAg");
	this.shape_8.setTransform(7.8,10.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#977DD1").s().p("AAAAMIgKgRQgCgCABgDQABgDACgBQAGgDADAGIAKAQQADAGgGAEIgDABQgEAAgBgEg");
	this.shape_9.setTransform(13.1,5.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#977DD1").s().p("AgGAKIAAgTQAAgHAGAAQAHAAAAAHIAAATQAAAHgHAAQgGAAAAgHg");
	this.shape_10.setTransform(20.3,3.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#977DD1").s().p("AgKCXQgDAAgEgCQgFgEgEgFQgVgHgCgQIgBgcQgUgPAAgVQAAgHgLgQQgNgSgFgMQgJgVAAgYQAAgsAggeQAggfAsAAQAtAAAgAfQAgAeAAAsQAAAZgJAUQgFAMgNASQgLAQAAAHQAAAVgUAPIgBAbQgCARgVAHQgDAFgGAEQgEACgEAAgAg4hkQgYAXAAAgQAAATAHARQAEAJAKAPQAQAWAAAQQAAAHAKAHIBDAAQAKgHAAgHQAAgPAPgXQALgPAEgJQAHgRAAgTQAAgggYgXQgXgXgiAAQggAAgYAXg");
	this.shape_11.setTransform(20.3,22.5);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	this.shape_12.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1copy3, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.ClipGroup_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	mask.setTransform(20.5,20.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9125").s().p("AiZBeIgDgDQgFgFAAgHQAAgHAFgEIBFhEQAEgEAHAAQAHAAAEAEIA0AzIBwhxIgOgPQgGgGADgGIACgDQACgDAHAAIA5gCQAGAAADADQACACAAAHIgCA3QAAAGgDADIgEACIgEABQgCAAgGgEIgPgOIh/B/QgFAFgGAAQgHAAgFgFIgzgzIg1A2QgFAEgHAAQgHAAgFgEg");
	this.shape.setTransform(19.3,16.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF9125").s().p("AgTBdQgGAAAAgGIAAiDIAvgwIABABIADADIAACvQAAAGgFAAg");
	this.shape_1.setTransform(29.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF9125").s().p("AgTA7QgGgBAAgFIAAg7IAGgFIAtgvIAABvQAAAFgGABg");
	this.shape_2.setTransform(22.4,27.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF9125").s().p("AgTAxQgGAAAAgFIAAhcIAbAcQAKAKAOAAIAAA2QAAAFgGAAg");
	this.shape_3.setTransform(15.1,28.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF9125").s().p("AgUAxQgFAAAAgFIAAg0QANgBAKgJIAcgeIAABcQAAAFgGAAg");
	this.shape_4.setTransform(7.9,28.9);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	this.shape_5.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0copy, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.___Camera___ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.visible = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// cameraBoundary
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(2,1,1,3,true).p("EAq+AfQMhV7AAAMAAAg+fMBV7AAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

}).prototype = p = new cjs.MovieClip();


(lib.Tween55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instr_en1 = new lib.Symbol63copy7();
	this.instr_en1.name = "instr_en1";
	this.instr_en1.parent = this;
	this.instr_en1.setTransform(153.4,63.2,0.746,0.746,0,0,0,209.1,85.6);
	new cjs.ButtonHelper(this.instr_en1, 0, 1, 1);

	this.instr_en2 = new lib.Symbol63copy9();
	this.instr_en2.name = "instr_en2";
	this.instr_en2.parent = this;
	this.instr_en2.setTransform(149.9,63,0.746,0.746,0,0,0,209.1,85.6);
	this.instr_en2.visible = false;
	new cjs.ButtonHelper(this.instr_en2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instr_en2},{t:this.instr_en1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169,-62.9,338.1,125.6);


(lib.Tween54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instr_en1 = new lib.Symbol63copy7();
	this.instr_en1.name = "instr_en1";
	this.instr_en1.parent = this;
	this.instr_en1.setTransform(153.4,63.2,0.746,0.746,0,0,0,209.1,85.6);
	new cjs.ButtonHelper(this.instr_en1, 0, 1, 1);

	this.instr_en2 = new lib.Symbol63copy9();
	this.instr_en2.name = "instr_en2";
	this.instr_en2.parent = this;
	this.instr_en2.setTransform(149.9,63,0.746,0.746,0,0,0,209.1,85.6);
	this.instr_en2.visible = false;
	new cjs.ButtonHelper(this.instr_en2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instr_en2},{t:this.instr_en1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169,-62.9,338.1,125.6);


(lib.Tween53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.ok_2 = new lib.Symbol80copy();
	this.ok_2.name = "ok_2";
	this.ok_2.parent = this;
	this.ok_2.setTransform(7,249.5,1,1,0,0,0,145.5,66.5);
	new cjs.ButtonHelper(this.ok_2, 0, 1, 1);

	this.arab_1 = new lib.Symbol67();
	this.arab_1.name = "arab_1";
	this.arab_1.parent = this;
	this.arab_1.setTransform(134,-246.5,1,1,0,0,0,141.5,55.5);
	new cjs.ButtonHelper(this.arab_1, 0, 1, 1);

	this.eng_1 = new lib.Symbol66();
	this.eng_1.name = "eng_1";
	this.eng_1.parent = this;
	this.eng_1.setTransform(-136,-246,1,1,0,0,0,139.5,52);
	new cjs.ButtonHelper(this.eng_1, 0, 1, 1);

	this.colos_bt2 = new lib.Symbol65copy();
	this.colos_bt2.name = "colos_bt2";
	this.colos_bt2.parent = this;
	this.colos_bt2.setTransform(-9.7,80.3,0.724,0.724,0,0,0,207.6,83.5);
	new cjs.ButtonHelper(this.colos_bt2, 0, 1, 1);

	this.fulsc_1 = new lib.Symbol63copy3();
	this.fulsc_1.name = "fulsc_1";
	this.fulsc_1.parent = this;
	this.fulsc_1.setTransform(-10.8,-18.2,0.724,0.724,0,0,0,209,85.5);
	new cjs.ButtonHelper(this.fulsc_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.fulsc_1},{t:this.colos_bt2},{t:this.eng_1},{t:this.arab_1},{t:this.ok_2}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286.5,-309,579,611);


(lib.Tween52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.ok_2 = new lib.Symbol80copy();
	this.ok_2.name = "ok_2";
	this.ok_2.parent = this;
	this.ok_2.setTransform(7,249.5,1,1,0,0,0,145.5,66.5);
	new cjs.ButtonHelper(this.ok_2, 0, 1, 1);

	this.arab_1 = new lib.Symbol67();
	this.arab_1.name = "arab_1";
	this.arab_1.parent = this;
	this.arab_1.setTransform(134,-246.5,1,1,0,0,0,141.5,55.5);
	new cjs.ButtonHelper(this.arab_1, 0, 1, 1);

	this.eng_1 = new lib.Symbol66();
	this.eng_1.name = "eng_1";
	this.eng_1.parent = this;
	this.eng_1.setTransform(-136,-246,1,1,0,0,0,139.5,52);
	new cjs.ButtonHelper(this.eng_1, 0, 1, 1);

	this.colos_bt2 = new lib.Symbol65copy();
	this.colos_bt2.name = "colos_bt2";
	this.colos_bt2.parent = this;
	this.colos_bt2.setTransform(-9.7,80.3,0.724,0.724,0,0,0,207.6,83.5);
	new cjs.ButtonHelper(this.colos_bt2, 0, 1, 1);

	this.fulsc_1 = new lib.Symbol63copy3();
	this.fulsc_1.name = "fulsc_1";
	this.fulsc_1.parent = this;
	this.fulsc_1.setTransform(-10.8,-18.2,0.724,0.724,0,0,0,209,85.5);
	new cjs.ButtonHelper(this.fulsc_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.fulsc_1},{t:this.colos_bt2},{t:this.eng_1},{t:this.arab_1},{t:this.ok_2}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286.5,-309,579,611);


(lib.Tween49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.ok_1 = new lib.Symbol80();
	this.ok_1.name = "ok_1";
	this.ok_1.parent = this;
	this.ok_1.setTransform(7,243,1,1,0,0,0,145.5,66.5);
	new cjs.ButtonHelper(this.ok_1, 0, 1, 1);

	this.arab_1 = new lib.Symbol67();
	this.arab_1.name = "arab_1";
	this.arab_1.parent = this;
	this.arab_1.setTransform(134,-254,1,1,0,0,0,141.5,55.5);
	new cjs.ButtonHelper(this.arab_1, 0, 1, 1);

	this.eng_1 = new lib.Symbol66();
	this.eng_1.name = "eng_1";
	this.eng_1.parent = this;
	this.eng_1.setTransform(-136,-253.5,1,1,0,0,0,139.5,52);
	new cjs.ButtonHelper(this.eng_1, 0, 1, 1);

	this.colos_bt1 = new lib.Symbol65();
	this.colos_bt1.name = "colos_bt1";
	this.colos_bt1.parent = this;
	this.colos_bt1.setTransform(2,73.9,0.627,0.627,0,0,0,207.6,83.5);
	new cjs.ButtonHelper(this.colos_bt1, 0, 1, 1);

	this.fulscen_1 = new lib.Symbol63();
	this.fulscen_1.name = "fulscen_1";
	this.fulscen_1.parent = this;
	this.fulscen_1.setTransform(-0.8,-30.3,0.627,0.627,0,0,0,209.1,85.5);
	new cjs.ButtonHelper(this.fulscen_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.fulscen_1},{t:this.colos_bt1},{t:this.eng_1},{t:this.arab_1},{t:this.ok_1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286.5,-316.5,579,626);


(lib.Tween44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.ok_1 = new lib.Symbol80();
	this.ok_1.name = "ok_1";
	this.ok_1.parent = this;
	this.ok_1.setTransform(7,243,1,1,0,0,0,145.5,66.5);
	new cjs.ButtonHelper(this.ok_1, 0, 1, 1);

	this.arab_1 = new lib.Symbol67();
	this.arab_1.name = "arab_1";
	this.arab_1.parent = this;
	this.arab_1.setTransform(134,-254,1,1,0,0,0,141.5,55.5);
	new cjs.ButtonHelper(this.arab_1, 0, 1, 1);

	this.eng_1 = new lib.Symbol66();
	this.eng_1.name = "eng_1";
	this.eng_1.parent = this;
	this.eng_1.setTransform(-136,-253.5,1,1,0,0,0,139.5,52);
	new cjs.ButtonHelper(this.eng_1, 0, 1, 1);

	this.colos_bt1 = new lib.Symbol65();
	this.colos_bt1.name = "colos_bt1";
	this.colos_bt1.parent = this;
	this.colos_bt1.setTransform(2,73.9,0.627,0.627,0,0,0,207.6,83.5);
	new cjs.ButtonHelper(this.colos_bt1, 0, 1, 1);

	this.fulscen_1 = new lib.Symbol63();
	this.fulscen_1.name = "fulscen_1";
	this.fulscen_1.parent = this;
	this.fulscen_1.setTransform(-0.8,-30.3,0.627,0.627,0,0,0,209.1,85.5);
	new cjs.ButtonHelper(this.fulscen_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.fulscen_1},{t:this.colos_bt1},{t:this.eng_1},{t:this.arab_1},{t:this.ok_1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286.5,-316.5,579,626);


(lib.Tween24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instr_1 = new lib.Symbol63copy6();
	this.instr_1.name = "instr_1";
	this.instr_1.parent = this;
	this.instr_1.setTransform(147.8,8.9,0.725,0.725,0,0,0,209.2,85.5);
	new cjs.ButtonHelper(this.instr_1, 0, 1, 1);

	this.instr_2 = new lib.Symbol63copy4();
	this.instr_2.name = "instr_2";
	this.instr_2.parent = this;
	this.instr_2.setTransform(147.5,8.8,0.725,0.725,0,0,0,209.1,85.7);
	this.instr_2.visible = false;
	new cjs.ButtonHelper(this.instr_2, 0, 1, 1);

	this.fulscen_2 = new lib.Symbol63copy();
	this.fulscen_2.name = "fulscen_2";
	this.fulscen_2.parent = this;
	this.fulscen_2.setTransform(1.6,51.3,0.627,0.627,0,0,0,209.1,85.5);
	this.fulscen_2.visible = false;
	new cjs.ButtonHelper(this.fulscen_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.fulscen_2},{t:this.instr_2},{t:this.instr_1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-156.3,-107.7,312.7,215.4);


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instr_1 = new lib.Symbol63copy6();
	this.instr_1.name = "instr_1";
	this.instr_1.parent = this;
	this.instr_1.setTransform(147.8,8.9,0.725,0.725,0,0,0,209.2,85.5);
	new cjs.ButtonHelper(this.instr_1, 0, 1, 1);

	this.instr_2 = new lib.Symbol63copy4();
	this.instr_2.name = "instr_2";
	this.instr_2.parent = this;
	this.instr_2.setTransform(147.5,8.8,0.725,0.725,0,0,0,209.1,85.7);
	this.instr_2.visible = false;
	new cjs.ButtonHelper(this.instr_2, 0, 1, 1);

	this.fulscen_2 = new lib.Symbol63copy();
	this.fulscen_2.name = "fulscen_2";
	this.fulscen_2.parent = this;
	this.fulscen_2.setTransform(1.6,51.3,0.627,0.627,0,0,0,209.1,85.5);
	this.fulscen_2.visible = false;
	new cjs.ButtonHelper(this.fulscen_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.fulscen_2},{t:this.instr_2},{t:this.instr_1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-156.3,-107.7,312.7,215.4);


(lib.Symbol84 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_1
	this.instance = new lib.Tween14("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(62.5,20.9);

	this.instance_1 = new lib.Tween18("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(62.5,20.9,1.122,1.122);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,scaleX:1.12,scaleY:1.12},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,125.1,41.7);


(lib.Symbol61 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("موافق", "21px 'Arial'", "#2C3186");
	this.text.textAlign = "center";
	this.text.lineHeight = 34;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(0,-29.1,1.796,1.796);

	this.instance = new lib.Symbol84();
	this.instance.parent = this;
	this.instance.setTransform(0.3,0.7,1.796,1.796,0,0,0,62.7,21.2);
	this.instance.filters = [new cjs.ColorFilter(0.51, 0.51, 0.51, 1, 58.8, 112.7, 38.22, 0)];
	this.instance.cache(-2,-2,129,46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.2,-37.4,224.6,74.9);


(lib.Symbol59_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("إبدأ الاختبار الان", "19px 'Arial'", "#330000");
	this.text.textAlign = "center";
	this.text.lineHeight = 35;
	this.text.lineWidth = 165;
	this.text.parent = this;
	this.text.setTransform(5.4,-29.9,1.755,1.755);

	this.instance = new lib.Tween14("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,2.581,2.581);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{scaleX:2.581,scaleY:2.581}},{t:this.text,p:{scaleX:1.755,scaleY:1.755,x:5.4,y:-29.9,color:"#330000"}}]}).to({state:[{t:this.instance,p:{scaleX:2.86,scaleY:2.86}},{t:this.text,p:{scaleX:1.945,scaleY:1.945,x:6,y:-33.1,color:"#006600"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-161.3,-53.8,322.9,107.6);


(lib.Symbol42copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_3();
	this.instance.parent = this;
	this.instance.setTransform(22.8,4.6,1,1,0,0,0,19.5,3.6);
	this.instance.alpha = 0.129;

	this.instance_1 = new lib.Path_2copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(9.4,37.3,1,1,0,0,0,7.3,12.3);
	this.instance_1.alpha = 0.602;

	this.instance_2 = new lib.Path_0copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(39.2,49.9);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.Path_1copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(24.3,49.1,1,1,0,0,0,14.7,0.8);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.Group_1copy4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(22.8,25.5,1,1,0,0,0,22.8,25.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42copy2, new cjs.Rectangle(0,0,45.6,51.1), null);


(lib.Symbol42copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_3();
	this.instance.parent = this;
	this.instance.setTransform(22.8,4.6,1,1,0,0,0,19.5,3.6);
	this.instance.alpha = 0.129;

	this.instance_1 = new lib.Path_2copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(9.4,37.3,1,1,0,0,0,7.3,12.3);
	this.instance_1.alpha = 0.602;

	this.instance_2 = new lib.Path_0copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(39.2,49.9);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.Path_1copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(24.3,49.1,1,1,0,0,0,14.7,0.8);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.Group_1copy4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(22.8,25.5,1,1,0,0,0,22.8,25.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42copy, new cjs.Rectangle(0,0,45.6,51.1), null);


(lib.Symbol31copy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_10 = function() {
		this.stop();
		//exportRoot.myhand.visible = true;
		exportRoot.myhand.visible = true;
		
		//exportRoot.text_1.gotoAndStop(1);
		
		/*exportRoot.massall.text = "125";
		exportRoot.mass.text = "50";
		exportRoot.vol.text = "50" ;
		exportRoot.dis.text = "1";
		exportRoot.materi.text = "الماء";*/
		//exportRoot.watr_2.visible = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(9).call(this.frame_10).wait(6));

	// Front_4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],79), null, new cjs.Matrix2D(0.44,0,0,0.422,-62.9,-32.2)).s().p("Ap1FDIAAqFIBsAAIAACHIAEAAIAAFfIPaAAIAAlfIAAiHIAMAAIAACHIgMAAIAMAAIAAiHICUAAIAAKFgAoFi7gAoJi7IAAiHIAEAAIAACHg");
	this.shape_2.setTransform(65,32.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).to({_off:true},15).wait(1));

	// Layer_18
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(199,221,180,0.718)").ss(1,1,1).p("ACSAAQAAAQgrALQgqAMg9AAQg8AAgrgMQgqgLAAgQQAAgPAqgMQArgLA8AAQA9AAAqALQArAMAAAPg");
	this.shape_3.setTransform(66.2,22.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C7DDB4").s().p("AhnAbQgqgLAAgQQAAgPAqgMQArgLA8AAQA9AAAqALQArAMAAAPQAAAQgrALQgqAMg9AAQg8AAgrgMg");
	this.shape_4.setTransform(66.2,22.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3}]},2).to({state:[]},8).wait(6));

	// Layer_2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(102,0,255,0.208)").s().p("AoOCtIAAlZIQdAAIAAFZg");
	this.shape_5.setTransform(63,36.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).to({_off:true},15).wait(1));

	// Layer_6
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.234,0.075,-0.075,0.234,-94.6,-136.6)).s().p("AA0CrIickKIgBgLQgCgLgLgPIgEgDQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQgCgEgGgEIgJgEIgMgGIgIgPIgKAGIgSgIIEVAAIBqC0Ih1Chg");
	this.shape_6.setTransform(125.6,-14.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.234,0.092,-0.075,0.288,-87.2,-145.6)).s().p("Ah1APIgDgBQgKgFgFgDIgLgIIgNgMIExAAIAOAdg");
	this.shape_7.setTransform(118.2,-32.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.234,0.102,-0.075,0.319,-82,-144.2)).s().p("AhrCaIggggIgMgMIAAgtIAMAAIALgMIAAhAIgJAAIAAgDIgnAAQAEgHAAgLIAMgJIgkhTIBUAAIAAgNIAAgMIACAHIANgKQABADADABQACABAGAAIAJABQAIABACgCIAMADIALADQAOAFAIgDQAJgEAEAAIAEAAIAFAAQAGgCADABIAFABIAHgEIBYDJIAggbIA4B/g");
	this.shape_8.setTransform(113.1,-49.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.234,0.024,-0.075,0.076,-63.1,-28.6)).s().p("AgVAVIgzgbIAmgHIgCgBIAhgGIBMApg");
	this.shape_9.setTransform(94.2,-66.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.234,0.059,-0.075,0.184,-65.9,-75.1)).s().p("AgjAIIgBAAIgMgQIBeAAIADAFIAAALg");
	this.shape_10.setTransform(96.9,-63.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]},2).to({state:[]},8).to({state:[]},2).wait(4));

	// Layer_7
	this.zgag_8t = new lib.Symbol41copy3();
	this.zgag_8t.name = "zgag_8t";
	this.zgag_8t.parent = this;
	this.zgag_8t.setTransform(95.7,-52.4,0.358,0.486,-90,0,0,35.9,51.7);
	this.zgag_8t._off = true;

	this.timeline.addTween(cjs.Tween.get(this.zgag_8t).wait(2).to({_off:false},0).to({_off:true},8).wait(6));

	// Layer_8
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(199,221,180,0.718)").ss(1,1,1).p("Ai7gnIgJgOABngzIBeBpIhYAAIgSgXIgNAAIjYAAIg6AAIAAgSIAJg0IEigMIBeAAIhegCg");
	this.shape_11.setTransform(97.4,-50);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C7DDB4").s().p("ABbAeIgOAAIjYAAIg5gTIAJgzIEigMIBeBpIhYAAg");
	this.shape_12.setTransform(97.4,-49.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#87BFD3").s().p("AinAdIDYAAQgVAag1AAQg2AAhYgagABKg1IBeAAIAABog");
	this.shape_13.setTransform(100.3,-49.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11}]},2).to({state:[]},8).to({state:[]},1).wait(5));

	// Layer_15 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_2 = new cjs.Graphics().p("AEjkXICDAAIAAAuIiDAAg");
	var mask_graphics_3 = new cjs.Graphics().p("AEGkeICfAAIAAFAIifAAg");
	var mask_graphics_4 = new cjs.Graphics().p("ADqkpIC6AAIAAJTIi6AAg");
	var mask_graphics_5 = new cjs.Graphics().p("ADMmzIDWAAIAANnIjWAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_2,x:42.2,y:-28}).wait(1).to({graphics:mask_graphics_3,x:42.1,y:-28.7}).wait(1).to({graphics:mask_graphics_4,x:42,y:-29.1}).wait(1).to({graphics:mask_graphics_5,x:41.8,y:-16.6}).wait(5).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_16
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(201,230,176,0.757)").ss(5,1,1).p("Ag5GFQgCjhgBg9QgBiQAIhmQAWkQBcAe");
	this.shape_14.setTransform(75.2,-12.9);
	this.shape_14._off = true;

	var maskedShapeInstanceList = [this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(2).to({_off:false},0).to({_off:true},8).wait(6));

	// Back_4
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],35), null, new cjs.Matrix2D(0.44,0,0,0.422,-61.8,-35.8)).s().p("ApqFmIAArLICAAAIAABVIPqAAIAAhVIBqAAIAALLg");
	this.shape_15.setTransform(61.9,40.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).to({_off:true},15).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127.9,76.7);


(lib.Symbol29copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],78), null, new cjs.Matrix2D(0.571,0,0,0.546,-16.2,-20.8)).s().p("AihDQIAAmfIFDAAIAAGfg");
	this.shape.setTransform(20.2,7.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiYCTIAAklIExAAIAAElg");
	mask.setTransform(19.8,13.7);

	// Layer_3
	this.instance = new lib.Path_2copy();
	this.instance.parent = this;
	this.instance.setTransform(12,21.9,0.622,0.48,0,0,0,7.3,12.3);
	this.instance.alpha = 0.602;

	this.instance_1 = new lib.Path_0copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(30.7,27.8,0.622,0.48,0,0,0,2.8,2.6);
	this.instance_1.alpha = 0.5;

	this.instance_2 = new lib.Path_1copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(21.3,27.2,0.622,0.48,0,0,0,17.5,2.7);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.Group_1copy4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(20.4,16.3,0.622,0.48,0,0,0,22.9,25.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29copy, new cjs.Rectangle(4,-13,32.4,41.6), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("معملي", "21px 'Arial'", "#FFFFFF");
	this.text.textAlign = "right";
	this.text.lineHeight = 37;
	this.text.lineWidth = 127;
	this.text.parent = this;
	this.text.setTransform(149.9,47.9,1,1,20.9);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(3));

	// Layer_3
	this.instance = new lib.Untitled2();
	this.instance.parent = this;
	this.instance.setTransform(-2,-4,0.564,0.564);

	this.instance_1 = new lib.Symbol55();
	this.instance_1.parent = this;
	this.instance_1.setTransform(96.5,58.9,1,1,0,0,0,98.5,62.9);
	this.instance_1.filters = [new cjs.ColorFilter(0.09, 0.09, 0.09, 1, 92.82, 232.05, 0, 0)];
	this.instance_1.cache(-2,-2,201,130);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,-4,196.9,125.8);


(lib.Symbol7copy7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
		
		this.vedio_1.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open("https://www.youtube.com/watch?v=vJujvGCbsso", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(1));

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_1_graphics_2 = new cjs.Graphics().p("EhJqARiMAAAgjDMCTVAAAMAAAAjDg");
	var mask_1_graphics_3 = new cjs.Graphics().p("EhL8AhoMAAAhDPMCX5AAAMAAABDPg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EhOPAxtMAAAhjZMCcfAAAMAAABjZg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_1_graphics_2,x:269.6,y:91.1}).wait(1).to({graphics:mask_1_graphics_3,x:272.3,y:191.6}).wait(1).to({graphics:mask_1_graphics_4,x:274.8,y:291.9}).wait(1));

	// Layer_4
	this.vedio_1 = new lib.Symbol68();
	this.vedio_1.name = "vedio_1";
	this.vedio_1.parent = this;
	this.vedio_1.setTransform(519.7,289.7);

	this.instance = new lib.Bitmap158();
	this.instance.parent = this;
	this.instance.setTransform(-168,147,0.782,0.782);

	var maskedShapeInstanceList = [this.vedio_1,this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance},{t:this.vedio_1}]},1).wait(4));

	// Layer_1
	this.text_2 = new cjs.Text("التجرب في المعمل التقليدي", "17px 'Arial'", "#330000");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 31;
	this.text_2.lineWidth = 256;
	this.text_2.parent = this;
	this.text_2.setTransform(248,502.7,1.755,1.755);

	this.text_3 = new cjs.Text("", "26px 'HacenSaudiArabia'", "#0000FF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 45;
	this.text_3.lineWidth = 100;
	this.text_3.parent = this;
	this.text_3.setTransform(1043.2,119.4);

	this.text_4 = new cjs.Text("التجربة من منصة فلابي", "17px 'Arial'", "#330000");
	this.text_4.textAlign = "right";
	this.text_4.lineHeight = 31;
	this.text_4.lineWidth = 256;
	this.text_4.parent = this;
	this.text_4.setTransform(748.3,502.7,1.755,1.755);

	this.text_5 = new cjs.Text("فيديوهات", "26px 'Arial'", "#E87E00");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 45;
	this.text_5.parent = this;
	this.text_5.setTransform(231.5,3.5,1.755,1.755);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape_1.setTransform(243.6,89.9);

	var maskedShapeInstanceList = [this.text_2,this.text_3,this.text_4,this.text_5,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2}]},1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.settingcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
		this.btnpro_2.addEventListener("click", clbtnpro_2.bind(this));
		function clbtnpro_2() {
			//this.proo.visible = false;
			//this.btnpro.visible = false;
			this.gotoAndStop(0);
			createjs.Sound.play("sound_1");
			//this.techer_1.gotoAndPlay(10);
			//canvas.style.cursor = "none";
		}
		
		this.startt_2.addEventListener("mousedown", fl2_ClickToGoToclic_startt_2.bind(this));
			function fl2_ClickToGoToclic_startt_2() {
				
				this.gotoAndStop(0);		
				
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_6
	this.instance = new lib.Tween26("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-694.6,377);
	this.instance._off = true;

	this.instance_1 = new lib.Tween27("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(401.4,377);

	this.text = new cjs.Text("Unit Two: Force and Motion", "63px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 113;
	this.text.lineWidth = 1091;
	this.text.parent = this;
	this.text.setTransform(444.1,462.7,0.647,0.647);

	this.text_1 = new cjs.Text("Lesson Two: Fundamental forces in nature", "63px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 113;
	this.text_1.lineWidth = 1191;
	this.text_1.parent = this;
	this.text_1.setTransform(414.6,535.9,0.647,0.647);

	this.text_2 = new cjs.Text("Second Term", "63px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 113;
	this.text_2.lineWidth = 869;
	this.text_2.parent = this;
	this.text_2.setTransform(516,334.4,0.647,0.647);

	this.text_3 = new cjs.Text("Preparatory Stage - year 1", "63px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 113;
	this.text_3.lineWidth = 876;
	this.text_3.parent = this;
	this.text_3.setTransform(513.6,242,0.647,0.647);

	this.text_4 = new cjs.Text("Fluid transport and penetration through porous membranes", "48px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 87;
	this.text_4.lineWidth = 1332;
	this.text_4.parent = this;
	this.text_4.setTransform(401.4,123.6,0.647,0.647);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},7).to({state:[{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({_off:true,x:401.4},7,cjs.Ease.quintOut).wait(2));

	// Layer_7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_2 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_3 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_4 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_5 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_6 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_7 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_8 = new cjs.Graphics().p("AvnTiQh8AAhYhYIAAAAQhYhYAAh8IAAAAIAA9rQAAh8BYhYIAAAAQBYhYB8AAIAAAAIfPAAQB8AABYBYIAAAAQBYBYAAB8IAAAAIAAdrQAAB8hYBYIAAAAQhYBYh8AAIAAAAg");
	var mask_graphics_9 = new cjs.Graphics().p("AvnTiQh8AAhYhYQhYhYAAh8IAA9rQAAh8BYhYQBYhYB8AAIfPAAQB8AABYBYQBYBYAAB8IAAdrQAAB8hYBYQhYBYh8AAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-1013,y:334}).wait(1).to({graphics:mask_graphics_2,x:-856.4,y:334}).wait(1).to({graphics:mask_graphics_3,x:-699.9,y:334}).wait(1).to({graphics:mask_graphics_4,x:-543.3,y:334}).wait(1).to({graphics:mask_graphics_5,x:-386.7,y:334}).wait(1).to({graphics:mask_graphics_6,x:-230.1,y:334}).wait(1).to({graphics:mask_graphics_7,x:-73.6,y:334}).wait(1).to({graphics:mask_graphics_8,x:83,y:334}).wait(1).to({graphics:mask_graphics_9,x:83,y:334}).wait(1));

	// Layer_4
	this.instance_2 = new lib.Tween30("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1017.5,332.8);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween31("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(78.5,332.8);

	this.instance_4 = new lib.expr_1_2_10();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-49,199,0.662,0.662);

	var maskedShapeInstanceList = [this.instance_2,this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},7).to({state:[{t:this.instance_4}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({_off:true,x:78.5},7,cjs.Ease.quartOut).wait(2));

	// Layer_3
	this.btnpro_2 = new lib.Symbol81();
	this.btnpro_2.name = "btnpro_2";
	this.btnpro_2.parent = this;
	this.btnpro_2.setTransform(-707,673,1,1,0,0,0,176,70);
	this.btnpro_2._off = true;
	new cjs.ButtonHelper(this.btnpro_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.btnpro_2).wait(1).to({_off:false},0).to({x:389},7,cjs.Ease.quartOut).wait(2));

	// Layer_1
	this.instance_5 = new lib.Tween32("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-709,400);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween33("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(387,400);
	this.instance_6.alpha = 0.801;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},7).to({state:[{t:this.instance_6}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({_off:false},0).to({_off:true,x:387,alpha:0.801},7,cjs.Ease.quartOut).wait(2));

	// Layer_9
	this.startt_2 = new lib.Symbol82();
	this.startt_2.name = "startt_2";
	this.startt_2.parent = this;
	this.startt_2.setTransform(374.3,409.4,1,1,0,0,0,664.3,409.3);
	this.startt_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.startt_2).wait(9).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.settingcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
		
		this.btnpro_1.addEventListener("click", clbtnpro_1.bind(this));
		function clbtnpro_1() {
			//this.proo.visible = false;
			//this.btnpro.visible = false;
			this.gotoAndStop(0);
			createjs.Sound.play("sound_1");
			//this.techer_1.gotoAndPlay(10);
			//canvas.style.cursor = "none";
		}
		
		this.startt_1.addEventListener("mousedown", fl2_ClickToGoToclic_startt_1.bind(this));
			function fl2_ClickToGoToclic_startt_1() {
				
				this.gotoAndStop(0);		
				
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_6
	this.instance = new lib.Tween34("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-692.6,359.9);
	this.instance._off = true;

	this.instance_1 = new lib.Tween35("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(390.4,359.9);

	this.text = new cjs.Text("", "64px 'AraAsmaaBeltajie-Regular'");
	this.text.textAlign = "center";
	this.text.lineHeight = 115;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(1132.9,392.1);

	this.text_1 = new cjs.Text("الدرس الأولى : المادة وخواصها", "63px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 113;
	this.text_1.lineWidth = 1091;
	this.text_1.parent = this;
	this.text_1.setTransform(444.1,462.7,0.647,0.647);

	this.text_2 = new cjs.Text(" الوحدة الأولى : المادة وتركيبها", "63px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 113;
	this.text_2.lineWidth = 1047;
	this.text_2.parent = this;
	this.text_2.setTransform(444.1,544.1,0.647,0.647);

	this.text_3 = new cjs.Text("الفصل الدراسي الأول", "63px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 113;
	this.text_3.lineWidth = 869;
	this.text_3.parent = this;
	this.text_3.setTransform(516,334.4,0.647,0.647);

	this.text_4 = new cjs.Text("الصف الأول الأعدادي", "63px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 113;
	this.text_4.lineWidth = 876;
	this.text_4.parent = this;
	this.text_4.setTransform(513.6,242,0.647,0.647);

	this.text_5 = new cjs.Text("تجربة للمقارنة بين كثافة بعض المواد وكثافة الماء", "64px 'Arial'");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 115;
	this.text_5.lineWidth = 1332;
	this.text_5.parent = this;
	this.text_5.setTransform(390.4,110.6,0.647,0.647);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},7).to({state:[{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({_off:true,x:390.4},7,cjs.Ease.quintOut).wait(2));

	// Layer_7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhTlgDMIfQAAQAqAAAmALQAmAKAhAUQAiAUAbAbQAbAbAUAiQAUAhAKAlQALAmAAAqIAAdsQAAAqgLAmQgKAmgUAhQgUAigbAbQgbAbgiAUQghAUgmAKQgmALgqAAI/QAAQg/AAg2gYQg2gXgpgpQgpgpgXg2QgYg2AAg/IAA9sQAAgqALgmQAKglAUghQAUgiAbgbQAbgbAigUQAhgUAmgKQAmgLAqAAg");
	var mask_graphics_2 = new cjs.Graphics().p("Eg/7gDMIfQAAQApAAAmALQAnAKAhAUQAhAUAcAbQAbAbAUAiQATAhALAlQAKAmABAqIAAdsQgBAqgKAmQgLAmgTAhQgUAigbAbQgcAbghAUQghAUgnAKQgmALgpAAI/QAAQg/AAg2gYQg2gXgqgpQgpgpgXg2QgXg2AAg/IAA9sQAAgqAKgmQALglAUghQATgiAbgbQAcgbAhgUQAigUAmgKQAmgLAqAAg");
	var mask_graphics_3 = new cjs.Graphics().p("EguzgDMIfQAAQApAAAnALQAmAKAhAUQAiAUAbAbQAbAbAUAiQAUAhAKAlQALAmAAAqIAAdsQAAAqgLAmQgKAmgUAhQgUAigbAbQgbAbgiAUQghAUgmAKQgnALgpAAI/QAAQg/AAg2gYQg2gXgpgpQgpgpgYg2QgXg2AAg/IAA9sQAAgqALgmQAKglAUghQATgiAcgbQAbgbAhgUQAigUAmgKQAmgLAqAAg");
	var mask_graphics_4 = new cjs.Graphics().p("EggMgDMIfQAAQApAAAmALQAmAKAhAUQAiAUAbAbQAbAbAUAiQATAhALAlQALAmAAAqIAAdsQAAAqgLAmQgLAmgTAhQgUAigbAbQgbAbgiAUQghAUgmAKQgmALgpAAI/QAAQg/AAg2gYQg2gXgpgpQgpgpgYg2QgXg2AAg/IAA9sQAAgqAKgmQALglAUghQATgiAcgbQAbgbAhgUQAigUAmgKQAmgLAqAAg");
	var mask_graphics_5 = new cjs.Graphics().p("A0HjMIfPAAQAqAAAmALQAmAKAiAUQAhAUAbAbQAcAbATAiQAUAhALAlQAKAmAAAqIAAdsQAAAqgKAmQgLAmgUAhQgTAigcAbQgbAbghAUQgiAUgmAKQgmALgqAAI/PAAQg+AAg2gYQg3gXgpgpQgpgpgXg2QgXg2gBg/IAA9sQAAgqALgmQALglATghQAUgiAbgbQAbgbAigUQAhgUAngKQAmgLApAAg");
	var mask_graphics_6 = new cjs.Graphics().p("AvnjMIfPAAQAqAAAmALQAmAKAhAUQAiAUAbAbQAbAbAUAiQAUAhAKAlQALAmAAAqIAAdsQAAAqgLAmQgKAmgUAhQgUAigbAbQgbAbgiAUQghAUgmAKQgmALgqAAI/PAAQg/AAg2gYQg2gXgpgpQgpgpgXg2QgYg2AAg/IAA9sQAAgqALgmQAKglAUghQAUgiAbgbQAbgbAigUQAhgUAmgKQAmgLAqAAg");
	var mask_graphics_7 = new cjs.Graphics().p("AvnjMIfPAAQAqAAAmALQAmAKAhAUQAiAUAbAbQAbAbAUAiQAUAhAKAlQALAmAAAqIAAdsQAAAqgLAmQgKAmgUAhQgUAigbAbQgbAbgiAUQghAUgmAKQgmALgqAAI/PAAQg/AAg2gYQg2gXgpgpQgpgpgXg2QgYg2AAg/IAA9sQAAgqALgmQAKglAUghQAUgiAbgbQAbgbAigUQAhgUAmgKQAmgLAqAAg");
	var mask_graphics_8 = new cjs.Graphics().p("AvnjMIfPAAQAqAAAmALQAmAKAhAUQAiAUAbAbQAbAbAUAiQAUAhAKAlQALAmAAAqIAAdsQAAAqgLAmQgKAmgUAhQgUAigbAbQgbAbgiAUQghAUgmAKQgmALgqAAI/PAAQg/AAg2gYQg2gXgpgpQgpgpgXg2QgYg2AAg/IAA9sQAAgqALgmQAKglAUghQAUgiAbgbQAbgbAigUQAhgUAmgKQAmgLAqAAg");
	var mask_graphics_9 = new cjs.Graphics().p("AvnjMIfPAAQAqAAAmALQAmAKAhAUQAiAUAbAbQAbAbAUAiQAUAhAKAlQALAmAAAqIAAdsQAAAqgLAmQgKAmgUAhQgUAigbAbQgbAbgiAUQghAUgmAKQgmALgqAAI/PAAQg/AAg2gYQg2gXgpgpQgpgpgXg2QgYg2AAg/IAA9sQAAgqALgmQAKglAUghQAUgiAbgbQAbgbAigUQAhgUAmgKQAmgLAqAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-565,y:229.5}).wait(1).to({graphics:mask_graphics_2,x:-439.2,y:229.5}).wait(1).to({graphics:mask_graphics_3,x:-329.6,y:229.5}).wait(1).to({graphics:mask_graphics_4,x:-236.1,y:229.5}).wait(1).to({graphics:mask_graphics_5,x:-158.8,y:229.5}).wait(1).to({graphics:mask_graphics_6,x:-65.1,y:229.5}).wait(1).to({graphics:mask_graphics_7,x:25.1,y:229.5}).wait(1).to({graphics:mask_graphics_8,x:83,y:229.5}).wait(1).to({graphics:mask_graphics_9,x:83,y:229.5}).wait(1));

	// Layer_4
	this.instance_2 = new lib.Tween38("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1004.5,332.8);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween39("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(78.5,332.8);

	this.instance_4 = new lib.expr_1_2_10();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-49,199,0.662,0.662);

	var maskedShapeInstanceList = [this.instance_2,this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},7).to({state:[{t:this.instance_4}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({_off:true,x:78.5},7,cjs.Ease.quintOut).wait(2));

	// Layer_3
	this.instance_5 = new lib.Tween40("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-696,680);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween41("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(387,680);

	this.btnpro_1 = new lib.Symbol83();
	this.btnpro_1.name = "btnpro_1";
	this.btnpro_1.parent = this;
	this.btnpro_1.setTransform(387,680,1,1,0,0,0,164,70);
	new cjs.ButtonHelper(this.btnpro_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},7).to({state:[{t:this.btnpro_1}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({_off:false},0).to({_off:true,x:387},7,cjs.Ease.quintOut).wait(2));

	// Layer_1
	this.instance_7 = new lib.Tween42("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(-696,400);
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween43("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(387,400);

	this.instance_9 = new lib.backkk23232pngcopy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-132,13);

	this.instance_10 = new lib.backkk();
	this.instance_10.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},7).to({state:[{t:this.instance_10},{t:this.instance_9}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({_off:false},0).to({_off:true,x:387},7,cjs.Ease.quintOut).wait(2));

	// Layer_9
	this.startt_1 = new lib.Symbol82();
	this.startt_1.name = "startt_1";
	this.startt_1.parent = this;
	this.startt_1.setTransform(374.3,409.4,1,1,0,0,0,664.3,409.3);
	this.startt_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.startt_1).wait(9).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Scene_1_vedio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// vedio
	this.borden_7 = new lib.Symbol7copy7();
	this.borden_7.name = "borden_7";
	this.borden_7.parent = this;
	this.borden_7.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);

	this.timeline.addTween(cjs.Tween.get(this.borden_7).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_vedio, null, null);


(lib.Scene_1_tools_hagb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// tools_hagb
	this.instance = new lib.Symbol25();
	this.instance.parent = this;
	this.instance.setTransform(1655.1,365,1,1.082,0,0,0,445.1,245);
	this.instance.alpha = 0.039;
	this.instance.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_tools_hagb, null, null);


(lib.Scene_1_tools_bnt2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// tools_bnt2
	this.textbnt_1 = new lib.Symbol51();
	this.textbnt_1.name = "textbnt_1";
	this.textbnt_1.parent = this;
	this.textbnt_1.setTransform(1763.5,715.1,0.598,0.598,0,0,0,270.1,37.5);

	this.timeline.addTween(cjs.Tween.get(this.textbnt_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_tools_bnt2, null, null);


(lib.Scene_1_tools = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// tools
	this.borden_1 = new lib.Symbol7copy9();
	this.borden_1.name = "borden_1";
	this.borden_1.parent = this;
	this.borden_1.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);
	this.borden_1.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.borden_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_tools, null, null);


(lib.Scene_1_test = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// test
	this.borden_5 = new lib.Symbol7copy4();
	this.borden_5.name = "borden_5";
	this.borden_5.parent = this;
	this.borden_5.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);

	this.timeline.addTween(cjs.Tween.get(this.borden_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_test, null, null);


(lib.Scene_1_steps = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// steps
	this.borden_2 = new lib.Symbol7copy8();
	this.borden_2.name = "borden_2";
	this.borden_2.parent = this;
	this.borden_2.setTransform(-397.9,138.8,0.598,0.598);

	this.timeline.addTween(cjs.Tween.get(this.borden_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_steps, null, null);


(lib.Scene_1_sabora_tol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sabora_tol
	this.instance = new lib.Layer0copy();
	this.instance.parent = this;
	this.instance.setTransform(-689,511,0.881,0.881);

	this.instance_1 = new lib.Symbol5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-653.5,521.5,1.05,1.049,0,0,0,6.7,44);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.instance_2 = new lib.Symbol4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-667.7,519.6,1.05,1.049,0,0,0,5.1,44.1);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 1);

	this.instance_3 = new lib.Symbol3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-671.3,523.1,1.05,1.049,0,0,0,16.7,42.3);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 1);

	this.instance_4 = new lib.Symbol2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-643.4,519.1,1.05,1.049,0,0,0,7.3,43.6);
	new cjs.ButtonHelper(this.instance_4, 0, 1, 1);

	this.instance_5 = new lib.Symbol1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-635.8,522.3,1.05,1.049,0,0,0,14.5,42.7);
	new cjs.ButtonHelper(this.instance_5, 0, 1, 1);

	this.instance_6 = new lib.Vlaby_board0peثn();
	this.instance_6.parent = this;
	this.instance_6.setTransform(65.2,533,1.049,1.05,90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_sabora_tol, null, null);


(lib.Scene_1_put_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// put_1
	this.term_point = new lib.point7();
	this.term_point.name = "term_point";
	this.term_point.parent = this;
	this.term_point.setTransform(638.4,377,1,1,0,0,0,-62.5,-10);
	this.term_point.visible = false;
	new cjs.ButtonHelper(this.term_point, 0, 1, 1);

	this.myput_1 = new lib.myput();
	this.myput_1.name = "myput_1";
	this.myput_1.parent = this;
	this.myput_1.setTransform(620.6,604.2,0.794,0.826,0,0,0,45.7,15.8);
	this.myput_1.alpha = 0.52;
	this.myput_1.visible = false;
	new cjs.ButtonHelper(this.myput_1, 0, 1, 1);

	this.myput_hod = new lib.myput();
	this.myput_hod.name = "myput_hod";
	this.myput_hod.parent = this;
	this.myput_hod.setTransform(313.2,605.2,0.794,0.826,0,0,0,45.7,15.8);
	this.myput_hod.alpha = 0.52;
	this.myput_hod.visible = false;
	new cjs.ButtonHelper(this.myput_hod, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.myput_hod},{t:this.myput_1},{t:this.term_point}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_put_1, null, null);


(lib.Scene_1_navig_ar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// navig_ar
	this.maemly2 = new lib.Symbol16();
	this.maemly2.name = "maemly2";
	this.maemly2.parent = this;
	this.maemly2.setTransform(65,129.8,1.047,1.047,0,0,0,92.3,59.9);
	this.maemly2.visible = false;
	new cjs.ButtonHelper(this.maemly2, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.maemly2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_navig_ar, null, null);


(lib.Scene_1_links = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// links
	this.borden_6 = new lib.Symbol7copy5_1();
	this.borden_6.name = "borden_6";
	this.borden_6.parent = this;
	this.borden_6.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);

	this.timeline.addTween(cjs.Tween.get(this.borden_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_links, null, null);


(lib.Scene_1_Layer_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_15
	this.myput_5 = new lib.myput();
	this.myput_5.name = "myput_5";
	this.myput_5.parent = this;
	this.myput_5.setTransform(612.9,391.8,0.389,0.404,0,0,0,46,16.1);
	this.myput_5.alpha = 0.52;
	this.myput_5.visible = false;
	new cjs.ButtonHelper(this.myput_5, 0, 1, 1);

	this.myput_4 = new lib.myput();
	this.myput_4.name = "myput_4";
	this.myput_4.parent = this;
	this.myput_4.setTransform(608.3,428,0.389,0.404,0,0,0,46,16.1);
	this.myput_4.alpha = 0.52;
	this.myput_4.visible = false;
	new cjs.ButtonHelper(this.myput_4, 0, 1, 1);

	this.myput_3 = new lib.myput();
	this.myput_3.name = "myput_3";
	this.myput_3.parent = this;
	this.myput_3.setTransform(612.2,488.1,0.415,0.431,0,0,0,45.9,16);
	this.myput_3.alpha = 0.52;
	this.myput_3.visible = false;
	new cjs.ButtonHelper(this.myput_3, 0, 1, 1);

	this.myput_2 = new lib.myput();
	this.myput_2.name = "myput_2";
	this.myput_2.parent = this;
	this.myput_2.setTransform(624.5,581.4,0.415,0.431,0,0,0,45.9,16);
	this.myput_2.alpha = 0.52;
	this.myput_2.visible = false;
	new cjs.ButtonHelper(this.myput_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.myput_2},{t:this.myput_3},{t:this.myput_4},{t:this.myput_5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_15, null, null);


(lib.Scene_1_Layer_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.resetButton2 = new lib.Symbol68_1();
	this.resetButton2.name = "resetButton2";
	this.resetButton2.parent = this;
	this.resetButton2.setTransform(1091.4,666.9,0.998,0.998,0,0,0,20,17.4);
	this.resetButton2.visible = false;
	new cjs.ButtonHelper(this.resetButton2, 0, 1, 1);

	this.resetButton3 = new lib.Symbol67_1();
	this.resetButton3.name = "resetButton3";
	this.resetButton3.parent = this;
	this.resetButton3.setTransform(1091.4,667,0.998,0.998,0,0,0,20,17.4);
	this.resetButton3.visible = false;
	new cjs.ButtonHelper(this.resetButton3, 0, 1, 1);

	this.upButton = new lib.Symbol63_1();
	this.upButton.name = "upButton";
	this.upButton.parent = this;
	this.upButton.setTransform(1090.1,635.9,0.998,0.998,0,0,0,42,24.4);
	this.upButton.visible = false;
	new cjs.ButtonHelper(this.upButton, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.upButton},{t:this.resetButton3},{t:this.resetButton2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_3, null, null);


(lib.Scene_1_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.settng = new lib.Symbol62();
	this.settng.name = "settng";
	this.settng.parent = this;
	this.settng.setTransform(1045.5,-32.8);

	this.timeline.addTween(cjs.Tween.get(this.settng).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_2, null, null);


(lib.Scene_1_introd_En = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// introd_En
	this.intro_en = new lib.settingcopy2();
	this.intro_en.name = "intro_en";
	this.intro_en.parent = this;
	this.intro_en.setTransform(679.7,393.9,0.789,0.789,0,0,0,411.7,400.3);

	this.timeline.addTween(cjs.Tween.get(this.intro_en).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_introd_En, null, null);


(lib.Scene_1_introd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// introd
	this.intro_ar = new lib.settingcopy();
	this.intro_ar.name = "intro_ar";
	this.intro_ar.parent = this;
	this.intro_ar.setTransform(679.7,393.9,0.789,0.789,0,0,0,411.7,400.3);

	this.timeline.addTween(cjs.Tween.get(this.intro_ar).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_introd, null, null);


(lib.Scene_1_hanfia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hanfia
	this.hanfi_1 = new lib.Symbol6();
	this.hanfi_1.name = "hanfi_1";
	this.hanfi_1.parent = this;
	this.hanfi_1.setTransform(250.3,484.5,1.05,1.049,0,0,0,71.5,106.9);

	this.instance = new lib.صيصيصي();
	this.instance.parent = this;
	this.instance.setTransform(260,578,1.05,1.049);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.hanfi_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_hanfia, null, null);


(lib.Scene_1_concol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// concol
	this.borden_3 = new lib.Symbol7copy6();
	this.borden_3.name = "borden_3";
	this.borden_3.parent = this;
	this.borden_3.setTransform(-398.8,138.2,0.598,0.598,0,0,0,-1.4,-0.9);

	this.timeline.addTween(cjs.Tween.get(this.borden_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_concol, null, null);


(lib.Scene_1_back_color = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// back_color
	this.yy = new lib.Symbol2copy();
	this.yy.name = "yy";
	this.yy.parent = this;
	this.yy.setTransform(180.6,142.3,1,1,0,0,0,180.6,142.3);

	this.timeline.addTween(cjs.Tween.get(this.yy).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_back_color, null, null);


(lib.Scene_1_فيديوهات = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// فيديوهات
	this.bord_7 = new lib.Symbol7copy7_1();
	this.bord_7.name = "bord_7";
	this.bord_7.parent = this;
	this.bord_7.setTransform(-397.9,138.8,0.598,0.598);

	this.timeline.addTween(cjs.Tween.get(this.bord_7).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_فيديوهات, null, null);


(lib.Scene_1_active = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// active
	this.borden_4 = new lib.Symbol7copy3();
	this.borden_4.name = "borden_4";
	this.borden_4.parent = this;
	this.borden_4.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);

	this.timeline.addTween(cjs.Tween.get(this.borden_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_active, null, null);


(lib.Scene_1_روابط_خارجية = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// روابط_خارجية
	this.bord_6 = new lib.Symbol7copy5();
	this.bord_6.name = "bord_6";
	this.bord_6.parent = this;
	this.bord_6.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);

	this.timeline.addTween(cjs.Tween.get(this.bord_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_روابط_خارجية, null, null);


(lib.Scene_1_خطوات_التجربة = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// خطوات_التجربة
	this.bord_2 = new lib.Symbol7copy();
	this.bord_2.name = "bord_2";
	this.bord_2.parent = this;
	this.bord_2.setTransform(-397.9,138.8,0.598,0.598);

	this.timeline.addTween(cjs.Tween.get(this.bord_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_خطوات_التجربة, null, null);


(lib.Scene_1_الاستنتاج = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// الاستنتاج
	this.bord_3 = new lib.Symbol7copy2();
	this.bord_3.name = "bord_3";
	this.bord_3.parent = this;
	this.bord_3.setTransform(-398.8,138.2,0.598,0.598,0,0,0,-1.4,-0.9);

	this.timeline.addTween(cjs.Tween.get(this.bord_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_الاستنتاج, null, null);


(lib.Symbol42copy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_5 = new lib.Path_3copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(22.8,4.6,1,1,0,0,0,19.5,3.6);
	this.instance_5.alpha = 0.129;

	this.instance_6 = new lib.Path_2copy5();
	this.instance_6.parent = this;
	this.instance_6.setTransform(9.4,37.3,1,1,0,0,0,7.3,12.3);
	this.instance_6.alpha = 0.602;

	this.instance_7 = new lib.Path_0copy4();
	this.instance_7.parent = this;
	this.instance_7.setTransform(39.2,49.9);
	this.instance_7.alpha = 0.5;

	this.instance_8 = new lib.Path_1copy3();
	this.instance_8.parent = this;
	this.instance_8.setTransform(24.3,49.1,1,1,0,0,0,14.7,0.8);
	this.instance_8.alpha = 0.5;

	this.instance_9 = new lib.Group_1copy7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(22.8,25.5,1,1,0,0,0,22.8,25.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42copy_1, new cjs.Rectangle(0,0,45.6,51.1), null);


(lib.Symbol42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_3();
	this.instance.parent = this;
	this.instance.setTransform(22.8,4.6,1,1,0,0,0,19.5,3.6);
	this.instance.alpha = 0.129;

	this.instance_1 = new lib.Path_2copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(9.4,37.3,1,1,0,0,0,7.3,12.3);
	this.instance_1.alpha = 0.602;

	this.instance_2 = new lib.Path_0copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(39.2,49.9);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.Path_1copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(24.3,49.1,1,1,0,0,0,14.7,0.8);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.Group_1copy4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(22.8,25.5,1,1,0,0,0,22.8,25.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42, new cjs.Rectangle(0,0,45.6,51.1), null);


(lib.Symbol41copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_1
	this.instance = new lib.Front();
	this.instance.parent = this;
	this.instance.setTransform(11,13);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(6));

	// Layer_5
	this.instance_1 = new lib.Pathcopy3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(34,29.2,1,1,0,0,0,7.7,0.5);
	this.instance_1.alpha = 0.5;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#42210B").s().p("AhEALQgdgEAAgHQAAgFAdgEQAdgFAnAAQAoAAAeAFQAcAEAAAFQAAAHgcAEQgdAEgpAAQgoAAgcgEg");
	this.shape.setTransform(34.6,29.2);

	this.instance_2 = new lib.Groupcopy3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(43.9,15.3,1,1,0,0,0,1.9,14.4);
	this.instance_2.alpha = 0.5;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#42210B").s().p("AhXCUIgBAAIgIgHIgCgDIgOj8QAAgOAhgKQAhgJAugBQAvABAhAJQAhAKAAAOIgPEAIgHAGg");
	this.shape_1.setTransform(34.6,14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance_2},{t:this.shape},{t:this.instance_1}]}).to({state:[]},1).wait(6));

	// Layer_4
	this.instance_3 = new lib.Symbol42copy_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(34.5,70.2,1,1,0,0,0,22.8,25.5);
	this.instance_3.filters = [new cjs.ColorFilter(0.31, 0.31, 0.31, 1, 105.57, 35.19, 175.95, 0)];
	this.instance_3.cache(-2,-2,50,55);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},1).wait(6));

	// Layer_3
	this.instance_4 = new lib.Mesh_0();
	this.instance_4.parent = this;
	this.instance_4.setTransform(12,90.4);

	this.instance_5 = new lib.Mesh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.6,16.2);

	this.instance_6 = new lib.Mesh_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(10.9,13.1);

	this.instance_7 = new lib.Mesh_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0,94.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]}).to({state:[]},1).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,102.3);


(lib.Symbol41copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_2
	this.text = new cjs.Text("NaCl", "19px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 23;
	this.text.lineWidth = 49;
	this.text.parent = this;
	this.text.setTransform(34.3,54);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape.setTransform(34.6,64.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(6));

	// Layer_1
	this.instance = new lib.Front();
	this.instance.parent = this;
	this.instance.setTransform(11,13);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(6));

	// Layer_5
	this.instance_1 = new lib.Pathcopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(34,29.2,1,1,0,0,0,7.7,0.5);
	this.instance_1.alpha = 0.5;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#42210B").s().p("AhEALQgdgEAAgHQAAgFAdgEQAdgFAnAAQAoAAAeAFQAcAEAAAFQAAAHgcAEQgdAEgpAAQgoAAgcgEg");
	this.shape_1.setTransform(34.6,29.2);

	this.instance_2 = new lib.Groupcopy2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(43.9,15.3,1,1,0,0,0,1.9,14.4);
	this.instance_2.alpha = 0.5;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#42210B").s().p("AhXCUIgBAAIgIgHIgCgDIgOj8QAAgOAhgKQAhgJAugBQAvABAhAJQAhAKAAAOIgPEAIgHAGg");
	this.shape_2.setTransform(34.6,14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.instance_2},{t:this.shape_1},{t:this.instance_1}]}).to({state:[]},1).wait(6));

	// Layer_4
	this.instance_3 = new lib.Symbol42();
	this.instance_3.parent = this;
	this.instance_3.setTransform(34.5,70.2,1,1,0,0,0,22.8,25.5);
	this.instance_3.alpha = 0.629;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},1).wait(6));

	// Layer_3
	this.instance_4 = new lib.Mesh_0();
	this.instance_4.parent = this;
	this.instance_4.setTransform(12,90.4);

	this.instance_5 = new lib.Mesh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.6,16.2);

	this.instance_6 = new lib.Mesh_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(10.9,13.1);

	this.instance_7 = new lib.Mesh_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0,94.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]}).to({state:[]},1).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,102.3);


(lib.Symbol41copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_2
	this.text = new cjs.Text("3", "8px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 11;
	this.text.lineWidth = 6;
	this.text.parent = this;
	this.text.setTransform(53,66.2);

	this.text_1 = new cjs.Text("AgNO", "19px 'Arial'", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 23;
	this.text_1.lineWidth = 49;
	this.text_1.parent = this;
	this.text_1.setTransform(34.3,54.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape.setTransform(34.6,64.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]}).to({state:[]},1).wait(6));

	// Layer_1
	this.instance = new lib.Front();
	this.instance.parent = this;
	this.instance.setTransform(11,13);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(6));

	// Layer_5
	this.instance_1 = new lib.Pathcopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(34,29.2,1,1,0,0,0,7.7,0.5);
	this.instance_1.alpha = 0.5;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#42210B").s().p("AhEALQgdgEAAgHQAAgFAdgEQAdgFAnAAQAoAAAeAFQAcAEAAAFQAAAHgcAEQgdAEgpAAQgoAAgcgEg");
	this.shape_1.setTransform(34.6,29.2);

	this.instance_2 = new lib.Groupcopy2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(43.9,15.3,1,1,0,0,0,1.9,14.4);
	this.instance_2.alpha = 0.5;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#42210B").s().p("AhXCUIgBAAIgIgHIgCgDIgOj8QAAgOAhgKQAhgJAugBQAvABAhAJQAhAKAAAOIgPEAIgHAGg");
	this.shape_2.setTransform(34.6,14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.instance_2},{t:this.shape_1},{t:this.instance_1}]}).to({state:[]},1).wait(6));

	// Layer_4
	this.instance_3 = new lib.Symbol42();
	this.instance_3.parent = this;
	this.instance_3.setTransform(34.5,70.2,1,1,0,0,0,22.8,25.5);
	this.instance_3.filters = [new cjs.ColorFilter(0.33, 0.33, 0.33, 1, 102.51, 170.85, 170.85, 0)];
	this.instance_3.cache(-2,-2,50,55);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},1).wait(6));

	// Layer_3
	this.instance_4 = new lib.Mesh_0();
	this.instance_4.parent = this;
	this.instance_4.setTransform(12,90.4);

	this.instance_5 = new lib.Mesh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.6,16.2);

	this.instance_6 = new lib.Mesh_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(10.9,13.1);

	this.instance_7 = new lib.Mesh_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0,94.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]}).to({state:[]},1).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,102.3);


(lib.Symbol34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1iil();
	this.instance.parent = this;
	this.instance.setTransform(145.3,37,0.67,1.657,0,-45,0,0.6,0.6);
	this.instance.alpha = 0.43;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.75},0).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.02)").s("rgba(153,153,0,0)").ss(1,1,1).dr(-99.95,-88.2,199.9,176.4);
	this.shape.setTransform(104.5,-22.8,1,1.216,0,-34.7,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.5,-112,324.6,179.6);


(lib.Symbol16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text_1 = new cjs.Text("My Lab", "21px 'Arial'", "#FFFFFF");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 37;
	this.text_1.lineWidth = 127;
	this.text_1.parent = this;
	this.text_1.setTransform(149.9,54,1,1,20.9);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1).to({y:47.9},0).wait(2));

	// Layer_3
	this.instance_2 = new lib.Untitled2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-2,-4,0.564,0.564);

	this.instance_3 = new lib.Symbol55_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(96.5,58.9,1,1,0,0,0,98.5,62.9);
	this.instance_3.filters = [new cjs.ColorFilter(0.09, 0.09, 0.09, 1, 92.82, 232.05, 0, 0)];
	this.instance_3.cache(-2,-2,201,130);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,-4,196.9,125.8);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text("My Lab", "21px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 37;
	this.text.lineWidth = 127;
	this.text.parent = this;
	this.text.setTransform(60.7,36.5,1,1,-24.1);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(3));

	// Layer_3
	this.instance = new lib.Untitled2();
	this.instance.parent = this;
	this.instance.setTransform(185.9,-9,0.564,0.564,0,0,180);

	this.instance_1 = new lib.Symbol54();
	this.instance_1.parent = this;
	this.instance_1.setTransform(87.5,53.9,1,1,0,0,0,98.5,62.9);
	this.instance_1.filters = [new cjs.ColorFilter(0.09, 0.09, 0.09, 1, 92.82, 232.05, 0, 0)];
	this.instance_1.cache(-2,-2,201,130);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11,-9,196.9,125.8);


(lib.Symbol5copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1copy3();
	this.instance.parent = this;
	this.instance.setTransform(26.5,23.4,1,1,0,0,0,20.4,20.4);

	this.instance_1 = new lib.Path_4copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.8,25.2,1,1,0,0,0,20.4,20.4);
	this.instance_1.alpha = 0.512;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC200").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(29.4,24.2);

	this.instance_2 = new lib.Path_2_1copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.4,24.2,1,1,0,0,0,27.4,24.2);
	this.instance_2.alpha = 0.359;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7931E").s().p("AliACIAAgCILEAAIAAACg");
	this.shape_1.setTransform(96,35.9);

	this.text = new cjs.Text("Conclusion", "16px 'Arial'", "#003300");
	this.text.textAlign = "right";
	this.text.lineHeight = 21;
	this.text.parent = this;
	this.text.setTransform(132,13.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFC200").s().p("AnhDKQg1AAgqgiQgMgVgKgUIgNgaIgDgPQgLghgHgZIAAhMQAAg/AtgtQArgtA/AAIO5AAQAfAAASAaIBkCMQAMARAAASQAAAUgMAPIhkCOQgSAZgfAAg");
	this.shape_2.setTransform(87.8,24.6);

	this.instance_3 = new lib.Path_1_3copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(87.7,24.4,1,1,0,0,0,65.2,22.7);
	this.instance_3.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_3},{t:this.shape_2},{t:this.shape},{t:this.instance_1},{t:this.instance},{t:this.text},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.9,48.4);


(lib.Symbol4copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_0copy();
	this.instance.parent = this;
	this.instance.setTransform(26.5,23.4,1,1,0,0,0,20.4,20.4);

	this.instance_1 = new lib.Path_0copy5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.8,25.2,1,1,0,0,0,20.4,20.4);
	this.instance_1.alpha = 0.512;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC200").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA9AUA7QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(29.4,24.2);

	this.instance_2 = new lib.Path_2_0copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.4,24.2,1,1,0,0,0,27.4,24.2);
	this.instance_2.alpha = 0.359;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7931E").s().p("AliABIAAgBILEAAIAAABg");
	this.shape_1.setTransform(96,34.9);

	this.text = new cjs.Text("The Steps", "16px 'Arial'", "#003300");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.parent = this;
	this.text.setTransform(92.6,13.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFC200").s().p("AnhDKQg1AAgpgiQgOgVgJgTIgMgbIgFgPQgLgggGgaIAAhMQAAg/AsgtQAsgtA/AAIO5AAQAfAAATAaIBkCMQALARAAASQAAAUgLAPIhkCNQgTAagfAAg");
	this.shape_2.setTransform(87.8,24.6);

	this.instance_3 = new lib.Path_1_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(87.7,24.4,1,1,0,0,0,65.2,22.7);
	this.instance_3.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_3},{t:this.shape_2},{t:this.shape},{t:this.instance_1},{t:this.instance},{t:this.text},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.9,48.4);


(lib.Symbol3copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroupcopy();
	this.instance.parent = this;
	this.instance.setTransform(26.5,23.4,1,1,0,0,0,20.4,20.4);

	this.instance_1 = new lib.Pathcopy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.8,25.2,1,1,0,0,0,20.4,20.4);
	this.instance_1.alpha = 0.512;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC200").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA9g1A8QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(29.4,24.2);

	this.instance_2 = new lib.Path_2copy4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.4,24.2,1,1,0,0,0,27.4,24.2);
	this.instance_2.alpha = 0.359;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7931E").s().p("AliABIAAgBILEAAIAAABg");
	this.shape_1.setTransform(96,33.9);

	this.text = new cjs.Text("The Tools", "20px 'Arial'", "#003300");
	this.text.textAlign = "right";
	this.text.lineHeight = 25;
	this.text.parent = this;
	this.text.setTransform(135,12);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFC200").s().p("AnhDKQg1AAgpgiQgOgVgJgTIgMgbIgFgQQgLgfgGgaIAAhNQAAg/AsgsQAsgtA/AAIO5AAQAfAAATAaIBkCNQALAQAAASQAAAUgLAQIhkCMQgTAagfAAg");
	this.shape_2.setTransform(87.8,24.6);

	this.instance_3 = new lib.Path_1_1copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(87.7,24.4,1,1,0,0,0,65.2,22.7);
	this.instance_3.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_3},{t:this.shape_2},{t:this.shape},{t:this.instance_1},{t:this.instance},{t:this.text},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.9,48.4);


(lib.Symbol1copy11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
		var shape10 = new createjs.Shape(new createjs.Graphics().beginFill("#A5A890").drawRect(-1220,0,3673.8,1206));
		var shape20 = new createjs.Shape(new createjs.Graphics().beginFill("#92F447").drawRect(-1220,0,3673.8,1206));
		var shape30 = new createjs.Shape(new createjs.Graphics().beginFill("#3D0D3D").drawRect(-1220,0,3673.8,1206));
		var shape40 = new createjs.Shape(new createjs.Graphics().beginFill("#3D9E0D").drawRect(-1220,0,3673.8,1206));
		var shape50 = new createjs.Shape(new createjs.Graphics().beginFill("#6DFFFF").drawRect(-1220,0,3673.8,1206));
		var shape60 = new createjs.Shape(new createjs.Graphics().beginFill("#FFFFFF").drawRect(-1220,0,3673.8,1206));
		var shape70 = new createjs.Shape(new createjs.Graphics().beginFill("#0D0D0D").drawRect(-1220,0,3673.8,1206));
		var shape80 = new createjs.Shape(new createjs.Graphics().beginFill("#FF3D0D").drawRect(-1220,0,3673.8,1206));
		var shape90 = new createjs.Shape(new createjs.Graphics().beginFill("#0D0DFF").drawRect(-1220,0,3673.8,1206));
		 
		 
		
		
		
		
		
		this.bac_0.addEventListener("mousedown", fl2_ClickToGoToclic_bac0_ss0.bind(this));
			function fl2_ClickToGoToclic_bac0_ss0() {
			
				//exportRoot.bfbf.setTransform(235,148.05,1,1,0,0,0,114,66);
				//exportRoot.backgrounsxsd_1.gotoAndStop(1);
				exportRoot.yy.addChild(shape10);
				
			}
		this.bac_1.addEventListener("mousedown", fl2_ClickToGoToclic_bac0_1.bind(this));
			function fl2_ClickToGoToclic_bac0_1() {
				exportRoot.yy.addChild(shape20);
				}
		this.bac_2.addEventListener("mousedown", fl2_ClickToGoToclic_bac_20.bind(this));
			function fl2_ClickToGoToclic_bac_20() {
				exportRoot.yy.addChild(shape30);
				}
		this.bac_3.addEventListener("mousedown", fl2_ClickToGoToclic_bac_30.bind(this));
			function fl2_ClickToGoToclic_bac_30() {
			exportRoot.yy.addChild(shape40);
				}
				
		this.bac_4.addEventListener("mousedown", fl2_ClickToGoToclic_bac_40.bind(this));
			function fl2_ClickToGoToclic_bac_40() {
				exportRoot.yy.addChild(shape50);
				}
		this.bac_5.addEventListener("mousedown", fl2_ClickToGoToclic_bac_60.bind(this));
			function fl2_ClickToGoToclic_bac_60() {
				exportRoot.yy.addChild(shape60);
				}
		this.bac_6.addEventListener("mousedown", fl2_ClickToGoToclic_bac_70.bind(this));
			function fl2_ClickToGoToclic_bac_70() {
				exportRoot.yy.addChild(shape70);
				}
		this.bac_7.addEventListener("mousedown", fl2_ClickToGoToclic_bac_80.bind(this));
			function fl2_ClickToGoToclic_bac_80() {
				
				exportRoot.yy.addChild(shape80);
				}
		this.bac_8.addEventListener("mousedown", fl2_ClickToGoToclic_bac_90.bind(this));
			function fl2_ClickToGoToclic_bac_90() {
				exportRoot.yy.addChild(shape90);
				}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(1));

	// bac_9
	this.bac_9 = new lib.Symbol79();
	this.bac_9.name = "bac_9";
	this.bac_9.parent = this;
	this.bac_9.setTransform(416,-18.4,0.596,0.49,0,0,0,30.7,33.1);
	this.bac_9._off = true;
	new cjs.ButtonHelper(this.bac_9, 0, 1, 1);

	this.bac_8 = new lib.Symbol79();
	this.bac_8.name = "bac_8";
	this.bac_8.parent = this;
	this.bac_8.setTransform(513.6,36.2,1,1,0,0,0,30.6,33.2);
	new cjs.ButtonHelper(this.bac_8, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_9}]},8).to({state:[{t:this.bac_9}]},3).to({state:[{t:this.bac_8}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.bac_9).wait(8).to({_off:false},0).to({regX:30.6,regY:33.2,scaleX:1,scaleY:1,x:513.6,y:36.2},3,cjs.Ease.bounceOut).to({_off:true},1).wait(1));

	// bac_8
	this.bac_8_1 = new lib.Symbol78();
	this.bac_8_1.name = "bac_8_1";
	this.bac_8_1.parent = this;
	this.bac_8_1.setTransform(380.2,-18.4,0.596,0.49,0,0,0,32.6,33.1);
	this.bac_8_1._off = true;
	new cjs.ButtonHelper(this.bac_8_1, 0, 1, 1);

	this.bac_7 = new lib.Symbol78();
	this.bac_7.name = "bac_7";
	this.bac_7.parent = this;
	this.bac_7.setTransform(453.6,36.2,1,1,0,0,0,32.6,33.2);
	new cjs.ButtonHelper(this.bac_7, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_8_1}]},7).to({state:[{t:this.bac_8_1}]},3).to({state:[{t:this.bac_7}]},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.bac_8_1).wait(7).to({_off:false},0).to({regY:33.2,scaleX:1,scaleY:1,x:453.6,y:36.2},3,cjs.Ease.bounceOut).to({_off:true},1).wait(2));

	// bac_7
	this.bac_7_1 = new lib.Symbol77();
	this.bac_7_1.name = "bac_7_1";
	this.bac_7_1.parent = this;
	this.bac_7_1.setTransform(344.5,-18.2,0.596,0.49,0,0,0,30.6,32.5);
	this.bac_7_1._off = true;
	new cjs.ButtonHelper(this.bac_7_1, 0, 1, 1);

	this.bac_6 = new lib.Symbol77();
	this.bac_6.name = "bac_6";
	this.bac_6.parent = this;
	this.bac_6.setTransform(393.6,36.6,1,1,0,0,0,30.6,32.6);
	new cjs.ButtonHelper(this.bac_6, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_7_1}]},6).to({state:[{t:this.bac_7_1}]},3).to({state:[{t:this.bac_6}]},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.bac_7_1).wait(6).to({_off:false},0).to({regY:32.6,scaleX:1,scaleY:1,x:393.6,y:36.6},3,cjs.Ease.bounceOut).to({_off:true},1).wait(3));

	// bac_6
	this.bac_6_1 = new lib.Symbol76();
	this.bac_6_1.name = "bac_6_1";
	this.bac_6_1.parent = this;
	this.bac_6_1.setTransform(308.5,-18.4,0.596,0.49,0,0,0,31.2,35.1);
	this.bac_6_1._off = true;
	new cjs.ButtonHelper(this.bac_6_1, 0, 1, 1);

	this.bac_5 = new lib.Symbol76();
	this.bac_5.name = "bac_5";
	this.bac_5.parent = this;
	this.bac_5.setTransform(333.1,36.3,1,1,0,0,0,31.1,35.3);
	new cjs.ButtonHelper(this.bac_5, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_6_1}]},5).to({state:[{t:this.bac_6_1}]},3).to({state:[{t:this.bac_5}]},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.bac_6_1).wait(5).to({_off:false},0).to({regX:31.1,regY:35.3,scaleX:1,scaleY:1,x:333.1,y:36.3},3,cjs.Ease.bounceOut).to({_off:true},1).wait(4));

	// bac_5
	this.bac_5_1 = new lib.Symbol73();
	this.bac_5_1.name = "bac_5_1";
	this.bac_5_1.parent = this;
	this.bac_5_1.setTransform(271.8,-18.1,0.596,0.49,0,0,0,30.6,35.7);
	this.bac_5_1._off = true;
	new cjs.ButtonHelper(this.bac_5_1, 0, 1, 1);

	this.bac_4 = new lib.Symbol73();
	this.bac_4.name = "bac_4";
	this.bac_4.parent = this;
	this.bac_4.setTransform(271.6,36.9,1,1,0,0,0,30.6,35.9);
	new cjs.ButtonHelper(this.bac_4, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_5_1}]},4).to({state:[{t:this.bac_5_1}]},3).to({state:[{t:this.bac_4}]},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.bac_5_1).wait(4).to({_off:false},0).to({regY:35.9,scaleX:1,scaleY:1,x:271.6,y:36.9},3,cjs.Ease.bounceOut).to({_off:true},1).wait(5));

	// bac_4
	this.bac_4_1 = new lib.Symbol72();
	this.bac_4_1.name = "bac_4_1";
	this.bac_4_1.parent = this;
	this.bac_4_1.setTransform(236.4,-18.1,0.596,0.49,0,0,0,31.2,36.7);
	this.bac_4_1._off = true;
	new cjs.ButtonHelper(this.bac_4_1, 0, 1, 1);

	this.bac_3 = new lib.Symbol72();
	this.bac_3.name = "bac_3";
	this.bac_3.parent = this;
	this.bac_3.setTransform(212.1,36.9,1,1,0,0,0,31.1,36.9);
	new cjs.ButtonHelper(this.bac_3, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_4_1}]},3).to({state:[{t:this.bac_4_1}]},3).to({state:[{t:this.bac_3}]},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.bac_4_1).wait(3).to({_off:false},0).to({regX:31.1,regY:36.9,scaleX:1,scaleY:1,x:212.1,y:36.9},3,cjs.Ease.bounceOut).to({_off:true},1).wait(6));

	// bac_2
	this.bac_2 = new lib.Symbol71copy();
	this.bac_2.name = "bac_2";
	this.bac_2.parent = this;
	this.bac_2.setTransform(200.4,-18.4,0.596,0.49,0,0,0,30.7,33.1);
	this.bac_2._off = true;
	new cjs.ButtonHelper(this.bac_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.bac_2).wait(2).to({_off:false},0).to({regX:30.6,regY:33.2,scaleX:1,scaleY:1,x:151.6,y:36.2},3,cjs.Ease.bounceOut).wait(8));

	// bac_1
	this.bac_1 = new lib.Symbol69copy();
	this.bac_1.name = "bac_1";
	this.bac_1.parent = this;
	this.bac_1.setTransform(164.9,-18.4,0.596,0.49,0,0,0,31.2,33.1);
	this.bac_1._off = true;
	new cjs.ButtonHelper(this.bac_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.bac_1).wait(1).to({_off:false},0).to({regX:31.1,regY:33.2,scaleX:1,scaleY:1,x:92.1,y:36.2},3,cjs.Ease.bounceOut).wait(9));

	// bac_0
	this.bac_0 = new lib.Symbol68copy();
	this.bac_0.name = "bac_0";
	this.bac_0.parent = this;
	this.bac_0.setTransform(128.9,-18.4,0.596,0.49,0,0,0,31.7,34);
	this.bac_0._off = true;
	new cjs.ButtonHelper(this.bac_0, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.bac_0).wait(1).to({_off:false},0).to({regX:31.6,regY:34.3,scaleX:1,scaleY:1,x:31.6,y:36.3},2,cjs.Ease.bounceOut).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
		var shape1 = new createjs.Shape(new createjs.Graphics().beginFill("#A5A890").drawRect(-1220,0,3673.8,1206));
		var shape2 = new createjs.Shape(new createjs.Graphics().beginFill("#92F447").drawRect(-1220,0,3673.8,1206));
		var shape3 = new createjs.Shape(new createjs.Graphics().beginFill("#3D0D3D").drawRect(-1220,0,3673.8,1206));
		var shape4 = new createjs.Shape(new createjs.Graphics().beginFill("#3D9E0D").drawRect(-1220,0,3673.8,1206));
		var shape5 = new createjs.Shape(new createjs.Graphics().beginFill("#6DFFFF").drawRect(-1220,0,3673.8,1206));
		var shape6 = new createjs.Shape(new createjs.Graphics().beginFill("#FFFFFF").drawRect(-1220,0,3673.8,1206));
		var shape7 = new createjs.Shape(new createjs.Graphics().beginFill("#0D0D0D").drawRect(-1220,0,3673.8,1206));
		var shape8 = new createjs.Shape(new createjs.Graphics().beginFill("#FF3D0D").drawRect(-1220,0,3673.8,1206));
		var shape9 = new createjs.Shape(new createjs.Graphics().beginFill("#0D0DFF").drawRect(-1220,0,3673.8,1206));
		 
		 
		
		
		
		
		
		this.bac_0.addEventListener("mousedown", fl2_ClickToGoToclic_bac_ss0.bind(this));
			function fl2_ClickToGoToclic_bac_ss0() {
			
				//exportRoot.bfbf.setTransform(235,148.05,1,1,0,0,0,114,66);
				//exportRoot.backgrounsxsd_1.gotoAndStop(1);
				exportRoot.yy.addChild(shape1);
				
			}
		this.bac_1.addEventListener("mousedown", fl2_ClickToGoToclic_bac_1.bind(this));
			function fl2_ClickToGoToclic_bac_1() {
				exportRoot.yy.addChild(shape2);
				}
		this.bac_2.addEventListener("mousedown", fl2_ClickToGoToclic_bac_2.bind(this));
			function fl2_ClickToGoToclic_bac_2() {
				exportRoot.yy.addChild(shape3);
				}
		this.bac_3.addEventListener("mousedown", fl2_ClickToGoToclic_bac_3.bind(this));
			function fl2_ClickToGoToclic_bac_3() {
			exportRoot.yy.addChild(shape4);
				}
				
		this.bac_4.addEventListener("mousedown", fl2_ClickToGoToclic_bac_4.bind(this));
			function fl2_ClickToGoToclic_bac_4() {
				exportRoot.yy.addChild(shape5);
				}
		this.bac_5.addEventListener("mousedown", fl2_ClickToGoToclic_bac_6.bind(this));
			function fl2_ClickToGoToclic_bac_6() {
				exportRoot.yy.addChild(shape6);
				}
		this.bac_6.addEventListener("mousedown", fl2_ClickToGoToclic_bac_7.bind(this));
			function fl2_ClickToGoToclic_bac_7() {
				exportRoot.yy.addChild(shape7);
				}
		this.bac_7.addEventListener("mousedown", fl2_ClickToGoToclic_bac_8.bind(this));
			function fl2_ClickToGoToclic_bac_8() {
				
				exportRoot.yy.addChild(shape8);
				}
		this.bac_8.addEventListener("mousedown", fl2_ClickToGoToclic_bac_9.bind(this));
			function fl2_ClickToGoToclic_bac_9() {
				exportRoot.yy.addChild(shape9);
				}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(1));

	// bac_9
	this.bac_9 = new lib.Symbol79();
	this.bac_9.name = "bac_9";
	this.bac_9.parent = this;
	this.bac_9.setTransform(416,-18.4,0.596,0.49,0,0,0,30.7,33.1);
	this.bac_9._off = true;
	new cjs.ButtonHelper(this.bac_9, 0, 1, 1);

	this.bac_8 = new lib.Symbol79();
	this.bac_8.name = "bac_8";
	this.bac_8.parent = this;
	this.bac_8.setTransform(513.6,36.2,1,1,0,0,0,30.6,33.2);
	new cjs.ButtonHelper(this.bac_8, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_9}]},8).to({state:[{t:this.bac_9}]},3).to({state:[{t:this.bac_8}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.bac_9).wait(8).to({_off:false},0).to({regX:30.6,regY:33.2,scaleX:1,scaleY:1,x:513.6,y:36.2},3,cjs.Ease.bounceOut).to({_off:true},1).wait(1));

	// bac_8
	this.bac_8_1 = new lib.Symbol78();
	this.bac_8_1.name = "bac_8_1";
	this.bac_8_1.parent = this;
	this.bac_8_1.setTransform(380.2,-18.4,0.596,0.49,0,0,0,32.6,33.1);
	this.bac_8_1._off = true;
	new cjs.ButtonHelper(this.bac_8_1, 0, 1, 1);

	this.bac_7 = new lib.Symbol78();
	this.bac_7.name = "bac_7";
	this.bac_7.parent = this;
	this.bac_7.setTransform(453.6,36.2,1,1,0,0,0,32.6,33.2);
	new cjs.ButtonHelper(this.bac_7, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_8_1}]},7).to({state:[{t:this.bac_8_1}]},3).to({state:[{t:this.bac_7}]},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.bac_8_1).wait(7).to({_off:false},0).to({regY:33.2,scaleX:1,scaleY:1,x:453.6,y:36.2},3,cjs.Ease.bounceOut).to({_off:true},1).wait(2));

	// bac_7
	this.bac_7_1 = new lib.Symbol77();
	this.bac_7_1.name = "bac_7_1";
	this.bac_7_1.parent = this;
	this.bac_7_1.setTransform(344.5,-18.2,0.596,0.49,0,0,0,30.6,32.5);
	this.bac_7_1._off = true;
	new cjs.ButtonHelper(this.bac_7_1, 0, 1, 1);

	this.bac_6 = new lib.Symbol77();
	this.bac_6.name = "bac_6";
	this.bac_6.parent = this;
	this.bac_6.setTransform(393.6,36.6,1,1,0,0,0,30.6,32.6);
	new cjs.ButtonHelper(this.bac_6, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_7_1}]},6).to({state:[{t:this.bac_7_1}]},3).to({state:[{t:this.bac_6}]},1).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.bac_7_1).wait(6).to({_off:false},0).to({regY:32.6,scaleX:1,scaleY:1,x:393.6,y:36.6},3,cjs.Ease.bounceOut).to({_off:true},1).wait(3));

	// bac_6
	this.bac_6_1 = new lib.Symbol76();
	this.bac_6_1.name = "bac_6_1";
	this.bac_6_1.parent = this;
	this.bac_6_1.setTransform(308.5,-18.4,0.596,0.49,0,0,0,31.2,35.1);
	this.bac_6_1._off = true;
	new cjs.ButtonHelper(this.bac_6_1, 0, 1, 1);

	this.bac_5 = new lib.Symbol76();
	this.bac_5.name = "bac_5";
	this.bac_5.parent = this;
	this.bac_5.setTransform(333.1,36.3,1,1,0,0,0,31.1,35.3);
	new cjs.ButtonHelper(this.bac_5, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_6_1}]},5).to({state:[{t:this.bac_6_1}]},3).to({state:[{t:this.bac_5}]},1).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.bac_6_1).wait(5).to({_off:false},0).to({regX:31.1,regY:35.3,scaleX:1,scaleY:1,x:333.1,y:36.3},3,cjs.Ease.bounceOut).to({_off:true},1).wait(4));

	// bac_5
	this.bac_5_1 = new lib.Symbol73();
	this.bac_5_1.name = "bac_5_1";
	this.bac_5_1.parent = this;
	this.bac_5_1.setTransform(271.8,-18.1,0.596,0.49,0,0,0,30.6,35.7);
	this.bac_5_1._off = true;
	new cjs.ButtonHelper(this.bac_5_1, 0, 1, 1);

	this.bac_4 = new lib.Symbol73();
	this.bac_4.name = "bac_4";
	this.bac_4.parent = this;
	this.bac_4.setTransform(271.6,36.9,1,1,0,0,0,30.6,35.9);
	new cjs.ButtonHelper(this.bac_4, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_5_1}]},4).to({state:[{t:this.bac_5_1}]},3).to({state:[{t:this.bac_4}]},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.bac_5_1).wait(4).to({_off:false},0).to({regY:35.9,scaleX:1,scaleY:1,x:271.6,y:36.9},3,cjs.Ease.bounceOut).to({_off:true},1).wait(5));

	// bac_4
	this.bac_4_1 = new lib.Symbol72();
	this.bac_4_1.name = "bac_4_1";
	this.bac_4_1.parent = this;
	this.bac_4_1.setTransform(236.4,-18.1,0.596,0.49,0,0,0,31.2,36.7);
	this.bac_4_1._off = true;
	new cjs.ButtonHelper(this.bac_4_1, 0, 1, 1);

	this.bac_3 = new lib.Symbol72();
	this.bac_3.name = "bac_3";
	this.bac_3.parent = this;
	this.bac_3.setTransform(212.1,36.9,1,1,0,0,0,31.1,36.9);
	new cjs.ButtonHelper(this.bac_3, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.bac_4_1}]},3).to({state:[{t:this.bac_4_1}]},3).to({state:[{t:this.bac_3}]},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.bac_4_1).wait(3).to({_off:false},0).to({regX:31.1,regY:36.9,scaleX:1,scaleY:1,x:212.1,y:36.9},3,cjs.Ease.bounceOut).to({_off:true},1).wait(6));

	// bac_2
	this.bac_2 = new lib.Symbol71copy();
	this.bac_2.name = "bac_2";
	this.bac_2.parent = this;
	this.bac_2.setTransform(200.4,-18.4,0.596,0.49,0,0,0,30.7,33.1);
	this.bac_2._off = true;
	new cjs.ButtonHelper(this.bac_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.bac_2).wait(2).to({_off:false},0).to({regX:30.6,regY:33.2,scaleX:1,scaleY:1,x:151.6,y:36.2},3,cjs.Ease.bounceOut).wait(8));

	// bac_1
	this.bac_1 = new lib.Symbol69copy();
	this.bac_1.name = "bac_1";
	this.bac_1.parent = this;
	this.bac_1.setTransform(164.9,-18.4,0.596,0.49,0,0,0,31.2,33.1);
	this.bac_1._off = true;
	new cjs.ButtonHelper(this.bac_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.bac_1).wait(1).to({_off:false},0).to({regX:31.1,regY:33.2,scaleX:1,scaleY:1,x:92.1,y:36.2},3,cjs.Ease.bounceOut).wait(9));

	// bac_0
	this.bac_0 = new lib.Symbol68copy();
	this.bac_0.name = "bac_0";
	this.bac_0.parent = this;
	this.bac_0.setTransform(128.9,-18.4,0.596,0.49,0,0,0,31.7,34);
	this.bac_0._off = true;
	new cjs.ButtonHelper(this.bac_0, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.bac_0).wait(1).to({_off:false},0).to({regX:31.6,regY:34.3,scaleX:1,scaleY:1,x:31.6,y:36.3},2,cjs.Ease.bounceOut).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc_question = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{appear:0,out:6});

	// timeline functions:
	this.frame_6 = function() {
		//    يظهر عند  تشغيل الموفى الموفى بيشتغل عند الانتقال اليه
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(6).call(this.frame_6).wait(5));

	// answer0
	this.answer0 = new lib.mc_answer();
	this.answer0.name = "answer0";
	this.answer0.parent = this;
	this.answer0.setTransform(487.7,-0.4);
	this.answer0.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.answer0).wait(1).to({x:456.6,alpha:0.167},0).wait(1).to({x:425.5,alpha:0.333},0).wait(1).to({x:394.4,alpha:0.5},0).wait(1).to({x:363.3,alpha:0.667},0).wait(1).to({x:332.2,alpha:0.833},0).wait(1).to({x:301.2,alpha:1},0).wait(1).to({scaleX:0.9,scaleY:0.9,x:279.1,y:5,alpha:0.75},0).wait(1).to({scaleX:0.8,scaleY:0.8,x:257.1,y:10.4,alpha:0.5},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:235.1,y:15.8,alpha:0.25},0).wait(1).to({scaleX:0.6,scaleY:0.6,x:213.1,y:21.2,alpha:0},0).wait(1));

	// answer1
	this.answer1 = new lib.mc_answer();
	this.answer1.name = "answer1";
	this.answer1.parent = this;
	this.answer1.setTransform(-341.5,-0.4);
	this.answer1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.answer1).wait(1).to({x:-313,alpha:0.167},0).wait(1).to({x:-284.5,alpha:0.333},0).wait(1).to({x:-256,alpha:0.5},0).wait(1).to({x:-227.5,alpha:0.667},0).wait(1).to({x:-199,alpha:0.833},0).wait(1).to({x:-170.5,alpha:1},0).wait(1).to({scaleX:0.89,scaleY:0.89,x:-153.2,y:5.4,alpha:0.75},0).wait(1).to({scaleX:0.78,scaleY:0.78,x:-135.8,y:11.2,alpha:0.5},0).wait(1).to({scaleX:0.68,scaleY:0.68,x:-118.5,y:17.1,alpha:0.25},0).wait(1).to({scaleX:0.57,scaleY:0.57,x:-101.2,y:22.9,alpha:0},0).wait(1));

	// answer2
	this.answer2 = new lib.mc_answer();
	this.answer2.name = "answer2";
	this.answer2.parent = this;
	this.answer2.setTransform(487.5,107.7);
	this.answer2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.answer2).wait(1).to({x:456.4,alpha:0.167},0).wait(1).to({x:425.3,alpha:0.333},0).wait(1).to({x:394.3,alpha:0.5},0).wait(1).to({x:363.2,alpha:0.667},0).wait(1).to({x:332.1,alpha:0.833},0).wait(1).to({x:301,alpha:1},0).wait(1).to({scaleX:0.9,scaleY:0.9,x:279,y:102.3,alpha:0.75},0).wait(1).to({scaleX:0.8,scaleY:0.8,x:257,y:96.9,alpha:0.5},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:235,y:91.5,alpha:0.25},0).wait(1).to({scaleX:0.6,scaleY:0.6,x:213,y:86.1,alpha:0},0).wait(1));

	// answer3
	this.answer3 = new lib.mc_answer();
	this.answer3.name = "answer3";
	this.answer3.parent = this;
	this.answer3.setTransform(-341.5,107.7);
	this.answer3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.answer3).wait(1).to({x:-313,alpha:0.167},0).wait(1).to({x:-284.5,alpha:0.333},0).wait(1).to({x:-256,alpha:0.5},0).wait(1).to({x:-227.5,alpha:0.667},0).wait(1).to({x:-199,alpha:0.833},0).wait(1).to({x:-170.5,alpha:1},0).wait(1).to({scaleX:0.89,scaleY:0.89,x:-153.2,y:101.8,alpha:0.75},0).wait(1).to({scaleX:0.78,scaleY:0.78,x:-135.8,y:96,alpha:0.5},0).wait(1).to({scaleX:0.68,scaleY:0.68,x:-118.5,y:90.1,alpha:0.25},0).wait(1).to({scaleX:0.57,scaleY:0.57,x:-101.2,y:84.3,alpha:0},0).wait(1));

	// questions
	this.num_question = new cjs.Text("", "bold 34px 'Georgia'", "#000066");
	this.num_question.name = "num_question";
	this.num_question.textAlign = "center";
	this.num_question.lineHeight = 41;
	this.num_question.lineWidth = 64;
	this.num_question.parent = this;
	this.num_question.setTransform(475.1,-152.1);

	this.txt_question = new cjs.Text("questions", "bold 33px 'Georgia'", "#000066");
	this.txt_question.name = "txt_question";
	this.txt_question.textAlign = "right";
	this.txt_question.lineHeight = 40;
	this.txt_question.lineWidth = 815;
	this.txt_question.parent = this;
	this.txt_question.setTransform(428.1,-152.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_question},{t:this.num_question}]}).to({state:[]},7).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-528,-154.1,1202.2,287.3);


(lib.hamellcopy8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		// this.swich_1.gotoAndPlay(7);
	}
	this.frame_1 = function() {
		//this.swich_1.gotoAndPlay(2);
	}
	this.frame_30 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(29).call(this.frame_30).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AjEjPQh4oHDTl+QBpivBpCvQC3FVhbIwg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-24.1,y:-119.6}).wait(30));

	// Untitled_2_psd
	this.instance = new lib.Layer1();
	this.instance.parent = this;
	this.instance.setTransform(-65,-270);

	this.instance_1 = new lib.Layer2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-65,-270);

	this.instance_2 = new lib.Layer3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-60,-262);

	this.instance_3 = new lib.Layer4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-62,-279);

	this.instance_4 = new lib.Layer5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-62,-273);

	this.instance_5 = new lib.Layer6();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-65,-281);

	this.instance_6 = new lib.Layer7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-65,-271);

	this.instance_7 = new lib.Layer8();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-60,-259);

	this.instance_8 = new lib.Layer9();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-65,-281);

	this.instance_9 = new lib.Layer10();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-65,-281);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.instance_7,this.instance_8,this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance_2}]},3).to({state:[{t:this.instance_3}]},3).to({state:[{t:this.instance_4}]},3).to({state:[{t:this.instance_5}]},3).to({state:[{t:this.instance_6}]},3).to({state:[{t:this.instance_7}]},3).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.instance_9}]},3).wait(3));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.822,-0.475,0.475,0.822,-463.3,2.8)).s().p("At0jYIAGgDIGJjjIAAAKIUpAAIAxBUIlTDEIwWJbg");
	this.shape.setTransform(114.7,7.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.95,0,0,0.95,-352.2,-279.4)).s().p("A2nbkMAAAg3HIW+AAIAAGyIp/AAIAAEfIHRAAIAAHkIjRB5IAFAIIgFADIF+KXIQXpbIF8AAMAAAAhSg");
	this.shape_1.setTransform(62.4,28.3);

	this.instance_10 = new lib.Symbol8copy2();
	this.instance_10.parent = this;
	this.instance_10.setTransform(63.2,28,2.802,2.802,0,0,0,-1148,364.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance_10}]},1).wait(30));

	// Layer_4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],7), null, new cjs.Matrix2D(1,0,0,1,-424.9,-330.2)).s().p("AmaIEIAAwHIM1AAIAAQHg");
	this.shape_2.setTransform(91.6,88);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(31));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.4,-148.1,289.7,352.8);


(lib.hamellcopy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.instance = new lib.Symbol8();
	this.instance.parent = this;
	this.instance.setTransform(62.9,28,2.802,2.802,0,0,0,-1148,364.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],7), null, new cjs.Matrix2D(1,0,0,1,-424.9,-330.2)).s().p("AmaIEIAAwHIM1AAIAAQHg");
	this.shape.setTransform(91.6,88);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hamellcopy3, new cjs.Rectangle(-82.4,-148.1,289.7,352.8), null);


(lib.Group_4copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_8copy();
	this.instance.parent = this;
	this.instance.setTransform(6.1,12.8,1,1,0,0,0,2.3,0.6);
	this.instance.alpha = 0.5;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1A1A").s().p("AAlBKIgJgGIg/ABQgGAAgCgKIABgEQABgDADgBQApgFgFgBIhJhAQgKgIAGgFQAFgGAHAFIAmAfQAAAAABABQABAAAAAAQABAAAAgBQABAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAgBIgJgIIgBAAIAAAAIgegaQgGgFAFgGIAAgBQADgDADAAQAEAAACACIAeAZIAAABIABAAIALAKQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAIgIgHIAAAAIghgcQgCgCAAgDQgBgDACgDQAFgGAHAFIAeAaIABABIAJAIIAAAAIAAAAIABABIABgBIABgCIgBgBIgegaQgFgGAEgFIABAAQAEgCAEACIAYATIABABIATAOIAAABIAoAmQADACALAUIADAFQACAFgIAKIgZAeQgCAEgFABIgBAAQgDAAgDgCg");
	this.shape.setTransform(8.2,7.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4copy3, new cjs.Rectangle(0,0.1,16.5,15.2), null);


(lib.Group_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_38copy();
	this.instance.parent = this;
	this.instance.setTransform(33,7,1,1,0,0,0,33,7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_0copy, new cjs.Rectangle(0,0,66,14), null);


(lib.Group_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_38();
	this.instance.parent = this;
	this.instance.setTransform(33,7,1,1,0,0,0,33,7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(0,0,66,14), null);


(lib.ClipGroup_36copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJClIAAlKIETAAIAAFKg");
	mask.setTransform(13.8,17);

	// Layer_3
	this.instance = new lib.ClipGroup_37copy();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.8,1,1,0,0,0,13.9,16.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36copy, new cjs.Rectangle(0,0.4,27.5,33.1), null);


(lib.ClipGroup_36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJClIAAlKIETAAIAAFKg");
	mask.setTransform(13.8,17);

	// Layer_3
	this.instance = new lib.ClipGroup_37();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.8,1,1,0,0,0,13.9,16.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36, new cjs.Rectangle(0,0.4,27.5,33.1), null);


(lib.ClipGroup_35copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJCmQANgeAVgZIAigpIAIgLQAhgkARgbQAegzAHhHIACgWQA0AAArgMIAPgFIgDAYQgKBIgiA4QgTAdgiAoIgJAMIghAsQgTAZgKAdg");
	mask.setTransform(13.8,16.6);

	// Layer_3
	this.instance = new lib.ClipGroup_36copy();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35copy, new cjs.Rectangle(0,0,27.5,33.1), null);


(lib.ClipGroup_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJCmQANgeAVgZIAigpIAIgLQAhgkARgbQAegzAHhHIACgWQA0AAArgMIAPgFIgDAYQgKBIgiA4QgTAdgiAoIgJAMIghAsQgTAZgKAdg");
	mask.setTransform(13.8,16.6);

	// Layer_3
	this.instance = new lib.ClipGroup_36();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35, new cjs.Rectangle(0,0,27.5,33.1), null);


(lib.ClipGroup_34copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJCmIAAlLIETAAIAAFLg");
	mask.setTransform(13.8,16.6);

	// Layer_3
	this.instance = new lib.ClipGroup_35copy();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_34copy, new cjs.Rectangle(0,0,27.5,33.1), null);


(lib.ClipGroup_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJCmIAAlLIETAAIAAFLg");
	mask.setTransform(13.8,16.6);

	// Layer_3
	this.instance = new lib.ClipGroup_35();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_34, new cjs.Rectangle(0,0,27.5,33.1), null);


(lib.ClipGroup_32copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.9,11.8);

	// Layer_3
	this.instance = new lib.ClipGroup_33copy();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.8,1,1,0,0,0,30.9,11.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32copy, new cjs.Rectangle(0.1,0.4,61.7,22.8), null);


(lib.ClipGroup_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.9,11.8);

	// Layer_3
	this.instance = new lib.ClipGroup_33();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.8,1,1,0,0,0,30.9,11.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32, new cjs.Rectangle(0.1,0.4,61.7,22.8), null);


(lib.ClipGroup_31copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah3BpQg5gJgfgQIgVgdQhHhkgHgvIgBgLQAhAmBYAVQBUAVBmgCQBegCBQgUQBWgWAwgoIgBAMQgHAdgeAxQgfAwghAlQgKALgKAIQhCAgh7ABIgHAAQg6AAgzgJg");
	mask.setTransform(30.8,11.4);

	// Layer_3
	this.instance = new lib.ClipGroup_32copy();
	this.instance.parent = this;
	this.instance.setTransform(30.8,11.5,1,1,0,0,0,30.9,11.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31copy, new cjs.Rectangle(0,0,61.7,22.8), null);


(lib.ClipGroup_31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah3BpQg5gJgfgQIgVgdQhHhkgHgvIgBgLQAhAmBYAVQBUAVBmgCQBegCBQgUQBWgWAwgoIgBAMQgHAdgeAxQgfAwghAlQgKALgKAIQhCAgh7ABIgHAAQg6AAgzgJg");
	mask.setTransform(30.8,11.4);

	// Layer_3
	this.instance = new lib.ClipGroup_32();
	this.instance.parent = this;
	this.instance.setTransform(30.8,11.5,1,1,0,0,0,30.9,11.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31, new cjs.Rectangle(0,0,61.7,22.8), null);


(lib.ClipGroup_30copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.8,11.4);

	// Layer_3
	this.instance = new lib.ClipGroup_31copy();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.4,1,1,0,0,0,30.9,11.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30copy, new cjs.Rectangle(0,0,61.7,22.8), null);


(lib.ClipGroup_30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.8,11.4);

	// Layer_3
	this.instance = new lib.ClipGroup_31();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.4,1,1,0,0,0,30.9,11.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30, new cjs.Rectangle(0,0,61.7,22.8), null);


(lib.ClipGroup_28copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.8,20.8);

	// Layer_3
	this.instance = new lib.ClipGroup_29copy();
	this.instance.parent = this;
	this.instance.setTransform(35.8,20.9,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28copy, new cjs.Rectangle(0.3,0.4,71,40.9), null);


(lib.ClipGroup_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.8,20.8);

	// Layer_3
	this.instance = new lib.ClipGroup_29();
	this.instance.parent = this;
	this.instance.setTransform(35.8,20.9,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28, new cjs.Rectangle(0.3,0.4,71,40.9), null);


(lib.ClipGroup_27copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhcDIQgsgFgBgHQAAgEgDgHQgDgJgIgJQgHgKgIgEQgngZgbgaQgmglgagvQgcgzgQhLQgMg0gCgkQAMAWBqALQBiALCIAAQCXAABogNQBbgMALgTQAAAcgRBFQgTBQgXAlQgeAzgcAbQgWAVgtAfQgOAJgHALQgHAIgDAJIgCALQgFAIgqAEQgnAFg2AAQg1AAglgFg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.ClipGroup_28copy();
	this.instance.parent = this;
	this.instance.setTransform(35.6,20.6,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27copy, new cjs.Rectangle(0,0,71,41), null);


(lib.ClipGroup_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhcDIQgsgFgBgHQAAgEgDgHQgDgJgIgJQgHgKgIgEQgngZgbgaQgmglgagvQgcgzgQhLQgMg0gCgkQAMAWBqALQBiALCIAAQCXAABogNQBbgMALgTQAAAcgRBFQgTBQgXAlQgeAzgcAbQgWAVgtAfQgOAJgHALQgHAIgDAJIgCALQgFAIgqAEQgnAFg2AAQg1AAglgFg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.ClipGroup_28();
	this.instance.parent = this;
	this.instance.setTransform(35.6,20.6,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27, new cjs.Rectangle(0,0,71,41), null);


(lib.ClipGroup_24copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(4.3,3.4);

	// Layer_3
	this.instance = new lib.ClipGroup_25copy();
	this.instance.parent = this;
	this.instance.setTransform(4,3.4,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24copy, new cjs.Rectangle(0.5,0.2,7.6,6.5), null);


(lib.ClipGroup_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(4.3,3.4);

	// Layer_3
	this.instance = new lib.ClipGroup_25();
	this.instance.parent = this;
	this.instance.setTransform(4,3.4,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24, new cjs.Rectangle(0.5,0.2,7.6,6.5), null);


(lib.ClipGroup_23copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgVAeQAHgOgBgPQgCgLgEgEQgFgFgLgCQAwgFAJgDIASgCQgUAOgEAEQgVATgBAVQAAACgFACIgCABIgGgCg");
	mask.setTransform(3.8,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_24copy();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.2,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23copy, new cjs.Rectangle(0,0,7.6,6.4), null);


(lib.ClipGroup_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgVAeQAHgOgBgPQgCgLgEgEQgFgFgLgCQAwgFAJgDIASgCQgUAOgEAEQgVATgBAVQAAACgFACIgCABIgGgCg");
	mask.setTransform(3.8,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_24();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.2,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23, new cjs.Rectangle(0,0,7.6,6.4), null);


(lib.ClipGroup_22copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(3.8,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_23copy();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.1,1,1,0,0,0,3.6,3.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22copy, new cjs.Rectangle(0.1,0,7.6,6.4), null);


(lib.ClipGroup_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(3.8,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_23();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.1,1,1,0,0,0,3.6,3.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22, new cjs.Rectangle(0.1,0,7.6,6.4), null);


(lib.ClipGroup_20copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAgIAAg/IBNAAIAAA/g");
	mask.setTransform(4,3.5);

	// Layer_3
	this.instance = new lib.ClipGroup_21copy();
	this.instance.parent = this;
	this.instance.setTransform(4,3.4,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20copy, new cjs.Rectangle(0.1,0.3,7.8,6.4), null);


(lib.ClipGroup_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAgIAAg/IBNAAIAAA/g");
	mask.setTransform(4,3.5);

	// Layer_3
	this.instance = new lib.ClipGroup_21();
	this.instance.parent = this;
	this.instance.setTransform(4,3.4,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20, new cjs.Rectangle(0.1,0.3,7.8,6.4), null);


(lib.ClipGroup_19copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AAOAfQgDgCgBgCQgCgUgVgUIgZgRIAUABQAJADAwAFQgLACgFAFQgEAEgBALQgCAPAHAOIgGABIgDAAg");
	mask.setTransform(3.9,3.1);

	// Layer_3
	this.instance = new lib.ClipGroup_20copy();
	this.instance.parent = this;
	this.instance.setTransform(4,3.2,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19copy, new cjs.Rectangle(0,0,7.8,6.3), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AAOAfQgDgCgBgCQgCgUgVgUIgZgRIAUABQAJADAwAFQgLACgFAFQgEAEgBALQgCAPAHAOIgGABIgDAAg");
	mask.setTransform(3.9,3.1);

	// Layer_3
	this.instance = new lib.ClipGroup_20();
	this.instance.parent = this;
	this.instance.setTransform(4,3.2,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(0,0,7.8,6.3), null);


(lib.ClipGroup_18copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAfIAAg+IBNAAIAAA+g");
	mask.setTransform(3.9,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_19copy();
	this.instance.parent = this;
	this.instance.setTransform(4,3.1,1,1,0,0,0,4,3.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18copy, new cjs.Rectangle(0,0,7.8,6.3), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAfIAAg+IBNAAIAAA+g");
	mask.setTransform(3.9,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_19();
	this.instance.parent = this;
	this.instance.setTransform(4,3.1,1,1,0,0,0,4,3.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(0,0,7.8,6.3), null);


(lib.ClipGroup_16copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AYIAAgvIFpAAIAAAvg");
	mask.setTransform(18.1,2.7);

	// Layer_3
	this.instance = new lib.ClipGroup_17copy();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.6,1,1,0,0,0,18.3,2.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16copy, new cjs.Rectangle(0,0.3,36.2,4.8), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AYIAAgvIFpAAIAAAvg");
	mask.setTransform(18.1,2.7);

	// Layer_3
	this.instance = new lib.ClipGroup_17();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.6,1,1,0,0,0,18.3,2.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0,0.3,36.2,4.8), null);


(lib.ClipGroup_15copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhJAWQg1gDgVgEQAAgBgEgGQgGgHgDgBQgUgLAAgBQAQABBGgFQBPgGAOAAQAKgBBUAFQBKAFAOgDQAAACgWAMIgKAIQgHAGAAACQgRADg3ADQgxADgWAAIgLAAIg9gBg");
	mask.setTransform(18.1,2.4);

	// Layer_3
	this.instance = new lib.ClipGroup_16copy();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.3,1,1,0,0,0,18.3,2.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15copy, new cjs.Rectangle(0,0.1,36.2,4.7), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhJAWQg1gDgVgEQAAgBgEgGQgGgHgDgBQgUgLAAgBQAQABBGgFQBPgGAOAAQAKgBBUAFQBKAFAOgDQAAACgWAMIgKAIQgHAGAAACQgRADg3ADQgxADgWAAIgLAAIg9gBg");
	mask.setTransform(18.1,2.4);

	// Layer_3
	this.instance = new lib.ClipGroup_16();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.3,1,1,0,0,0,18.3,2.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(0,0.1,36.2,4.7), null);


(lib.ClipGroup_14copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AXIAAgtIFpAAIAAAtg");
	mask.setTransform(18.1,2.4);

	// Layer_3
	this.instance = new lib.ClipGroup_15copy();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.4,1,1,0,0,0,18.3,2.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14copy, new cjs.Rectangle(0,0.1,36.2,4.7), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AXIAAgtIFpAAIAAAtg");
	mask.setTransform(18.1,2.4);

	// Layer_3
	this.instance = new lib.ClipGroup_15();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.4,1,1,0,0,0,18.3,2.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(0,0.1,36.2,4.7), null);


(lib.ClipGroup_12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEiAAIAAA1g");
	mask.setTransform(14.7,2.7);

	// Layer_3
	this.instance = new lib.ClipGroup_13copy();
	this.instance.parent = this;
	this.instance.setTransform(14.7,2.9,1,1,0,0,0,14.7,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12copy, new cjs.Rectangle(0.1,0,29.1,5.5), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEiAAIAAA1g");
	mask.setTransform(14.7,2.7);

	// Layer_3
	this.instance = new lib.ClipGroup_13();
	this.instance.parent = this;
	this.instance.setTransform(14.7,2.9,1,1,0,0,0,14.7,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0.1,0,29.1,5.5), null);


(lib.ClipGroup_11copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhyAPIgSgEQgLgKgBgOIgBgNIASABQASAAApAHQAoAIAWAAQBIAAA0gPIANgBIAOAAQAAAGgCAIQgFAMgIALIgIACIgHACIgMADQg3AJgzAAQg9AAgygMg");
	mask.setTransform(14.6,2.8);

	// Layer_3
	this.instance = new lib.ClipGroup_12copy();
	this.instance.parent = this;
	this.instance.setTransform(14.6,2.9,1,1,0,0,0,14.7,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11copy, new cjs.Rectangle(0,0.1,29.1,5.4), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhyAPIgSgEQgLgKgBgOIgBgNIASABQASAAApAHQAoAIAWAAQBIAAA0gPIANgBIAOAAQAAAGgCAIQgFAMgIALIgIACIgHACIgMADQg3AJgzAAQg9AAgygMg");
	mask.setTransform(14.6,2.8);

	// Layer_3
	this.instance = new lib.ClipGroup_12();
	this.instance.parent = this;
	this.instance.setTransform(14.6,2.9,1,1,0,0,0,14.7,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0,0.1,29.1,5.4), null);


(lib.ClipGroup_10copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEjAAIAAA1g");
	mask.setTransform(14.6,2.8);

	// Layer_3
	this.instance = new lib.ClipGroup_11copy();
	this.instance.parent = this;
	this.instance.setTransform(14.7,2.9,1,1,0,0,0,14.6,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10copy, new cjs.Rectangle(0,0.1,29.2,5.4), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEjAAIAAA1g");
	mask.setTransform(14.6,2.8);

	// Layer_3
	this.instance = new lib.ClipGroup_11();
	this.instance.parent = this;
	this.instance.setTransform(14.7,2.9,1,1,0,0,0,14.6,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0,0.1,29.2,5.4), null);


(lib.ClipGroup_8copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.6,20.8);

	// Layer_3
	this.instance = new lib.ClipGroup_9copy();
	this.instance.parent = this;
	this.instance.setTransform(35.8,20.9,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8copy, new cjs.Rectangle(0.1,0.4,71,40.9), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.6,20.8);

	// Layer_3
	this.instance = new lib.ClipGroup_9();
	this.instance.parent = this;
	this.instance.setTransform(35.8,20.9,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0.1,0.4,71,40.9), null);


(lib.ClipGroup_7copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhdDIQgqgFgCgHQAAgEgDgHQgCgGgIgMQgJgKgGgEQgogZgbgaQgmglgZgvQgcgzgRhLQgMg0gCgkQAMAWBqALQBiALCIAAQCXAABogNQBcgMAKgTQAAAdgRBEQgUBQgWAlQgeAygcAcQgVAVguAfQgOAJgHALQgIAKgCAHQgCAIABADQgGAIgqAEQgnAFg2AAQg0AAgngFg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.ClipGroup_8copy();
	this.instance.parent = this;
	this.instance.setTransform(35.7,20.6,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7copy, new cjs.Rectangle(0,0,71,41), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhdDIQgqgFgCgHQAAgEgDgHQgCgGgIgMQgJgKgGgEQgogZgbgaQgmglgZgvQgcgzgRhLQgMg0gCgkQAMAWBqALQBiALCIAAQCXAABogNQBcgMAKgTQAAAdgRBEQgUBQgWAlQgeAygcAcQgVAVguAfQgOAJgHALQgIAKgCAHQgCAIABADQgGAIgqAEQgnAFg2AAQg0AAgngFg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.ClipGroup_8();
	this.instance.parent = this;
	this.instance.setTransform(35.7,20.6,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,71,41), null);


(lib.ClipGroup_5copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8ABBTQgBBVg7A8Qg8A7hVAAQhUAAg7g7g");
	mask.setTransform(23.7,22.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgBAOIAAgBIAAgVIgBgBIgCAAIgBAAIAAgDIAAgBIALAAIAAABIAAADIAAAAIgEAAIAAAWIgBABg");
	this.shape.setTransform(25.9,8.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgEAIIgBgDIAAgIIADgFQACgCACABQADABAAADIABACIAAADIgBABIgGAAIAAAFIABABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIACgBIAAgDIADAAIABABIgBAEQgBADgDAAIgBAAQgCAAgCgDgAgBgFIAAAEIADAAIAAgEQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAg");
	this.shape_1.setTransform(29.8,8.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgEAIIAAgCIAAgPIAAAAIADAAIAAAAIAAAPQAAAAABABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQABgBAAAAQAAAAAAAAQABgBAAAAIAAgOIABAAIACAAIAAAAIAAATIAAAAIgDAAIAAAAIAAgCIgBABIgCABIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAgBg");
	this.shape_2.setTransform(27,8.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAAANIgBgBIAAABIgBABIgCAAIgBgBIAAgZIABgBIADAAIAAABIAAAIIABgCQADgBACADIAAAEQABADgBAFIAAADQAAABAAAAQAAAAAAABQgBAAAAAAQAAABgBAAIgBAAIgCgBgAAAgCIgBABIAAAKIABABIAAAAQAAAAAAAAQAAABABgBQAAAAAAAAQAAAAAAgBIABgKIgBgBIgBgBg");
	this.shape_3.setTransform(28.4,8.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAHIgBgDIAAgIIABgCQABgDADgBQADAAABADIACADIAAAIIgBADQgBADgEAAIAAABQgDAAgBgEgAAAgFIAAALQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgLIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAg");
	this.shape_4.setTransform(23.4,8.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgBAOIAAgLIAAgBIgEgOIgBgBIAEAAIAAABIADAKIACgKIABgBIADAAIgEAPIAAAMg");
	this.shape_5.setTransform(22.2,8.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AABAKIAAgCIAAABQgBAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAAAIgBgSIAFAAIAAAPIAAABIABgBIAAgCIAAgNIAFAAIAAATg");
	this.shape_6.setTransform(24.7,8.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgLAQIgGgCQgEgBAAgIIAAgHQAAgHABgCQACgDAFAAIAVgBIAHABQADAAACACIACAGIAAAOQAAAGgEAAQgEACgFAAgAgEAHIALgHIgLgGg");
	this.shape_7.setTransform(18.8,8.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgCADIAAgFIACAAIAAAEIADAAIAAABg");
	this.shape_8.setTransform(39,36.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgCADIAAgBIAEAAIAAgEIABAAIAAAFg");
	this.shape_9.setTransform(39.9,36.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAABIgDAAIAAAEg");
	this.shape_10.setTransform(39,35.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AACADIAAgEIgEAAIAAgBIAFAAIAAAFg");
	this.shape_11.setTransform(39.9,35.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgIAGIAAgLIARAAIAAALgAgHAFIAPAAIAAgJIgPAAg");
	this.shape_12.setTransform(36.6,35.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAAAIIgBgDIgBAAIgCABIgCgBIABgDIAAAAIgCgBIAAgBIACgBIAAgBIgBgCIACgCIACABIABAAIABgCIABAAIABACIABAAIACgBIACABIgBADIAAABIACABIAAABIgCABIAAAAIABADIgCABIgCgBIgBAAIgBADgAgBAAQAAABAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQAAAAAAABQAAAAAAAAg");
	this.shape_13.setTransform(33.7,35.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAAAGIAAgLIABAAIAAALg");
	this.shape_14.setTransform(7.9,35.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgDAAIAIgFIAAALg");
	this.shape_15.setTransform(8.6,35.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgDgFIAIAFIgIAGg");
	this.shape_16.setTransform(11.2,35.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAAAGIAAgLIABAAIAAALg");
	this.shape_17.setTransform(14.4,35.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgEgFIAIAFIgIAGg");
	this.shape_18.setTransform(13.7,35.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgQgVIAhAVIghAWg");
	this.shape_19.setTransform(24.3,24.9);

	this.instance = new lib.Path_1_13copy();
	this.instance.parent = this;
	this.instance.setTransform(23.8,24.9,1,1,0,0,0,4.2,4.2);
	this.instance.alpha = 0.301;

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FF4C41").s().p("AgdABIAAgBIA7AAIAAABg");
	this.shape_20.setTransform(9.7,34.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#D8E2E8").s().p("AipABIAAgBIFTAAIAAABg");
	this.shape_21.setTransform(23.7,34.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#303030").s().p("AiuBzIAAjlIFdAAIAADlg");
	this.shape_22.setTransform(23.7,25.9);

	this.instance_1 = new lib.Path_3_1copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(24.4,26.6,1,1,0,0,0,17.5,11.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FF4C41").s().p("AjqDqIAAnUIHVAAIAAHUg");
	this.shape_23.setTransform(23.5,23.5);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.instance,this.shape_20,this.shape_21,this.shape_22,this.instance_1,this.shape_23];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.instance_1},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.instance},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8ABBTQgBBVg7A8Qg8A7hVAAQhUAAg7g7g");
	this.shape_24.setTransform(23.7,22.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_24).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5copy3, new cjs.Rectangle(3.3,1.7,40.9,40.9), null);


(lib.ClipGroup_5copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljBrIAAjVILHAAIAADVg");
	mask.setTransform(36,10.7);

	// Layer_3
	this.instance = new lib.ClipGroup_6copy();
	this.instance.parent = this;
	this.instance.setTransform(36,10.8,1,1,0,0,0,36,10.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5copy2, new cjs.Rectangle(0.4,0.1,71.1,21.3), null);


(lib.ClipGroup_5copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljBrIAAjVILHAAIAADVg");
	mask.setTransform(36,10.7);

	// Layer_3
	this.instance = new lib.ClipGroup_6();
	this.instance.parent = this;
	this.instance.setTransform(36,10.8,1,1,0,0,0,36,10.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5copy, new cjs.Rectangle(0.4,0.1,71.1,21.3), null);


(lib.ClipGroup_4copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiQCRQg7g8AAhVQAAhTA7g8QA9g8BTAAQBVAAA7A8QA9A8gBBTQABBVg9A8Qg7A7hVAAQhUAAg8g7g");
	mask.setTransform(85.8,69.1);

	// Layer_3
	this.instance = new lib.Path_16copy();
	this.instance.parent = this;
	this.instance.setTransform(76.4,65,1,1,0,0,0,7.1,7.2);
	this.instance.alpha = 0.129;

	this.instance_1 = new lib.Path_1_11copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(76.3,64.9,1,1,0,0,0,5.5,5.5);
	this.instance_1.alpha = 0.5;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#555369").s().p("AgcAdQgLgMAAgRQAAgPALgNQAMgMAQAAQARAAAMAMQAQARgGAVIgKgDQAEgPgMgNQgIgIgNAAQgMAAgIAIQgJAKAAALQAAAMAJAJQAMAMAPgEIACAKIgJABQgPABgNgMg");
	this.shape.setTransform(76.4,64.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#555369").s().p("AgUgMIAHgIIAiAiIgIAHg");
	this.shape_1.setTransform(84.5,70.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#555369").s().p("AAdBeQgNgFgMAAIg1ABQgKAAgIgIQgHgIABgLQABgJAHgGQAHgGAJAAIAPAAIhchbQgIgHABgLQAAgKAJgIQAGgFAJAAQAKAAAIAIIAqAqQABgJAHgFQAHgGAIAAIAJACQABgJAIgIQAGgFAIAAQAHAAAGAEQABgKAHgGQAHgFAIAAQAKAAAIAIIAyAxQAWAXACAeQACAfgTAYQgZAegmAAQgMAAgNgEgAAgBUQAKADAMAAQAhAAAWgaQARgVgCgbQgCgagUgTIgxgyQgEgEgGAAQgFgBgEAEQgEADgBAGQAAAGAEAFIgHAHIgKgJQgDgEgGAAQgFgBgDADQgFAEAAAGQAAAHAEAEIgIAHIgFgGQgEgEgGAAQgFgBgEAEQgEADgBAHQAAAGAEAEIgIAHIg4g4QgDgEgGAAQgGgBgEADQgEAEAAAGQgBAGAEAFIBvBsIgoAAQgGAAgEAEQgEADgBAFQAAAGAEAFQAEAEAGAAIA1AAQAMAAAQAFg");
	this.shape_2.setTransform(88.4,72.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#EFF9FF","#BDE5FF"],[0,0.227,1],-80,-92.1,80.1,92.1).s().p("AtgNhIAA7BIbBAAIAAbBg");
	this.shape_3.setTransform(86.5,86.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.shape,this.shape_1,this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiQCRQg7g8AAhVQAAhTA7g8QA9g8BTAAQBVAAA7A8QA9A8gBBTQABBVg9A8Qg7A7hVAAQhUAAg8g7g");
	this.shape_4.setTransform(85.8,69.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4copy3, new cjs.Rectangle(65.3,48.7,40.9,40.9), null);


(lib.ClipGroup_3copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiQCRQg7g8gBhVQABhTA7g8QA8g8BUAAQBVAAA7A8QA9A8AABTQAABVg9A8Qg7A7hVAAQhUAAg8g7g");
	mask.setTransform(20.8,25.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4DDC9").s().p("AACAGQgJAAABgCIADgJIADgBIABAAQAGABAAAGQAAAGgEAAIgBgBg");
	this.shape.setTransform(14.1,34.8);

	this.instance = new lib.Path_14copy();
	this.instance.parent = this;
	this.instance.setTransform(15.7,37.9,1,1,0,0,0,1.5,4);
	this.instance.alpha = 0.602;

	this.instance_1 = new lib.Path_1_9copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(21.1,41.7,1,1,0,0,0,0.7,2.1);
	this.instance_1.alpha = 0.898;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EAC2A7").s().p("AgLABIAIgZQACgDACAAQAEgBADACIABABQADADAAAFIgEAcQAAAOADADQgSgHgEgUg");
	this.shape_1.setTransform(14.1,36.7);

	this.instance_2 = new lib.Path_12copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(30.7,33.2,1,1,0,0,0,2.3,0.6);
	this.instance_2.alpha = 0.5;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F4DDC9").s().p("AgBAFQgFAAAAgFQAAgEAFAAIADAAQAFAAAAAEQAAAFgFAAg");
	this.shape_2.setTransform(29.3,34.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C69C6D").s().p("AglABIA6hBIARAQIAABwg");
	this.shape_3.setTransform(39.1,36.2);

	this.instance_3 = new lib.Path_10copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(35.2,25.1,1,1,0,0,0,5,4.7);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.Path_1_8copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(30.5,22.9,1,1,0,0,0,2.5,2);
	this.instance_4.alpha = 0.5;

	this.instance_5 = new lib.Path_2_4copy();
	this.instance_5.parent = this;
	this.instance_5.setTransform(29.1,24.4,1,1,0,0,0,2.6,2);
	this.instance_5.alpha = 0.5;

	this.instance_6 = new lib.Path_3_0copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(27.6,26.3,1,1,0,0,0,2.5,1.9);
	this.instance_6.alpha = 0.5;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F4DDC9").s().p("AgBAFIgCgCQgDgDACgDQAEgEACADIACACQAEADgDADQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAIgCgBg");
	this.shape_4.setTransform(30.4,21.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F4DDC9").s().p("AgBAFIgDgCQgEgDADgEQABgBAAAAQAAAAABgBQAAAAABAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABABQAAAAABAAIACADQAFADgEAEQgBAAAAABQgBAAAAABQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAgBQgBAAAAgBg");
	this.shape_5.setTransform(26.7,23.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F4DDC9").s().p("AgCAGIgCgDQgFgDAEgEQAEgEADADIADADQAFACgEAFQgBABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAgBQgBAAAAAAQAAAAAAgBQgBAAgBAAg");
	this.shape_6.setTransform(28.3,21.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F4DDC9").s().p("AgCAGIgCgDQgFgDAEgEQAEgEADADIADADQAFACgEAFQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAIgDgBg");
	this.shape_7.setTransform(25.4,25.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EAC2A7").s().p("AAlBKIgJgFIhAAAQgGABgCgKIABgEQACgEADgBQApgFgGgBIhJhAQgJgIAFgFQAGgGAGAFIAmAfQABABABAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBABAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgJgIIAAAAIAAgBIgfgaQgFgFAEgGIABgBQACgCAEgBQADAAADACIAdAaIABAAIAAAAIALAKQABAAAAABQABAAAAAAQABAAAAgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQgBAAAAgBIgIgGIgBgBIgggcQgDgCAAgDQAAgDACgCQAFgGAGAEIAeAaIABAAIAAABIAAAAIAJAIIAAABIACAAIABgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAIAAgBIgegaQgGgFAFgFIAAAAQAFgEADAEIAZATIAAAAIATAPIABABIAnAlQAEACAKAVIAEAEQACAGgJAJIgYAeQgDAEgEABIgCAAQgDAAgCgCg");
	this.shape_8.setTransform(32.8,28);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C69C6D").s().p("AgvAYIAFgvIBaAIIgCAng");
	this.shape_9.setTransform(17.2,45.6);

	this.instance_7 = new lib.Group_3copy3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(14.3,36.1,1,1,0,0,0,1.2,2.2);
	this.instance_7.alpha = 0.199;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0071BC").s().p("AAGATIgOgGQgDgBABgDQABgEADABIAKAFIgBgaQAAgEAEAAQABAAAAABQABAAAAAAQABABAAAAQAAABAAABIABAfQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAIgCABIgCgBg");
	this.shape_10.setTransform(11.6,24.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0071BC").s().p("AAHAUIgPgGQgDgCABgDQABgEADABIAKAEIgBgZQAAgEAEAAQABAAAAAAQABABAAAAQABAAAAABQAAABAAABIABAfQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAABIgCABIgBAAg");
	this.shape_11.setTransform(8.9,20.3);

	this.instance_8 = new lib.Group_4copy3();
	this.instance_8.parent = this;
	this.instance_8.setTransform(33.3,28.2,1,1,0,0,0,8.2,7.7);
	this.instance_8.alpha = 0.102;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#666666").ss(0.3,1,1).p("Ag8AjIB5hF");
	this.shape_12.setTransform(25,29.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#666666").ss(0.3,1,1).p("Ag9AjIB6hF");
	this.shape_13.setTransform(25.7,30.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#666666").ss(0.3,1,1).p("Ag8AjIB5hF");
	this.shape_14.setTransform(24.4,28.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#666666").ss(0.3).p("AARAAQACACgBADQgBADgDACIgMAHQgHADgEgGIgGgMQgFgGAIgFIAMgGQACgCADABQADABACADg");
	this.shape_15.setTransform(11.7,25.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#666666").ss(0.3).p("AARAAQABACgBADQgBADgDACIgMAHQgCACgDgBQgDgBgCgDIgHgMQgDgHAGgEIAMgGQAGgFAFAIg");
	this.shape_16.setTransform(16.9,34.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#666666").ss(0.3).p("AARgBQAEAGgHAFIgMAGQgGAFgFgIIgGgMQgFgGAIgEIAMgHQAGgEAEAHg");
	this.shape_17.setTransform(14.2,29.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#666666").ss(0.3).p("AARAAQAEAGgHAEIgMAHQgHADgEgGIgGgMQgFgGAIgFIAMgHQAGgDAEAHg");
	this.shape_18.setTransform(9.2,21);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#666666").ss(0.3,1,1).p("Ag8AjIB5hF");
	this.shape_19.setTransform(22.4,25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#666666").ss(0.3,1,1).p("Ag8AjIB6hF");
	this.shape_20.setTransform(23.1,26.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#666666").ss(0.3,1,1).p("Ag9AjIB6hF");
	this.shape_21.setTransform(21.8,23.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#666666").ss(0.3,1,1).p("Ag5AhIBzhB");
	this.shape_22.setTransform(17,16.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#666666").ss(0.3,1,1).p("Ag5AhIBzhB");
	this.shape_23.setTransform(17.7,17.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#666666").ss(0.3,1,1).p("Ag5AhIBzhB");
	this.shape_24.setTransform(16.4,15.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#666666").ss(0.3,1,1).p("Ag6AiIB1hC");
	this.shape_25.setTransform(19.7,20.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#666666").ss(0.3,1,1).p("Ag6AiIB1hD");
	this.shape_26.setTransform(20.4,22);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#666666").ss(0.3,1,1).p("Ag6AhIB1hC");
	this.shape_27.setTransform(19,19.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#666666").ss(0.3,1,1).p("AghATIBDgm");
	this.shape_28.setTransform(13.8,13.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#4D4D4D").s().p("AghARIBAglIADAEIhCAlg");
	this.shape_29.setTransform(12.7,11.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#666666").s().p("AglAHIAXgRIAGgBIAEgEIAagKIAQATIgEgEIhAAlgAAOgNIglAUQAAABgBAAQAAABAAAAQgBABAAAAQAAAAABABQAAAAABABQAAAAAAAAQABAAAAAAQABAAAAAAIAmgVQAAAAABgBQAAAAAAAAQAAgBAAAAQAAgBAAgBIgCgBIgCABg");
	this.shape_30.setTransform(12.4,10.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#666666").s().p("AgJAGQgCgEABgEQACgEADgDQAEgCAEABQAEACADAEQACADgBADIgCABIgFAFIgEABIgDACQgEgCgCgDgAgBgDQgEACACAEQADAEADgDQAEgCgDgDQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBAAIgCABg");
	this.shape_31.setTransform(11,8.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#B3B3B3").s().p("AgCAEIADgIIACAAIgDAJg");
	this.shape_32.setTransform(9.9,34.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#B3B3B3").s().p("AgCAEIADgIIACAAIgDAJg");
	this.shape_33.setTransform(9.5,34.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#B3B3B3").s().p("AgCAEIADgIIACAAIgDAJg");
	this.shape_34.setTransform(9.1,34.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#8C8C8C").s().p("AgHADIAEgJIALAEIgFAJg");
	this.shape_35.setTransform(9.4,34.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3FA2FF").s().p("AgCAAIABgBIAEADg");
	this.shape_36.setTransform(20.1,39);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#E57225").s().p("AADAHIgFgDQgHgCADgEQACgGAFADIAGADIABAAIgEAJg");
	this.shape_37.setTransform(8.2,33.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3FA2FF").s().p("AAsAWIhZgnQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAIBZAnQAAABABAAQAAAAAAAAQAAABAAAAQAAAAAAABIgCABIgBAAg");
	this.shape_38.setTransform(13.3,35.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#5DB3F9").s().p("AAsAWIhZgoQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAIBZAoQAAAAABAAQAAAAAAABQAAAAAAAAQAAABAAAAIgBABIgCAAg");
	this.shape_39.setTransform(13.2,36);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3F9DEA").s().p("AAsAWIhZgnQAAgBgBAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAIBZAnQAAABABAAQAAAAAAAAQAAABAAAAQAAAAAAABIgCABIgBAAg");
	this.shape_40.setTransform(13,36.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FBB03B").s().p("AgJADIgIgDIAEgJIAIADIAYAQg");
	this.shape_41.setTransform(18.6,38.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#E9E7DA").s().p("AiUg9ICrhiIB+DeIiqBhg");
	this.shape_42.setTransform(18.5,22.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#CCCCCC").s().p("AiVg/ICqhiICBDiIirBhg");
	this.shape_43.setTransform(19.2,22.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#CCCCCC").s().p("AgGAAQAAgGAGAAQAHAAAAAGQAAAHgHAAQgGAAAAgHg");
	this.shape_44.setTransform(37.3,20.6);

	this.instance_9 = new lib.Path_1_7copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(37.7,20.6,1,1,0,0,0,0.7,0.7);
	this.instance_9.alpha = 0.102;

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#CCCCCC").s().p("AgGAAQAAgGAGAAQAHAAAAAGQAAAHgHAAQgGAAAAgHg");
	this.shape_45.setTransform(4,10.5);

	this.instance_10 = new lib.Path_1_6copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(4.5,10.5,1,1,0,0,0,0.7,0.7);
	this.instance_10.alpha = 0.102;

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#CCCCCC").s().p("AADALIgNgLQgEgEADgFQAEgEAFADIANALQAFADgEAFQgDADgCAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_46.setTransform(3.5,30.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#CCCCCC").s().p("AgKALIAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBQABgBAAAAIAMgMQAFgEAEAEIAAAAQAAABABAAQAAABAAAAQAAABABAAQAAABAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAAAIgMANQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_47.setTransform(3.5,30.5);

	this.instance_11 = new lib.Group_1_0copy3();
	this.instance_11.parent = this;
	this.instance_11.setTransform(4.5,30.5,1,1,0,0,0,1.3,1.2);
	this.instance_11.alpha = 0.102;

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#CCCCCC").s().p("AADALIgNgLQgEgEADgEIAAgBQAEgEAFADIANALQAEADgDAGQgDACgCAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_48.setTransform(26.6,42.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#CCCCCC").s().p("AgKALQgEgEAEgFIAMgMQAFgEAEAEQAEAFgEAEIgMAMQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_49.setTransform(26.6,42.6);

	this.instance_12 = new lib.Group_1copy6();
	this.instance_12.parent = this;
	this.instance_12.setTransform(27.6,42.7,1,1,0,0,0,1.3,1.3);
	this.instance_12.alpha = 0.102;

	this.instance_13 = new lib.Group_16copy();
	this.instance_13.parent = this;
	this.instance_13.setTransform(39.8,35.7,1,1,0,0,0,3.1,6.2);
	this.instance_13.alpha = 0.102;

	this.instance_14 = new lib.Path_9copy();
	this.instance_14.parent = this;
	this.instance_14.setTransform(29.1,26,1,1,0,0,0,2.5,1.9);
	this.instance_14.alpha = 0.5;

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#E57225").s().p("AgTC0QgEgBgBgCIiLj0QgEgHAHgDICwhlQAGgEAEAHICLDzQACADgBADQgBABAAABQAAAAAAABQgBAAAAABQgBAAAAAAIiwBlIgEACIgCgBg");
	this.shape_50.setTransform(19.4,23.8);

	this.instance_15 = new lib.Path_11copy();
	this.instance_15.parent = this;
	this.instance_15.setTransform(29.3,18.5,1,1,0,0,0,8.2,12.9);
	this.instance_15.alpha = 0.102;

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#808080").s().p("AgiAQIBBgkIAEAEIhDAlg");
	this.shape_51.setTransform(13.7,10.5);

	this.instance_16 = new lib.Group_17copy();
	this.instance_16.parent = this;
	this.instance_16.setTransform(13.4,10.2,1,1,0,0,0,3.8,3.1);
	this.instance_16.alpha = 0.102;

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#EAC2A7").s().p("AgUBTQgFAAgEgCQgFgDAAgEIABgKQgRgoAGgNQALgZAAggIgCgaQAAgFACgDQADgEAEABQAJAAAAAIIABAxQAAABAAABQAAAAAAABQABAAAAAAQABABABAAQAAAAABgBQABAAAAAAQAAgBABAAQAAgBAAgBIABg2IADgDIAHgBQAEAAABAEIAAA8IAAgBIACAAQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIAAg4QAAgGAIAAQAIAAAAAHIAAA4QAAAAAAAAQAAABAAAAQAAAAABAAQAAABABAAQAAAAAAgBQABAAAAAAQAAAAAAAAQAAgBAAAAIABgBIgBgzQACgDADgBIAFACQAFAAACAsIgEBOQAAAFgJAVQABAOgFAAg");
	this.shape_52.setTransform(17.4,35.7);

	this.instance_17 = new lib.Path_13copy();
	this.instance_17.parent = this;
	this.instance_17.setTransform(26.7,39.5,1,1,0,0,0,7.2,8.4);
	this.instance_17.alpha = 0.102;

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#7FB1B5").s().p("AjhD7IAAn1IHDAAIAAH1g");
	this.shape_53.setTransform(22.6,25.1);

	var maskedShapeInstanceList = [this.shape,this.instance,this.instance_1,this.shape_1,this.instance_2,this.shape_2,this.shape_3,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.instance_7,this.shape_10,this.shape_11,this.instance_8,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.instance_9,this.shape_45,this.instance_10,this.shape_46,this.shape_47,this.instance_11,this.shape_48,this.shape_49,this.instance_12,this.instance_13,this.instance_14,this.shape_50,this.instance_15,this.shape_51,this.instance_16,this.shape_52,this.instance_17,this.shape_53];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53},{t:this.instance_17},{t:this.shape_52},{t:this.instance_16},{t:this.shape_51},{t:this.instance_15},{t:this.shape_50},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.shape_49},{t:this.shape_48},{t:this.instance_11},{t:this.shape_47},{t:this.shape_46},{t:this.instance_10},{t:this.shape_45},{t:this.instance_9},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.instance_8},{t:this.shape_11},{t:this.shape_10},{t:this.instance_7},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.shape_3},{t:this.shape_2},{t:this.instance_2},{t:this.shape_1},{t:this.instance_1},{t:this.instance},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AiQCRQg7g8gBhVQABhTA7g8QA8g8BUAAQBVAAA7A8QA9A8AABTQAABVg9A8Qg7A7hVAAQhUAAg8g7g");
	this.shape_54.setTransform(20.8,25.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_54).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3copy3, new cjs.Rectangle(0.3,4.7,40.9,40.9), null);


(lib.ClipGroup_3copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjBAVIAAgpIGDAAIAAApg");
	mask.setTransform(19.4,2.1);

	// Layer_3
	this.instance = new lib.ClipGroup_4copy2();
	this.instance.parent = this;
	this.instance.setTransform(19.4,2.1,1,1,0,0,0,19.3,2.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3copy2, new cjs.Rectangle(0.1,0,38.7,4.3), null);


(lib.ClipGroup_3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjBAVIAAgpIGDAAIAAApg");
	mask.setTransform(19.4,2.1);

	// Layer_3
	this.instance = new lib.ClipGroup_4copy();
	this.instance.parent = this;
	this.instance.setTransform(19.4,2.1,1,1,0,0,0,19.3,2.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3copy, new cjs.Rectangle(0.1,0,38.7,4.3), null);


(lib.ClipGroup_2copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	mask.setTransform(20.5,20.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3F3F5").s().p("AhmB2QgFAAgFgEIAAgBQgFgEAAgGIAAjNQAAgGAFgEQAEgFAGAAIDNAAQAGAAADAEIABAAIACACQADAEAAAFIAADNQAAAGgFAEQgEAFgGAAgAAGBpIBhAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAgBAAAAIAAhhIgkAAQgGAAAAgGQAAgGAEgFQADgEAAgFQAAgFgEgFQgEgDgGAAIgBAAQgFAAgEAEQgEAEAAAFQAAAFADAEQAEAFAAAGQAAAGgGAAIglAAIAAAcQAHgFAIAAIABAAQAKABAHAHQAIAHAAALQABALgIAIQgIAIgLAAQgIAAgHgEgAhoBnQAAAAAAABQAAAAAAABQABAAAAAAQABAAAAAAIBhAAIAAgkQAAgHAFAAQAHAAAFAFQAEACAFAAQAGAAAEgEQAEgEAAgGQgBgFgEgEQgDgEgGAAQgFAAgEADQgFAEgHAAQgFAAAAgGIAAglIgcAAQAFAHAAAIQgBALgHAHQgHAHgLABIgBAAQgKAAgIgIQgIgIAAgLQAAgHAEgHIgbAAgAhohmIAABhIAkAAQAHAAAAAFQAAAHgEAFQgDAEAAAEQAAAGAEAEQAEAEAFAAIABAAQAFAAAEgEQAEgEAAgFQAAgFgDgEQgEgFAAgHQAAgFAGAAIAlAAIAAgcQgHAEgHAAIgBAAQgKAAgIgHQgHgIgBgKQAAgLAIgIQAIgIALAAQAIAAAGAEIAAgbIhhAAQAAAAgBAAQAAAAgBAAQAAABAAAAQAAABAAAAgAA4guQAKAAAIAHQAIAIAAALQAAAIgEAHIAbAAIAAhhQAAAAAAgBQAAAAAAgBQgBAAAAAAQgBAAAAAAIhhAAIAAAkQAAAGgGAAQgFAAgGgEQgDgDgFAAQgGAAgEAFQgEAEAAAGQAAAFAEAEQAEAEAFAAQAFAAAEgDQAGgEAFAAQAGAAAAAGIAAAlIAcAAQgEgHAAgIQAAgLAHgHQAIgHAKgBg");
	this.shape.setTransform(19.1,18.7);

	this.instance = new lib.Path_6copy();
	this.instance.parent = this;
	this.instance.setTransform(27,22,1,1,0,0,0,19.7,15.1);
	this.instance.alpha = 0.352;

	var maskedShapeInstanceList = [this.shape,this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiPCRQg9g8AAhVQAAhTA9g8QA7g8BUAAQBVAAA8A8QA7A8AABTQAABVg7A8Qg8A7hVAAQhUAAg7g7g");
	this.shape_1.setTransform(20.5,20.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2copy3, new cjs.Rectangle(0,0,40.9,40.9), null);


(lib.ClipGroup_1copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjDAVIAAgpIGHAAIAAApg");
	mask.setTransform(19.6,2.1);

	// Layer_3
	this.instance = new lib.ClipGroup_2copy2();
	this.instance.parent = this;
	this.instance.setTransform(19.6,2.1,1,1,0,0,0,19.6,2.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1copy2, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.ClipGroup_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjDAVIAAgpIGHAAIAAApg");
	mask.setTransform(19.6,2.1);

	// Layer_3
	this.instance = new lib.ClipGroup_2copy();
	this.instance.parent = this;
	this.instance.setTransform(19.6,2.1,1,1,0,0,0,19.6,2.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1copy, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.ClipGroup_1_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ABxBmIiCgKQhPgHgygDQhLgEhPAAQgohKgOhAQgBgWCEgNQBrgLBxAAQB6AABjAKQCFAMAEAYQgKAhgcA0IgvBSQhPAAhOgFg");
	mask.setTransform(35.7,10.7);

	// Layer_3
	this.instance = new lib.ClipGroup_5copy2();
	this.instance.parent = this;
	this.instance.setTransform(35.6,10.8,1,1,0,0,0,36,10.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0copy, new cjs.Rectangle(0.2,0,71,21.4), null);


(lib.ClipGroup_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ABxBmIiCgKQhPgHgygDQhLgEhPAAQgohKgOhAQgBgWCEgNQBrgLBxAAQB6AABjAKQCFAMAEAYQgKAhgcA0IgvBSQhPAAhOgFg");
	mask.setTransform(35.7,10.7);

	// Layer_3
	this.instance = new lib.ClipGroup_5copy();
	this.instance.parent = this;
	this.instance.setTransform(35.6,10.8,1,1,0,0,0,36,10.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0, new cjs.Rectangle(0.2,0,71,21.4), null);


(lib.arrow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}
	this.frame_11 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11).call(this.frame_11).wait(1));

	// Layer_1
	this.instance = new lib.Tween17("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(31,48.5,0.689,1);

	this.instance_1 = new lib.Tween15("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(31,28,1,0.713);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween16("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(31,48.5,0.619,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},6).to({state:[{t:this.instance_2}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,scaleX:1,scaleY:0.71,y:28},6).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},6).to({_off:true,scaleX:0.62,scaleY:1,y:48.5},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9.7,0,42.7,97);


(lib.Tween57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.colo_bac1 = new lib.Symbol1copy11();
	this.colo_bac1.name = "colo_bac1";
	this.colo_bac1.parent = this;
	this.colo_bac1.setTransform(-21.3,161.3,0.63,0.627,0,0,0,272.1,37);

	this.instance = new lib.question();
	this.instance.parent = this;
	this.instance.setTransform(157.2,-138.1,0.557,0.557);

	this.instance_1 = new lib.question();
	this.instance_1.parent = this;
	this.instance_1.setTransform(157.2,76.9,0.557,0.557);

	this.instance_2 = new lib.question();
	this.instance_2.parent = this;
	this.instance_2.setTransform(157.2,-33.1,0.557,0.557);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.colo_bac1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(157.2,-138.1,35.7,250.7);


(lib.Tween56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.colo_bac1 = new lib.Symbol1copy11();
	this.colo_bac1.name = "colo_bac1";
	this.colo_bac1.parent = this;
	this.colo_bac1.setTransform(-21.3,161.3,0.63,0.627,0,0,0,272.1,37);

	this.instance = new lib.question();
	this.instance.parent = this;
	this.instance.setTransform(157.2,-138.1,0.557,0.557);

	this.instance_1 = new lib.question();
	this.instance_1.parent = this;
	this.instance_1.setTransform(157.2,76.9,0.557,0.557);

	this.instance_2 = new lib.question();
	this.instance_2.parent = this;
	this.instance_2.setTransform(157.2,-33.1,0.557,0.557);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.colo_bac1}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(157.2,-138.1,35.7,250.7);


(lib.Symbol29copy7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.box_22 = new lib.Symbol41copy6();
	this.box_22.name = "box_22";
	this.box_22.parent = this;
	this.box_22.setTransform(34,47.7,0.876,0.876,0,0,0,38.8,54.4);

	this.timeline.addTween(cjs.Tween.get(this.box_22).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60.5,89.6);


(lib.Symbol7copy4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{tst:5,score:6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
		
		this.start_tst.addEventListener("mousedown", onstartest.bind(this));
		
				function onstartest(event){
					this.gotoAndStop("tst");
				}
	}
	this.frame_5 = function() {
		this.stop();
		//creat question Array
		//    0          1           2            3
		var data = [{
			 
			//question numer one
			questin_text: "وحدة قياس الكثافة هي ..........",
			answer: "2",
			answers: ["جم", "سم³", "جم/سم³", "جم.سم³"]
		}, 
		{
			//question numer tow
			questin_text: "اذا كانت كثافة الحديد 7,8 جم/سم³ فإن كتلة 10 سم³ منه تساوي ........ جم",
			answer: "1",
			answers: ["78", "7,8", "0,78", "0."]
		}, 
		{
			//question numer three
			questin_text: "كثافة زيت البترول .............. كثافة الماء",
			answer: "0",
			answers: ["أقل من", "تساوي ", "أكبر من", "أكبر من ضعف"]
		},
		{
			//question numer 4
			questin_text: "من المواد التي تطفو فوق سطح الماء ...........",
			answer: "0",
			answers: ["الحديد", "النحاس ", "الفلين", "الزلط"]
		},
		{
			//question numer 5
			questin_text: "عند ضع كرة مصمته كتلتها 25 جم وحجمها 10 سم3 في الماء، فإنها ............. علما بأن كثافة الماء 1 جم /سم3",
			answer: "0",
			answers: ["تطفو", "تغوص ", "تذوب", "تلين"]
		},
		{
			//question numer 6
			questin_text: "يستخدم غاز ............ في ملء بالونات الاحتفالات",
			answer: "0",
			answers: ["الأكسجين", "النيتروجين ", "الهيدروجين", "النيون"]
		},
		{
			//question numer 7
			questin_text: "الكثافة تساوي ........... / الحجم ",
			answer: "0",
			answers: ["الكتلة", "الوزن ", "الطول", "المحيط"]
		},
		{
			//question numer 8
			questin_text: "الفلين من المواد التي ...........عند وضعها في الماء",
			answer: "1",
			answers: ["تطفو", " تغوص ", "تذوب", "تلين"]
		},
		{
			//question numer 9
			questin_text: "عند وضع جسم صلب كثافته عالية في سائل أقل كثافة فإن الجسم الصلب ........ ",
			answer: "0",
			answers: ["يغوص", "يطفو ", "يذوب", "يعلق"]
		},
		{
			//question numer 10
			questin_text: "كثافة زيت البترول .............. كثافة الماء",
			answer: "0",
			answers: ["أقل من", "تساوي ", "أكبر من", "أكبر من ضعف"]
		},
		{
			//question numer 11
			questin_text: "كثافة زيت البترول .............. كثافة الماء",
			answer: "0",
			answers: ["أقل من", "تساوي ", "أكبر من", "أكبر من ضعف"]
		},
		{
			//question numer 12
			questin_text: "كثافة زيت البترول .............. كثافة الماء",
			answer: "0",
			answers: ["أقل من", "تساوي ", "أكبر من", "أكبر من ضعف"]
		},
		{
			//question numer 13
			questin_text: "كثافة زيت البترول .............. كثافة الماء",
			answer: "0",
			answers: ["أقل من", "تساوي ", "أكبر من", "أكبر من ضعف"]
		},
		{
			//question numer 14
			questin_text: "كثافة زيت البترول .............. كثافة الماء",
			answer: "0",
			answers: ["أقل من", "تساوي ", "أكبر من", "أكبر من ضعف"]
		},
		{
			//question numer 15
			questin_text: "كثافة زيت البترول .............. كثافة الماء",
			answer: "0",
			answers: ["أقل من", "تساوي ", "أكبر من", "أكبر من ضعف"]
		},
		
		
		];
		 
		 //random questions 
		data= mixed(data);
		 function mixed(Items)
		{
			var newArray= [];
			var orginal=Items.concat();
			while(orginal.length >0)
			{
				var r = Math.floor(Math.random()*(orginal.length));
				  newArray.push(orginal[r]);
				  orginal.splice(r,1);
				
				
			}
			return newArray;
		}
		
		
		
		
		console.log(data.length);
		
		//varibles
		var indexQuestion=0;
		// السؤال الحالى
		var currentQuestion=data[indexQuestion];
		
		var IsAnswer=false;
		var newqus = false;
		var score=0;
		var num_qus = 0;
		// loadQuestion
		num_qus =0;
		loadQuestion.bind(this)();
			function loadQuestion(e)
				{
					exportRoot.bord_5.question.gotoAndPlay("appear");
					num_qus +=1;
					// عرض السؤال
					exportRoot.bord_5.question.txt_question.text=currentQuestion.questin_text;
					exportRoot.bord_5.question.num_question.text = num_qus;
					//عرض  بدائل الاجابة
					exportRoot.bord_5.question.answer0.txt_answer.text=currentQuestion.answers[0];
					exportRoot.bord_5.question.answer1.txt_answer.text=currentQuestion.answers[1];
					exportRoot.bord_5.question.answer2.txt_answer.text=currentQuestion.answers[2];
					exportRoot.bord_5.question.answer3.txt_answer.text=currentQuestion.answers[3];
					
					exportRoot.bord_5.question.answer0.gotoAndStop(0);
					exportRoot.bord_5.question.answer1.gotoAndStop(0);
					exportRoot.bord_5.question.answer2.gotoAndStop(0);
				    exportRoot.bord_5.question.answer3.gotoAndStop(0);
				}
				
				exportRoot.bord_5.question.answer0.on("click",onClickAnswer.bind(this));
				exportRoot.bord_5.question.answer1.on("click",onClickAnswer.bind(this));
				exportRoot.bord_5.question.answer2.on("click",onClickAnswer.bind(this));
				exportRoot.bord_5.question.answer3.on("click",onClickAnswer.bind(this));
				
				exportRoot.bord_5.question.answer0.name = "answer0";
				exportRoot.bord_5.question.answer1.name = "answer1";
				exportRoot.bord_5.question.answer2.name = "answer2";
				exportRoot.bord_5.question.answer2.name = "answer3";
		function onClickAnswer(e)
		{
			newqus = true;
			if(IsAnswer==false)
			{ 
				var item=e.currentTarget;
				if(item.name=="answer"+currentQuestion.answer)
				{
						item.gotoAndStop("good");
							score+=100;
				        	exportRoot.pointplus();
						
				}else{
					item.gotoAndStop("bad");
				}
				IsAnswer=true;
			}
			createjs.Tween.get(this)
			.wait(1000)
			.call( function ()
			{
				exportRoot.bord_5.question.gotoAndStop("out")
			}.bind(this)
			
			
			)
			.wait(600)
			.call( function ()
			{
				exportRoot.bord_5.question.play();
			}.bind(this))
			.wait(100)
			.call(loadNextq.bind(this))
		}
		
		
		
		function loadNextq(e)
		{
			indexQuestion++;
			//if(indexQuestion==data.length)
			if(num_qus == 10)
			{
				//exportRoot.parent.changePage(new lib.mc_over())
				//exportRoot.bord_5.gotoAndStop("score");
				exportRoot.bord_5.question.visible = false;
				exportRoot.bord_5.massege.text = "انتهي الاختبار ولقد حصلت على " +  score  + "نقطة وتم تسجيلها في حسابك على المنصة اذا كانت هذه اول مرة تجري فيها الاختبار"
				num_qus = 0;
				stage.SCORE=score;
			}else{
				currentQuestion=data[indexQuestion];
				IsAnswer=false;
				loadQuestion.bind(this)();
				startTimer();
			}
		}
		//////////////////////////////////////////////////////////// timer
		function startTimer(){
					var sec = 40;
					var timer = setInterval(function(){
						exportRoot.bord_5.text_scored.text ='00:'+sec + "باقي من الوقت";
						sec--;
						if(newqus == true){
									clearInterval(timer);
									newqus = false;
									
								}else if (sec < 0 ) {
									 clearInterval(timer);
									 newqus = false;
									 loadNextq();
								}
		
					}, 1000);
				}
				 startTimer();
		
		
		
		//  كانت هذه نظرة سريعة على الملف والمكونات  والشاشات الاساسية
		//  تابع ايضا
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(1).call(this.frame_5).wait(2));

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_1_graphics_2 = new cjs.Graphics().p("EhLKATYMAAAgmvMCWVAAAMAAAAmvg");
	var mask_1_graphics_3 = new cjs.Graphics().p("EhO8AlTMAAAhKlMCd5AAAMAAABKlg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EhSuA3OMAAAhubMCldAAAMAAABubg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_1_graphics_2,x:267.9,y:101.8}).wait(1).to({graphics:mask_1_graphics_3,x:268.9,y:212.9}).wait(1).to({graphics:mask_1_graphics_4,x:269.5,y:324}).wait(3));

	// Layer_1
	this.start_tst = new lib.Symbol59_1();
	this.start_tst.name = "start_tst";
	this.start_tst.parent = this;
	this.start_tst.setTransform(253,596.5);
	this.start_tst._off = true;
	new cjs.ButtonHelper(this.start_tst, 0, 1, 1);

	var maskedShapeInstanceList = [this.start_tst];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.start_tst).wait(1).to({_off:false},0).to({_off:true},4).wait(2));

	// Layer_5
	this.text_2 = new cjs.Text("هل أنت جاهز !", "20px 'Arial'", "#E87E00");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 36;
	this.text_2.lineWidth = 110;
	this.text_2.parent = this;
	this.text_2.setTransform(263,484.8,1.755,1.755);

	this.text_3 = new cjs.Text(":تعليمات الاختبار", "47px 'Arial'", "#000033");
	this.text_3.textAlign = "right";
	this.text_3.lineHeight = 58;
	this.text_3.lineWidth = 437;
	this.text_3.parent = this;
	this.text_3.setTransform(739.6,102.2);

	this.text_4 = new cjs.Text(".يمنحك هذا الاختبار 20 نقطة، حيث تحصل على نقطتين لكل إجابة صحيحة -\n.يتكن الاختبار من 10 أسئلة عشوائية غير ثابتة -\n.زمن الإجابة على كل سؤال 40 ثانية بعدها يت م الانتقال للسؤال التالي مباشرة -\n.بمجرد الإجابة على السؤال يتم الانتقال للسؤال التالي، لذا فكر جيداً قبل الإجابة -\n.يتم إضافة النقاط التي حصلت عليها في أول محاولة فقط إلى نقاطك في المنصة -", "20px 'Arial'", "#330000");
	this.text_4.textAlign = "right";
	this.text_4.lineHeight = 32;
	this.text_4.lineWidth = 529;
	this.text_4.parent = this;
	this.text_4.setTransform(751.4,180.6,1.755,1.755);

	this.text_5 = new cjs.Text("اختبارات", "26px 'Arial'", "#E87E00");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 45;
	this.text_5.parent = this;
	this.text_5.setTransform(139.2,3.5,1.755,1.755);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape_1.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text_2,this.text_3,this.text_4,this.text_5,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2}]},1).to({state:[]},4).wait(2));

	// Layer_8
	this.text_6 = new cjs.Text("اختبارات", "26px 'Arial'", "#E87E00");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 45;
	this.text_6.parent = this;
	this.text_6.setTransform(139.2,3.5,1.755,1.755);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape_2.setTransform(151.4,89.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.text_6}]},5).wait(2));

	// Layer_6
	this.text_scored = new cjs.Text("", "bold 19px 'Arial'", "#660033");
	this.text_scored.name = "text_scored";
	this.text_scored.textAlign = "center";
	this.text_scored.lineHeight = 23;
	this.text_scored.lineWidth = 170;
	this.text_scored.parent = this;
	this.text_scored.setTransform(535.9,11.1);

	this.instance = new lib._3349926();
	this.instance.parent = this;
	this.instance.setTransform(379,-13,0.453,0.453);

	this.instance_1 = new lib.Tween14("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(520.5,34.3,1.852,1.852);

	this.text_7 = new cjs.Text("نقطة", "bold 45px 'Arial'", "#660033");
	this.text_7.textAlign = "right";
	this.text_7.lineHeight = 52;
	this.text_7.lineWidth = 117;
	this.text_7.parent = this;
	this.text_7.setTransform(108.6,541.5);

	this.text_8 = new cjs.Text("           لقد حصلت على ", "bold 37px 'Arial'", "#660033");
	this.text_8.lineHeight = 43;
	this.text_8.lineWidth = 353;
	this.text_8.parent = this;
	this.text_8.setTransform(268,556.6);

	this.text_score = new cjs.Text("", "bold 64px 'Arial'", "#660033");
	this.text_score.name = "text_score";
	this.text_score.textAlign = "center";
	this.text_score.lineHeight = 74;
	this.text_score.lineWidth = 103;
	this.text_score.parent = this;
	this.text_score.setTransform(187.7,541.5);

	this.question = new lib.mc_question();
	this.question.name = "question";
	this.question.parent = this;
	this.question.setTransform(235.3,345.3,1,1,0,0,0,-6,4);

	this.massege = new cjs.Text("", "bold 64px 'Arial'", "#660033");
	this.massege.name = "massege";
	this.massege.textAlign = "center";
	this.massege.lineHeight = 74;
	this.massege.lineWidth = 932;
	this.massege.parent = this;
	this.massege.setTransform(272.4,208.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.massege},{t:this.question},{t:this.text_score},{t:this.text_8,p:{x:268,y:556.6,text:"           لقد حصلت على ",font:"bold 37px 'Arial'",color:"#660033",textAlign:"",lineHeight:43.35,lineWidth:353}},{t:this.text_7,p:{x:108.6,text:"نقطة",font:"bold 45px 'Arial'",textAlign:"right",lineHeight:52.3,lineWidth:117}},{t:this.instance_1},{t:this.instance},{t:this.text_scored,p:{x:535.9,y:11.1,text:"",font:"bold 19px 'Arial'",textAlign:"center",lineHeight:23.25,lineWidth:170}}]},5).to({state:[{t:this.text_8,p:{x:215.6,y:541.5,text:"",font:"bold 34px 'Arial'",color:"#000000",textAlign:"right",lineHeight:40,lineWidth:103}},{t:this.text_7,p:{x:162.5,text:"           لقد حصلت على ",font:"bold 35px 'Arial'",textAlign:"",lineHeight:41.1,lineWidth:403}},{t:this.text_scored,p:{x:108.6,y:541.5,text:"درجة",font:"bold 35px 'Arial'",textAlign:"right",lineHeight:41.1,lineWidth:80}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Symbol7copy3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
		document.getElementById("ac_holder").style.display= "block";
		
				var ac_hold = document.getElementById("ac_holder");
				var ac_holdY = 150;
				var ac_holdL = 310;
				//    ac_ac_hold.y = 100;
				ac_hold.style.position = "absolute";
				ac_hold.style.top = ac_holdY + "px";
				ac_hold.style.left = ac_holdL + "px";
				//    ac_hold.style.zDepth = 100;
				//    ac_hold.style.x = ac_holdL +"px";
				//    ac_hold.style.y = ac_holdY +"px";
				var frame = new Frame("ac_holder", 600, 330);
				// var mainfun = 	
				frame.on("ready", framerdy);
				function framerdy(loc) {
				
					var stage = frame.stage;
					var stageW = frame.width; // - 200;
					var stageH = frame.height; // - 400;
				
					var fromBottom = 300;
					var borders = {
						x: 0,
						y: 0,
						width: stageW,
						height: stageH
					};
				
					// 6. make a physics.World and pass in the frame and borders
					var physics = new zim.Physics(frame, borders);
					var world = physics.world;
				 
				
					var scale = physics.scale;
				
					// physics.remove(physics.borderTop);
					// physics.remove(physics.borderLeft);
					// physics.remove(physics.borderRight);
				
					function sub_1() {
						var pic_sub_1 = new lib.sub_1();
						//	    physics.AddBody(physics.pic_work);
						stage.addChild(pic_sub_1);
						var barwork = physics.makeRectangle({
							width: 50,
							height: 50,
							dynamic: true,
							angular: 2,
							density: 1
						});
						barwork.x = 120;
						barwork.y = 300;
						physics.addMap(barwork, pic_sub_1);
					}
				
					function sub_2() {
						var pic_sub_2 = new lib.sub_2();
						stage.addChild(pic_sub_2);
						var barwood = physics.makeRectangle({
							width: 50,
							height: 50,
							dynamic: true,
							angular: 2,
							density: 3
						});
						barwood.x = 100;
						barwood.y = 300;
						physics.addMap(barwood, pic_sub_2);
					}
					function sub_3() {
						var pic_sub_3 = new lib.sub_3();
						stage.addChild(pic_sub_3);
						var barcoin = physics.makeRectangle({
							width: 50,
							height: 50,
							dynamic: true,
							angular: 2,
							density: 5
						});
						barcoin.x = 160;
						barcoin.y = 300;
						physics.addMap(barcoin, pic_sub_3);
				
					}
					function sub_4() {
						var pic_sub_4 = new lib.sub_4();
						stage.addChild(pic_sub_4);
						var barmsmr = physics.makeRectangle({
							width: 50,
							height: 50,
							dynamic: true,
							angular: 2,
							density:7
						});
						barmsmr.x = 220;
						barmsmr.y = 300;
						physics.addMap(barmsmr, pic_sub_4);
				
					}
					window.sub_5 = function () {
						var pic_sub_5 = new lib.sub_5();
						stage.addChild(pic_sub_5);
						var barflin = physics.makeRectangle({
							width: 50,
							height: 50,
							dynamic: true,
							angular: 2,
							density: 10
						});
						barflin.x = 280;
						barflin.y = 300;
						physics.addMap(barflin, pic_sub_5);
						barflin.rotation = rand(360);
					}
		
					// function sub_6() {
					// 	var pic_sub_6 = new lib.sub_6();
					// 	stage.addChild(pic_sub_6);
					// 	var barice = physics.makeRectangle({
					// 		width: 50,
					// 		height: 50,
					// 		dynamic: true,
					// 		angular: 2,
					// 		density: 35
					// 	});
					// 	barice.x = 340;
					// 	barice.y = 300;
					// 	physics.addMap(barice, pic_sub_6);
				
					// }
					// var barice4 = physics.makeRectangle({width:50, height:50, dynamic:true, angular:2, density:2});
					// barice4.x= 184;
					// barice4.y= 400;
					sub_1();
					sub_2();
					sub_3();
					sub_4();
					sub_5();
					// sub_6();
				
					// stage.addChild(pic_work);
				
					/*exportRoot.hod_1.addChild(pic_work);
																						exportRoot.hod_1.addChild(pic_wood);
																						exportRoot.hod_1.addChild(pic_coin);
																						exportRoot.hod_1.addChild(pic_msmr);
																						exportRoot.hod_1.addChild(pic_flin);*/
					// stage.addChild(bowlBacking2);
					// var ing = bowlBacking.clone();
					// 8. create a b2BuoyancyController with desired properties  
					var bc = new b2BuoyancyController();
					bc.normal.Set(0, -1);
					bc.offset = -stageH / 2 / physics.scale;
					bc.density = 2;
					bc.linearDrag = 3;
					bc.angularDrag = 2;
					world.AddController(bc);
					///////////////////////////////////////////////
					exportRoot.bord_4.btds_1.addEventListener("click", fl_ClickTobtds_1.bind(this));
					function fl_ClickTobtds_1() {
						bc.density  = 2;
					exportRoot.bord_4.des_t.text = "2";
				 
				
					}
						exportRoot.bord_4.btds_2.addEventListener("click", fl_ClickTobtds_2.bind(this));
					function fl_ClickTobtds_2() {
						bc.density  = 4;
					exportRoot.bord_4.des_t.text = "4";
				 
				
					}
						exportRoot.bord_4.btds_3.addEventListener("click", fl_ClickTobtds_3.bind(this));
					function fl_ClickTobtds_3() {
						bc.density  = 6;
					exportRoot.bord_4.des_t.text = "6";
				 
				
					}
						exportRoot.bord_4.btds_4.addEventListener("click", fl_ClickTobtds_4.bind(this));
					function fl_ClickTobtds_4() {
						bc.density  = 8;
					exportRoot.bord_4.des_t.text = "8";
				 
					}
					//ماء الحوض
					var bowlDef = new b2BodyDef();
					bowlDef.type = b2Body.b2_staticBody;
					var bowlBody = world.CreateBody(bowlDef);
					var bowlShape = new b2PolygonShape();
				
					var points = [];
					var bTopW = 280; // stageW;
					var bBotW = 280; // stageW;
					var bHeight = 100; //stageH/2-fromBottom;
					points[0] = new b2Vec2(0 / scale, 0 / scale);
					points[3] = new b2Vec2(bTopW / scale, 0 / scale);
					points[2] = new b2Vec2((bTopW - (bTopW - bBotW) / 2) / scale, bHeight / scale);
					points[1] = new b2Vec2((bTopW - bBotW) / 2 / scale, bHeight / scale);
					bowlBody.x = 230; //frame.x;//+100;//200;// exportRoot.hod_1.x - 5 ;// (stageW-bTopW)/2;
					bowlBody.y = 140; //frame.y + 200;//+100; //exportRoot.hod_1.y - 5  ; //stageH/2;
				
					bowlBody.SetPosition(new b2Vec2(bowlBody.x / scale, bowlBody.y / scale));
					bowlShape.SetAsArray(points, points.length);
					var bowlFixture = new b2FixtureDef();
				
					// 18. set the bowl as a sensor (will no longer physically interact)
					bowlFixture.isSensor = true;
					bowlFixture.shape = bowlShape;
					bowlBody.CreateFixture(bowlFixture);
				
				
				
					// var barBody = physics.makeRectangle(500, 20, false, 1,3);
					// barBody.x = frame.x;
					// barBody.y = frame.y+70;
					// barBody.rotation = 0;
				
					var bowlLeftBody = physics.makeRectangle(7, bHeight * 1.2, false);
					bowlLeftBody.x = bowlBody.x + (bTopW - bBotW) / 2 / 2 - 6;
					bowlLeftBody.y = bowlBody.y + bHeight / 2 - 22;
					bowlLeftBody.rotation = 0;
				
					var bowlRightBody = physics.makeRectangle(7, bHeight * 1.2, false);
					bowlRightBody.x = bowlBody.x + bTopW - (bTopW - bBotW) / 2 / 2 + 6;
					bowlRightBody.y = bowlBody.y + bHeight / 2 - 22;
					bowlRightBody.rotation = 0;
				
					var bowlBottomBody = physics.makeRectangle(7, 270, false);
					bowlBottomBody.x = bowlBody.x + bTopW - (bTopW - bBotW) / 2 / 2 - 130;
					bowlBottomBody.y = bowlBody.y + bHeight / 2 + 40;
					bowlBottomBody.rotation = 90;
				
				
				
				
					var contactListener = new b2ContactListener();
					contactListener.BeginContact = function (e) {
						if (e.m_fixtureA.m_isSensor || e.m_fixtureB.m_isSensor) {
							if (e.m_fixtureA.m_isSensor) {
								bc.AddBody(e.m_fixtureB.GetBody());
							} else {
								bc.AddBody(e.m_fixtureA.GetBody());
							}
						}
					}
				
					contactListener.EndContact = function (e) {
						if (e.m_fixtureA.m_isSensor || e.m_fixtureB.m_isSensor) {
							if (e.m_fixtureA.m_isSensor) {
								bc.RemoveBody(e.m_fixtureB.GetBody());
							} else {
								bc.RemoveBody(e.m_fixtureA.GetBody());
							}
						}
					}
				
					// set the contact listener on the world
					world.SetContactListener(contactListener);
				
					physics.drag();
					// physics.debug();
					
					// exportRoot.bord_4.ans_1.addEventListener("mousedown", function(event) {
					// 	var sX = Math.floor(event.stageX);
					// 	var sY = Math.floor(event.stageY);
					// 	exportRoot.bord_4.ans_1.dX = sX - exportRoot.bord_4.ans_1.x;
					// 	exportRoot.bord_4.ans_1.dY = sY - exportRoot.bord_4.ans_1.y;
					// 	// logDiv.innerHTML += 'dn x:' + sX + ' y:' + sY + ', ';
					// });
					// exportRoot.bord_4.ans_1.addEventListener("pressmove", function(event) {
					// 	var sX = Math.floor(event.stageX);
					// 	var sY = Math.floor(event.stageY);
					// 	exportRoot.bord_4.ans_1.x = sX - exportRoot.bord_4.ans_1.dX;
					// 	exportRoot.bord_4.ans_1.y = sY - exportRoot.bord_4.ans_1.dY;
					// 	// if (circle.x > 90 && circle.x < 110 && circle.y > 90 && circle.y < 110) {
					// 	// 	circle.x = 100;
					// 	// 	circle.y = 100;
					// 	// }
					// 	stage.update();
					// 	// exportRoot.bord_4.ans_1.x =  pxy.x;
					// 	// exportRoot.bord_4.ans_1.y =  pxy.y;
						
				
					// });
					var corec1 = false;
						var corec2 = false;
						var corec3 = false;
						var corec4 = false;
						var corec5 = false;
						var rightco1 = false;
						var rightco2 = false;
						var rightco3 = false;
						var rightco4 = false;
						var rightco5 = false;
						
						exportRoot.bord_4.ans_1.on('mousedown', function(e){
								var posX = e.stageX;
								var posY = e.stageY;
								this.offset = {x: this.x - posX, y: this.y - posY};
						});
		    exportRoot.bord_4.ans_1.on('pressmove', function(e){
							var posX = e.stageX;
							var posY = e.stageY;
							this.x = posX + this.offset.x;
							this.y = posY + this.offset.y ;
				
							if(this.x < exportRoot.bord_4.ansa_1.x + 30 && this.x > exportRoot.bord_4.ansa_1.x - 30
								&& this.y < exportRoot.bord_4.ansa_1.y + 30 && this.y > exportRoot.bord_4.ansa_1.y - 30 ){
								 exportRoot.bord_4.ansa_1.alpha = 0.2;
								this.x = exportRoot.bord_4.ansa_1.x;
								this.y = exportRoot.bord_4.ansa_1.y;
				
								corec1 = true;
								rightco1	= true;
								}else if(this.x < exportRoot.bord_4.ansa_2.x + 30 && this.x > exportRoot.bord_4.ansa_2.x - 30
									&& this.y < exportRoot.bord_4.ansa_2.y + 30 && this.y > exportRoot.bord_4.ansa_2.y - 30) {
										exportRoot.bord_4.ansa_2.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_2.x;
										this.y = exportRoot.bord_4.ansa_2.y;
										corec2 = true;
										rightco1	= false;
								}else if(this.x < exportRoot.bord_4.ansa_3.x + 30 && this.x > exportRoot.bord_4.ansa_3.x - 30
								  	&& this.y < exportRoot.bord_4.ansa_3.y + 30 && this.y > exportRoot.bord_4.ansa_3.y - 30) {
										exportRoot.bord_4.ansa_3.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_3.x;
										this.y = exportRoot.bord_4.ansa_3.y;
										corec3 = true;
										rightco1	= false;
								}else if(this.x < exportRoot.bord_4.ansa_4.x + 30 && this.x > exportRoot.bord_4.ansa_4.x - 30
									  && this.y < exportRoot.bord_4.ansa_4.y + 30 && this.y > exportRoot.bord_4.ansa_4.y - 30) {
										exportRoot.bord_4.ansa_4.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_4.x;
										this.y = exportRoot.bord_4.ansa_4.y;
										corec4 = true;
										  rightco1	= false;
								}else if(this.x < exportRoot.bord_4.ansa_5.x + 30 && this.x > exportRoot.bord_4.ansa_5.x - 30
									&& this.y < exportRoot.bord_4.ansa_5.y + 30 && this.y > exportRoot.bord_4.ansa_5.y - 30) {
										exportRoot.bord_4.ansa_5.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_5.x;
										this.y = exportRoot.bord_4.ansa_5.y;
										corec5 = true;
								        rightco1	= false;
								 } else {
								corec1 = false;corec2 = false;corec3 = false;corec4 = false;corec5 = false;   rightco1	= false;
								exportRoot.bord_4.ansa_1.alpha = 1;
								exportRoot.bord_4.ansa_2.alpha = 1;
								exportRoot.bord_4.ansa_3.alpha = 1;
								exportRoot.bord_4.ansa_4.alpha = 1;
								exportRoot.bord_4.ansa_5.alpha = 1;
							}
				
						});
		 
						exportRoot.bord_4.ans_1.on('pressup', function(e){
						//	if(	exportRoot.bord_4.ansa_1.x != this.x != exportRoot.bord_4.ansa_1.x){
							if(corec1 == false && corec2 == false && corec3 == false && corec4 == false && corec5 == false ){
							this.x = 500;
							this.y = 650;
							}
							
					});
							/////////////////////////             2
		
							exportRoot.bord_4.ans_2.on('mousedown', function(e){
								var posX = e.stageX;
								var posY = e.stageY;
								this.offset = {x: this.x - posX, y: this.y - posY};
						});
		    exportRoot.bord_4.ans_2.on('pressmove', function(e){
							var posX = e.stageX;
							var posY = e.stageY;
							this.x = posX + this.offset.x;
							this.y = posY + this.offset.y ;
				
							if(this.x < exportRoot.bord_4.ansa_1.x + 30 && this.x > exportRoot.bord_4.ansa_1.x - 30
								&& this.y < exportRoot.bord_4.ansa_1.y + 30 && this.y > exportRoot.bord_4.ansa_1.y - 30 ){
								 exportRoot.bord_4.ansa_1.alpha = 0.2;
								this.x = exportRoot.bord_4.ansa_1.x;
								this.y = exportRoot.bord_4.ansa_1.y;
				
								corec1 = true;
								 rightco2	= false;
								}else if(this.x < exportRoot.bord_4.ansa_2.x + 30 && this.x > exportRoot.bord_4.ansa_2.x - 30
									&& this.y < exportRoot.bord_4.ansa_2.y + 30 && this.y > exportRoot.bord_4.ansa_2.y - 30) {
										exportRoot.bord_4.ansa_2.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_2.x;
										this.y = exportRoot.bord_4.ansa_2.y;
										corec2 = true;
										 rightco2	= true;
								}else if(this.x < exportRoot.bord_4.ansa_3.x + 30 && this.x > exportRoot.bord_4.ansa_3.x - 30
								  	&& this.y < exportRoot.bord_4.ansa_3.y + 30 && this.y > exportRoot.bord_4.ansa_3.y - 30) {
										exportRoot.bord_4.ansa_3.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_3.x;
										this.y = exportRoot.bord_4.ansa_3.y;
										corec3 = true;
										 rightco2	= false;
								}else if(this.x < exportRoot.bord_4.ansa_4.x + 30 && this.x > exportRoot.bord_4.ansa_4.x - 30
									  && this.y < exportRoot.bord_4.ansa_4.y + 30 && this.y > exportRoot.bord_4.ansa_4.y - 30) {
										exportRoot.bord_4.ansa_4.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_4.x;
										this.y = exportRoot.bord_4.ansa_4.y;
										corec4 = true;
										   rightco2	= false;
								}else if(this.x < exportRoot.bord_4.ansa_5.x + 30 && this.x > exportRoot.bord_4.ansa_5.x - 30
									&& this.y < exportRoot.bord_4.ansa_5.y + 30 && this.y > exportRoot.bord_4.ansa_5.y - 30) {
										exportRoot.bord_4.ansa_5.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_5.x;
										this.y = exportRoot.bord_4.ansa_5.y;
										corec5 = true;
							    	  rightco2	= false;
								 } else {
								corec1 = false;corec2 = false;corec3 = false;corec4 = false;corec5 = false;  rightco2	= false;
								exportRoot.bord_4.ansa_1.alpha = 1;
								exportRoot.bord_4.ansa_2.alpha = 1;
								exportRoot.bord_4.ansa_3.alpha = 1;
								exportRoot.bord_4.ansa_4.alpha = 1;
								exportRoot.bord_4.ansa_5.alpha = 1;
							}
				
						});
		 
						exportRoot.bord_4.ans_2.on('pressup', function(e){
						//	if(	exportRoot.bord_4.ansa_1.x != this.x != exportRoot.bord_4.ansa_1.x){
							if(corec1 == false && corec2 == false && corec3 == false && corec4 == false && corec5 == false ){
							this.x = 394;
							this.y = 650;
							}
							
					});
							/////////////////////////
							exportRoot.bord_4.ans_3.on('mousedown', function(e){
								var posX = e.stageX;
								var posY = e.stageY;
								this.offset = {x: this.x - posX, y: this.y - posY};
						});
		    exportRoot.bord_4.ans_3.on('pressmove', function(e){
							var posX = e.stageX;
							var posY = e.stageY;
							this.x = posX + this.offset.x;
							this.y = posY + this.offset.y ;
				
							if(this.x < exportRoot.bord_4.ansa_1.x + 30 && this.x > exportRoot.bord_4.ansa_1.x - 30
								&& this.y < exportRoot.bord_4.ansa_1.y + 30 && this.y > exportRoot.bord_4.ansa_1.y - 30 ){
								 exportRoot.bord_4.ansa_1.alpha = 0.2;
								this.x = exportRoot.bord_4.ansa_1.x;
								this.y = exportRoot.bord_4.ansa_1.y;
				
								corec1 = true;
									 rightco3	= false;
								}else if(this.x < exportRoot.bord_4.ansa_2.x + 30 && this.x > exportRoot.bord_4.ansa_2.x - 30
									&& this.y < exportRoot.bord_4.ansa_2.y + 30 && this.y > exportRoot.bord_4.ansa_2.y - 30) {
										exportRoot.bord_4.ansa_2.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_2.x;
										this.y = exportRoot.bord_4.ansa_2.y;
										corec2 = true;
										 rightco3	= false;
								}else if(this.x < exportRoot.bord_4.ansa_3.x + 30 && this.x > exportRoot.bord_4.ansa_3.x - 30
								  	&& this.y < exportRoot.bord_4.ansa_3.y + 30 && this.y > exportRoot.bord_4.ansa_3.y - 30) {
										exportRoot.bord_4.ansa_3.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_3.x;
										this.y = exportRoot.bord_4.ansa_3.y;
										corec3 = true;
										 rightco3	= true;
								}else if(this.x < exportRoot.bord_4.ansa_4.x + 30 && this.x > exportRoot.bord_4.ansa_4.x - 30
									  && this.y < exportRoot.bord_4.ansa_4.y + 30 && this.y > exportRoot.bord_4.ansa_4.y - 30) {
										exportRoot.bord_4.ansa_4.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_4.x;
										this.y = exportRoot.bord_4.ansa_4.y;
										corec4 = true;
										   rightco3	= false;
								}else if(this.x < exportRoot.bord_4.ansa_5.x + 30 && this.x > exportRoot.bord_4.ansa_5.x - 30
									&& this.y < exportRoot.bord_4.ansa_5.y + 30 && this.y > exportRoot.bord_4.ansa_5.y - 30) {
										exportRoot.bord_4.ansa_5.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_5.x;
										this.y = exportRoot.bord_4.ansa_5.y;
										corec5 = true;
										 rightco3	= false;
								 
								 } else {
								corec1 = false;corec2 = false;corec3 = false;corec4 = false;corec5 = false;  rightco3	= false;
								exportRoot.bord_4.ansa_1.alpha = 1;
								exportRoot.bord_4.ansa_2.alpha = 1;
								exportRoot.bord_4.ansa_3.alpha = 1;
								exportRoot.bord_4.ansa_4.alpha = 1;
								exportRoot.bord_4.ansa_5.alpha = 1;
							}
				
						});
		 
						exportRoot.bord_4.ans_3.on('pressup', function(e){
						//	if(	exportRoot.bord_4.ansa_1.x != this.x != exportRoot.bord_4.ansa_1.x){
							if(corec1 == false && corec2 == false && corec3 == false && corec4 == false && corec5 == false ){
							this.x = 286.05;
							this.y = 650;
							}
							
					});
							/////////////////////////4
		
							exportRoot.bord_4.ans_4.on('mousedown', function(e){
								var posX = e.stageX;
								var posY = e.stageY;
								this.offset = {x: this.x - posX, y: this.y - posY};
						});
		    exportRoot.bord_4.ans_4.on('pressmove', function(e){
							var posX = e.stageX;
							var posY = e.stageY;
							this.x = posX + this.offset.x;
							this.y = posY + this.offset.y ;
				
							if(this.x < exportRoot.bord_4.ansa_1.x + 30 && this.x > exportRoot.bord_4.ansa_1.x - 30
								&& this.y < exportRoot.bord_4.ansa_1.y + 30 && this.y > exportRoot.bord_4.ansa_1.y - 30 ){
								 exportRoot.bord_4.ansa_1.alpha = 0.2;
								this.x = exportRoot.bord_4.ansa_1.x;
								this.y = exportRoot.bord_4.ansa_1.y;
				
								corec1 = true;
							   rightco4	= false;
								}else if(this.x < exportRoot.bord_4.ansa_2.x + 30 && this.x > exportRoot.bord_4.ansa_2.x - 30
									&& this.y < exportRoot.bord_4.ansa_2.y + 30 && this.y > exportRoot.bord_4.ansa_2.y - 30) {
										exportRoot.bord_4.ansa_2.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_2.x;
										this.y = exportRoot.bord_4.ansa_2.y;
										corec2 = true;
										   rightco4	= false;
								}else if(this.x < exportRoot.bord_4.ansa_3.x + 30 && this.x > exportRoot.bord_4.ansa_3.x - 30
								  	&& this.y < exportRoot.bord_4.ansa_3.y + 30 && this.y > exportRoot.bord_4.ansa_3.y - 30) {
										exportRoot.bord_4.ansa_3.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_3.x;
										this.y = exportRoot.bord_4.ansa_3.y;
										corec3 = true;
										   rightco4	= false;
								}else if(this.x < exportRoot.bord_4.ansa_4.x + 30 && this.x > exportRoot.bord_4.ansa_4.x - 30
									  && this.y < exportRoot.bord_4.ansa_4.y + 30 && this.y > exportRoot.bord_4.ansa_4.y - 30) {
										exportRoot.bord_4.ansa_4.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_4.x;
										this.y = exportRoot.bord_4.ansa_4.y;
										corec4 = true;
										     rightco4	= true;
								}else if(this.x < exportRoot.bord_4.ansa_5.x + 30 && this.x > exportRoot.bord_4.ansa_5.x - 30
									&& this.y < exportRoot.bord_4.ansa_5.y + 30 && this.y > exportRoot.bord_4.ansa_5.y - 30) {
										exportRoot.bord_4.ansa_5.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_5.x;
										this.y = exportRoot.bord_4.ansa_5.y;
										corec5 = true;
										   rightco4	= false;
								 
								 } else {
								corec1 = false;corec2 = false;corec3 = false;corec4 = false;corec5 = false;    rightco4	= false;
								exportRoot.bord_4.ansa_1.alpha = 1;
								exportRoot.bord_4.ansa_2.alpha = 1;
								exportRoot.bord_4.ansa_3.alpha = 1;
								exportRoot.bord_4.ansa_4.alpha = 1;
								exportRoot.bord_4.ansa_5.alpha = 1;
							}
				
						});
		 
						exportRoot.bord_4.ans_4.on('pressup', function(e){
						//	if(	exportRoot.bord_4.ansa_1.x != this.x != exportRoot.bord_4.ansa_1.x){
							if(corec1 == false && corec2 == false && corec3 == false && corec4 == false && corec5 == false ){
							this.x = 178.1;
							this.y = 650;
							}
							
					});
							/////////////////////////         5
		
							exportRoot.bord_4.ans_5.on('mousedown', function(e){
								var posX = e.stageX;
								var posY = e.stageY;
								this.offset = {x: this.x - posX, y: this.y - posY};
						});
		    exportRoot.bord_4.ans_5.on('pressmove', function(e){
							var posX = e.stageX;
							var posY = e.stageY;
							this.x = posX + this.offset.x;
							this.y = posY + this.offset.y ;
				
							if(this.x < exportRoot.bord_4.ansa_1.x + 30 && this.x > exportRoot.bord_4.ansa_1.x - 30
								&& this.y < exportRoot.bord_4.ansa_1.y + 30 && this.y > exportRoot.bord_4.ansa_1.y - 30 ){
								 exportRoot.bord_4.ansa_1.alpha = 0.2;
								this.x = exportRoot.bord_4.ansa_1.x;
								this.y = exportRoot.bord_4.ansa_1.y;
				
								corec1 = true;
									   rightco5	= false;
								}else if(this.x < exportRoot.bord_4.ansa_2.x + 30 && this.x > exportRoot.bord_4.ansa_2.x - 30
									&& this.y < exportRoot.bord_4.ansa_2.y + 30 && this.y > exportRoot.bord_4.ansa_2.y - 30) {
										exportRoot.bord_4.ansa_2.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_2.x;
										this.y = exportRoot.bord_4.ansa_2.y;
										corec2 = true;
										   rightco5	= false;
								}else if(this.x < exportRoot.bord_4.ansa_3.x + 30 && this.x > exportRoot.bord_4.ansa_3.x - 30
								  	&& this.y < exportRoot.bord_4.ansa_3.y + 30 && this.y > exportRoot.bord_4.ansa_3.y - 30) {
										exportRoot.bord_4.ansa_3.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_3.x;
										this.y = exportRoot.bord_4.ansa_3.y;
										corec3 = true;
										   rightco5	= false;
								}else if(this.x < exportRoot.bord_4.ansa_4.x + 30 && this.x > exportRoot.bord_4.ansa_4.x - 30
									  && this.y < exportRoot.bord_4.ansa_4.y + 30 && this.y > exportRoot.bord_4.ansa_4.y - 30) {
										exportRoot.bord_4.ansa_4.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_4.x;
										this.y = exportRoot.bord_4.ansa_4.y;
										corec4 = true;
										     rightco5	= false;
								}else if(this.x < exportRoot.bord_4.ansa_5.x + 30 && this.x > exportRoot.bord_4.ansa_5.x - 30
									&& this.y < exportRoot.bord_4.ansa_5.y + 30 && this.y > exportRoot.bord_4.ansa_5.y - 30) {
										exportRoot.bord_4.ansa_5.alpha = 0.2;
										this.x = exportRoot.bord_4.ansa_5.x;
										this.y = exportRoot.bord_4.ansa_5.y;
										corec5 = true;
								    rightco5	= true;
								 } else {
								corec1 = false;corec2 = false;corec3 = false;corec4 = false;corec5 = false;    rightco4	= false;
								exportRoot.bord_4.ansa_1.alpha = 1;
								exportRoot.bord_4.ansa_2.alpha = 1;
								exportRoot.bord_4.ansa_3.alpha = 1;
								exportRoot.bord_4.ansa_4.alpha = 1;
								exportRoot.bord_4.ansa_5.alpha = 1;
							}
				
						});
		 
						exportRoot.bord_4.ans_5.on('pressup', function(e){
						//	if(	exportRoot.bord_4.ansa_1.x != this.x != exportRoot.bord_4.ansa_1.x){
							if(corec1 == false && corec2 == false && corec3 == false && corec4 == false && corec5 == false ){
							this.x = 70;
							this.y = 650;
							}
							
					});
							/////////////////////////
		
					
					
			 
				
		
							exportRoot.bord_4.ok_act1.addEventListener("click", clickok_act1.bind(this));
				
				function clickok_act1() {
					if(  rightco1	== true && rightco2	== true && rightco3	== true && rightco4	== true && rightco5	== true ){
						exportRoot.pointplus();
					}
					
				}
				
				
				}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5).call(this.frame_5).wait(1));

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("EhHYABdIAAi5MCOxAAAIAAC5g");
	var mask_1_graphics_2 = new cjs.Graphics().p("EhHYARAMAAAgh/MCOxAAAMAAAAh/g");
	var mask_1_graphics_3 = new cjs.Graphics().p("EhHYAgkMAAAhBHMCOxAAAMAAABBHg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EhHYAwHMAAAhgNMCOxAAAMAAABgNg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:267,y:-9.3}).wait(1).to({graphics:mask_1_graphics_2,x:267,y:90.2}).wait(1).to({graphics:mask_1_graphics_3,x:267,y:189.8}).wait(1).to({graphics:mask_1_graphics_4,x:267,y:289.3}).wait(2));

	// Layer_1
	this.text_2 = new cjs.Text("ستتوفر الأنشطة قريبا ... \nتابعونا", "22px 'Arial'", "#330000");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 39;
	this.text_2.parent = this;
	this.text_2.setTransform(700.1,135.8,1.755,1.755);

	this.text_3 = new cjs.Text("أنشطة تفاعلية ", "26px 'Arial'", "#E87E00");
	this.text_3.textAlign = "right";
	this.text_3.lineHeight = 45;
	this.text_3.parent = this;
	this.text_3.setTransform(327.3,3.5,1.755,1.755);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape_1.setTransform(151.4,89.9);

	var maskedShapeInstanceList = [this.text_2,this.text_3,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_3},{t:this.text_2}]},1).to({state:[]},4).wait(1));

	// Layer_6
	this.text_4 = new cjs.Text("أنشطة تفاعلية ", "26px 'Arial'", "#E87E00");
	this.text_4.textAlign = "right";
	this.text_4.lineHeight = 45;
	this.text_4.parent = this;
	this.text_4.setTransform(327.3,3.5,1.755,1.755);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFC200").ss(2.8,1,1).p("A3PB9UgDhgGNApzADqQEBAWEeAc");
	this.shape_2.setTransform(151.4,89.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.text_4}]},5).wait(1));

	// Layer_7
	this.ans_3 = new lib.sub_1();
	this.ans_3.name = "ans_3";
	this.ans_3.parent = this;
	this.ans_3.setTransform(54.8,633.4);

	this.ans_5 = new lib.sub_5();
	this.ans_5.name = "ans_5";
	this.ans_5.parent = this;
	this.ans_5.setTransform(480.1,633.4);

	this.ans_4 = new lib.sub_4();
	this.ans_4.name = "ans_4";
	this.ans_4.parent = this;
	this.ans_4.setTransform(267.5,633.4);

	this.ans_1 = new lib.sub_3();
	this.ans_1.name = "ans_1";
	this.ans_1.parent = this;
	this.ans_1.setTransform(161.1,633.4);

	this.ans_2 = new lib.sub_2();
	this.ans_2.name = "ans_2";
	this.ans_2.parent = this;
	this.ans_2.setTransform(373.8,633.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.ans_2},{t:this.ans_1},{t:this.ans_4},{t:this.ans_5},{t:this.ans_3}]},5).wait(1));

	// Layer_5
	this.btds_3 = new lib.Symbol29copy7();
	this.btds_3.name = "btds_3";
	this.btds_3.parent = this;
	this.btds_3.setTransform(742.9,238.5,0.876,0.876,0,0,0,30.3,45);
	new cjs.ButtonHelper(this.btds_3, 0, 1, 1);

	this.btds_1 = new lib.Symbol29copy7();
	this.btds_1.name = "btds_1";
	this.btds_1.parent = this;
	this.btds_1.setTransform(742.9,426.8,0.876,0.876,0,0,0,30.3,45);
	new cjs.ButtonHelper(this.btds_1, 0, 1, 1);

	this.btds_2 = new lib.Symbol29copy7();
	this.btds_2.name = "btds_2";
	this.btds_2.parent = this;
	this.btds_2.setTransform(742.9,332.6,0.876,0.876,0,0,0,30.3,45);
	new cjs.ButtonHelper(this.btds_2, 0, 1, 1);

	this.hod_1 = new lib.Symbol31copy_1();
	this.hod_1.name = "hod_1";
	this.hod_1.parent = this;
	this.hod_1.setTransform(248.2,302.8,3.109,2.697,0,0,0,65,38);

	this.btds_4 = new lib.Symbol29copy7();
	this.btds_4.name = "btds_4";
	this.btds_4.parent = this;
	this.btds_4.setTransform(742.9,144.4,0.876,0.876,0,0,0,30.3,45);
	new cjs.ButtonHelper(this.btds_4, 0, 1, 1);

	this.ansa_2 = new lib.Symbol60();
	this.ansa_2.name = "ansa_2";
	this.ansa_2.parent = this;
	this.ansa_2.setTransform(399,551.5);

	this.ansa_3 = new lib.Symbol60();
	this.ansa_3.name = "ansa_3";
	this.ansa_3.parent = this;
	this.ansa_3.setTransform(277.4,551.5);

	this.ansa_4 = new lib.Symbol60();
	this.ansa_4.name = "ansa_4";
	this.ansa_4.parent = this;
	this.ansa_4.setTransform(155.9,551.5);

	this.ansa_5 = new lib.Symbol60();
	this.ansa_5.name = "ansa_5";
	this.ansa_5.parent = this;
	this.ansa_5.setTransform(34.3,551.5);

	this.ansa_1 = new lib.Symbol60();
	this.ansa_1.name = "ansa_1";
	this.ansa_1.parent = this;
	this.ansa_1.setTransform(520.7,551.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(10,2,1).p("EBEnAAAMiJNAAA");
	this.shape_3.setTransform(257,481);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.ansa_1},{t:this.ansa_5},{t:this.ansa_4},{t:this.ansa_3},{t:this.ansa_2},{t:this.btds_4},{t:this.hod_1},{t:this.btds_2},{t:this.btds_1},{t:this.btds_3}]},5).wait(1));

	// Layer_4
	this.ok_act1 = new lib.Symbol61();
	this.ok_act1.name = "ok_act1";
	this.ok_act1.parent = this;
	this.ok_act1.setTransform(-162.6,601.5);
	new cjs.ButtonHelper(this.ok_act1, 0, 1, 1);

	this.text_5 = new cjs.Text("3", "22px 'Arial'");
	this.text_5.textAlign = "right";
	this.text_5.lineHeight = 27;
	this.text_5.lineWidth = 21;
	this.text_5.parent = this;
	this.text_5.setTransform(-82.7,280.2);

	this.des_t = new cjs.Text("2", "35px 'Arial'");
	this.des_t.name = "des_t";
	this.des_t.textAlign = "right";
	this.des_t.lineHeight = 41;
	this.des_t.lineWidth = 33;
	this.des_t.parent = this;
	this.des_t.setTransform(34.8,280.2);

	this.text_6 = new cjs.Text(" جم/سم", "35px 'Arial'");
	this.text_6.textAlign = "right";
	this.text_6.lineHeight = 41;
	this.text_6.lineWidth = 104;
	this.text_6.parent = this;
	this.text_6.setTransform(-1.9,280.2);

	this.text_7 = new cjs.Text("3", "22px 'Arial'");
	this.text_7.textAlign = "right";
	this.text_7.lineHeight = 27;
	this.text_7.lineWidth = 21;
	this.text_7.parent = this;
	this.text_7.setTransform(597.9,418.4);

	this.text_8 = new cjs.Text("2", "35px 'Arial'");
	this.text_8.textAlign = "right";
	this.text_8.lineHeight = 41;
	this.text_8.lineWidth = 33;
	this.text_8.parent = this;
	this.text_8.setTransform(715.4,418.4);

	this.text_9 = new cjs.Text(" جم/سم", "35px 'Arial'");
	this.text_9.textAlign = "right";
	this.text_9.lineHeight = 41;
	this.text_9.lineWidth = 104;
	this.text_9.parent = this;
	this.text_9.setTransform(678.7,418.4);

	this.text_10 = new cjs.Text("<", "69px 'Arial'");
	this.text_10.textAlign = "right";
	this.text_10.lineHeight = 79;
	this.text_10.lineWidth = 63;
	this.text_10.parent = this;
	this.text_10.setTransform(114.3,511.2);

	this.text_11 = new cjs.Text("<", "69px 'Arial'");
	this.text_11.textAlign = "right";
	this.text_11.lineHeight = 79;
	this.text_11.lineWidth = 63;
	this.text_11.parent = this;
	this.text_11.setTransform(234.1,511.2);

	this.text_12 = new cjs.Text("<", "69px 'Arial'");
	this.text_12.textAlign = "right";
	this.text_12.lineHeight = 79;
	this.text_12.lineWidth = 63;
	this.text_12.parent = this;
	this.text_12.setTransform(354,511.2);

	this.text_13 = new cjs.Text("<", "69px 'Arial'");
	this.text_13.textAlign = "right";
	this.text_13.lineHeight = 79;
	this.text_13.lineWidth = 63;
	this.text_13.parent = this;
	this.text_13.setTransform(473.8,511.2);

	this.text_14 = new cjs.Text("الأعلى كثافة", "35px 'Arial'");
	this.text_14.textAlign = "right";
	this.text_14.lineHeight = 41;
	this.text_14.lineWidth = 172;
	this.text_14.parent = this;
	this.text_14.setTransform(735.1,532.6);

	this.text_15 = new cjs.Text("3", "22px 'Arial'");
	this.text_15.textAlign = "right";
	this.text_15.lineHeight = 27;
	this.text_15.lineWidth = 21;
	this.text_15.parent = this;
	this.text_15.setTransform(594.9,136);

	this.text_16 = new cjs.Text("8", "35px 'Arial'");
	this.text_16.textAlign = "right";
	this.text_16.lineHeight = 41;
	this.text_16.lineWidth = 33;
	this.text_16.parent = this;
	this.text_16.setTransform(712.5,136);

	this.text_17 = new cjs.Text(" جم/سم", "35px 'Arial'");
	this.text_17.textAlign = "right";
	this.text_17.lineHeight = 41;
	this.text_17.lineWidth = 104;
	this.text_17.parent = this;
	this.text_17.setTransform(675.7,136);

	this.text_18 = new cjs.Text("3", "22px 'Arial'");
	this.text_18.textAlign = "right";
	this.text_18.lineHeight = 27;
	this.text_18.lineWidth = 21;
	this.text_18.parent = this;
	this.text_18.setTransform(597.9,314.1);

	this.text_19 = new cjs.Text("4", "35px 'Arial'");
	this.text_19.textAlign = "right";
	this.text_19.lineHeight = 41;
	this.text_19.lineWidth = 33;
	this.text_19.parent = this;
	this.text_19.setTransform(715.4,314.1);

	this.text_20 = new cjs.Text(" جم/سم", "35px 'Arial'");
	this.text_20.textAlign = "right";
	this.text_20.lineHeight = 41;
	this.text_20.lineWidth = 104;
	this.text_20.parent = this;
	this.text_20.setTransform(678.7,314.1);

	this.text_21 = new cjs.Text("3", "22px 'Arial'");
	this.text_21.textAlign = "right";
	this.text_21.lineHeight = 27;
	this.text_21.lineWidth = 21;
	this.text_21.parent = this;
	this.text_21.setTransform(596.8,221.8);

	this.text_22 = new cjs.Text("6", "35px 'Arial'");
	this.text_22.textAlign = "right";
	this.text_22.lineHeight = 41;
	this.text_22.lineWidth = 33;
	this.text_22.parent = this;
	this.text_22.setTransform(714.4,221.8);

	this.text_23 = new cjs.Text(" جم/سم", "35px 'Arial'");
	this.text_23.textAlign = "right";
	this.text_23.lineHeight = 41;
	this.text_23.lineWidth = 104;
	this.text_23.parent = this;
	this.text_23.setTransform(677.6,221.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.des_t},{t:this.text_5},{t:this.ok_act1}]},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.settingcopy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
		
		
		exportRoot.sett_en.colo_bac2.gotoAndStop(0);
		
		this.fulsc_1.addEventListener("mousedown", toggleFullscreen11.bind(this));
		//function fl2_ClickToGoToclic_fulsc_1() {
				
		function toggleFullscreen11(event) {
			this.fulsc_2.visible = true;
			this.fulsc_1.visible = false;
			
		    var element = document.body;
		
		    if (event instanceof HTMLElement) {
		        element = event;
		    }
		
		    var isFullscreen = document.webkitIsFullScreen || document.mozFullScreen || false;
		
		    element.requestFullScreen = element.requestFullScreen || element.webkitRequestFullScreen ||   element.mozRequestFullScreen || element.msRequestFullscreen || function () {
		        return false;
		    };
		    document.cancelFullScreen = document.cancelFullScreen || document.webkitCancelFullScreen ||  document.mozCancelFullScreen || document.msExitFullscreen || function () {
		        return false;
		    };
		
		    isFullscreen ? document.cancelFullScreen() : element.requestFullScreen();
		} 
		this.fulsc_2.addEventListener("mousedown", toggleFullscreen2.bind(this));
		//function fl2_ClickToGoToclic_fulsc_1() {
				
		function toggleFullscreen2(event) {
			this.fulsc_1.visible = true;
			this.fulsc_2.visible = false;
			
		    var element = document.body;
		
		    if (event instanceof HTMLElement) {
		        element = event;
		    }
		
		    var isFullscreen = document.webkitIsFullScreen || document.mozFullScreen || false;
		
		    element.requestFullScreen = element.requestFullScreen || element.webkitRequestFullScreen ||   element.mozRequestFullScreen || element.msRequestFullscreen || function () {
		        return false;
		    };
		    document.cancelFullScreen = document.cancelFullScreen || document.webkitCancelFullScreen ||  document.mozCancelFullScreen || document.msExitFullscreen || function () {
		        return false;
		    };
		
		    isFullscreen ? document.cancelFullScreen() : element.requestFullScreen();
		} 
		
		this.colos_bt2.addEventListener("mousedown", fl2_ClickToGoToclic_colbak_23.bind(this));
			function fl2_ClickToGoToclic_colbak_23() {
				this.colo_bac2.visible = true;	
				this.colo_bac2.gotoAndPlay(1);
				 this.bak_322.visible = true;	
				 	    	 		
				}
				
		this.bak_322.addEventListener("mousedown", fl2_ClickToGoToclic_bak_322.bind(this));
			function fl2_ClickToGoToclic_bak_322() {
			  
			  this.colo_bac2.gotoAndStop(0);
			  this.colo_bac2.visible =false;
			  this.bak_322.visible = false;
				 
				}
		
		this.arab_1.addEventListener("mousedown", fl2_ClickToGoToclic_arab_1.bind(this));
		function fl2_ClickToGoToclic_arab_1() {
		 	this.gotoAndStop(0);
			exportRoot.sett.gotoAndStop(9);
			
			exportRoot.lib_ar.text = "جميع الأدوات موجودة على منضدة المعمل";
				
		 exportRoot.text_en.visible = false;
		 exportRoot.text_ar.visible = true;
		exportRoot.btnen_1.visible = false;	
		exportRoot.btnen_2.visible = false;
		exportRoot.btnen_3.visible = false;
		exportRoot.btnen_4.visible = false;
		exportRoot.btnen_5.visible = false;
		exportRoot.btnen_6.visible = false;
		exportRoot.btnen_7.visible = false;
		exportRoot.borden_1.visible = false;
			
		exportRoot.btn_1.visible = true;
		exportRoot.btn_2.visible = true;
		exportRoot.btn_3.visible = true;
		exportRoot.btn_4.visible = true;
		exportRoot.btn_5.visible = true;
		exportRoot.btn_6.visible = true;
		exportRoot.btn_7.visible = true;
		exportRoot.bord_1.visible = true; 
		
		 
		if(exportRoot.borden_1.visible == true){
			exportRoot.bord_1.visible = true;
			exportRoot.borden_1.visible = false;
		}
		if(exportRoot.borden_2.visible == true){
			exportRoot.bord_2.visible = true;
			exportRoot.borden_2.visible = false;
		}
		if(exportRoot.borden_3.visible == true){
			exportRoot.bord_3.visible = true;
			exportRoot.borden_3.visible = false;
		}
		if(exportRoot.borden_4.visible == true){
			exportRoot.bord_4.visible = true;
			exportRoot.borden_4.visible = false;
		}
		if(exportRoot.borden_5.visible == true){
			exportRoot.bord_5.visible = true;
			exportRoot.borden_5.visible = false;
		}
		if(exportRoot.borden_6.visible == true){
			exportRoot.bord_6.visible = true;
			exportRoot.borden_6.visible = false;
		}
		if(exportRoot.borden_7.visible == true){
			exportRoot.bord_7.visible = true;
			exportRoot.borden_7.visible = false;
		}
			
		if(exportRoot.tools_en.visible == true){
			exportRoot.tools.visible = true;
			exportRoot.tools_en.visible = false;
		}
		if(exportRoot.maemly_en.visible == true){
			exportRoot.maemly.visible = true;
			exportRoot.maemly_en.visible = false;
		}
		if(exportRoot.sabora_en.visible == true){
			exportRoot.sabora.visible = true;
			exportRoot.sabora_en.visible = false;
		}
		if(exportRoot.maemly2_en.visible == true){
			exportRoot.maemly2.visible = true;
			exportRoot.maemly2_en.visible = false;
		}
		 		}
		
				
		
		this.settend_2.addEventListener("mousedown", fl2_ClickToGoToclic_bak_3.bind(this));
			function fl2_ClickToGoToclic_bak_3() {
				
				this.gotoAndStop(0);		
				 document.getElementById("holder").style.display= "block";
				if (exportRoot.settng.visible == true){
					exportRoot.intro_en.gotoAndPlay(1);
					exportRoot.settng = false;
				}
			}
				
		this.ok_2.addEventListener("mousedown", fl2_ClickToGoToclic_ok2.bind(this));
			function fl2_ClickToGoToclic_ok2() {
				
				this.gotoAndStop(0);		
				 document.getElementById("holder").style.display= "block";
				if (exportRoot.settng.visible == true){
					exportRoot.intro_en.gotoAndPlay(1);
					exportRoot.settng = false;
				}
			}
		
		this.instr_en1.addEventListener("mousedown", fl2_ClickToGoToinstr_en1.bind(this));
			function fl2_ClickToGoToinstr_en1() {
				
				this.instr_en1.visible = false;
				this.instr_en2.visible = true;
				exportRoot.techer_1.visible = false;
				exportRoot.text_1.visible = false;
				exportRoot.text_ar.visible = false;
				exportRoot.text_en.visible = false;
				
			}
		
		this.instr_en2.addEventListener("mousedown", fl2_ClickToGoToinstr_en2.bind(this));
			function fl2_ClickToGoToinstr_en2() {
				
				this.instr_en2.visible = false;
				this.instr_en1.visible = true;
				exportRoot.techer_1.visible = true;
				exportRoot.text_1.visible = true;
				exportRoot.text_ar.visible = true;
				exportRoot.text_en.visible = true;
				
				
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2
	this.colo_bac2 = new lib.Symbol1_1();
	this.colo_bac2.name = "colo_bac2";
	this.colo_bac2.parent = this;
	this.colo_bac2.setTransform(416.3,568,1.005,1,0,0,0,272.1,36.9);
	this.colo_bac2._off = true;
	this.colo_bac2.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.colo_bac2).wait(9).to({_off:false},0).wait(1));

	// Layer_5
	this.bak_322 = new lib.Symbol59copy3();
	this.bak_322.name = "bak_322";
	this.bak_322.parent = this;
	this.bak_322.setTransform(410.1,390.1,0.645,0.9,0,0,0,589.5,411.1);
	this.bak_322._off = true;
	this.bak_322.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.bak_322).wait(9).to({_off:false},0).wait(1));

	// Layer_6
	this.instance = new lib.Tween50("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-285,161);
	this.instance._off = true;

	this.instance_1 = new lib.Tween51("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(700,161);

	this.instance_2 = new lib.question();
	this.instance_2.parent = this;
	this.instance_2.setTransform(680,141,0.625,0.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},7).to({state:[{t:this.instance_2}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({_off:true,x:700},7,cjs.Ease.quartOut).wait(2));

	// Layer_4
	this.fulsc_2 = new lib.Symbol63copy2();
	this.fulsc_2.name = "fulsc_2";
	this.fulsc_2.parent = this;
	this.fulsc_2.setTransform(-582.1,381.5,0.731,0.731,0,0,0,209.5,85.7);
	this.fulsc_2._off = true;
	this.fulsc_2.visible = false;
	new cjs.ButtonHelper(this.fulsc_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.fulsc_2).wait(1).to({_off:false},0).to({x:402.9},7,cjs.Ease.quartOut).wait(2));

	// Layer_3
	this.instance_3 = new lib.Tween52("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-571.5,400);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween53("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(413.5,400);

	this.ok_2 = new lib.Symbol80copy();
	this.ok_2.name = "ok_2";
	this.ok_2.parent = this;
	this.ok_2.setTransform(420.5,649.5,1,1,0,0,0,145.5,66.5);
	new cjs.ButtonHelper(this.ok_2, 0, 1, 1);

	this.arab_1 = new lib.Symbol67();
	this.arab_1.name = "arab_1";
	this.arab_1.parent = this;
	this.arab_1.setTransform(547.5,153.5,1,1,0,0,0,141.5,55.5);
	new cjs.ButtonHelper(this.arab_1, 0, 1, 1);

	this.eng_1 = new lib.Symbol66();
	this.eng_1.name = "eng_1";
	this.eng_1.parent = this;
	this.eng_1.setTransform(277.5,154,1,1,0,0,0,139.5,52);
	new cjs.ButtonHelper(this.eng_1, 0, 1, 1);

	this.colos_bt2 = new lib.Symbol65copy();
	this.colos_bt2.name = "colos_bt2";
	this.colos_bt2.parent = this;
	this.colos_bt2.setTransform(403.8,480.3,0.724,0.724,0,0,0,207.6,83.5);
	new cjs.ButtonHelper(this.colos_bt2, 0, 1, 1);

	this.fulsc_1 = new lib.Symbol63copy3();
	this.fulsc_1.name = "fulsc_1";
	this.fulsc_1.parent = this;
	this.fulsc_1.setTransform(402.7,381.8,0.724,0.724,0,0,0,209,85.5);
	new cjs.ButtonHelper(this.fulsc_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},7).to({state:[{t:this.fulsc_1},{t:this.colos_bt2},{t:this.eng_1},{t:this.arab_1},{t:this.ok_2}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({_off:true,x:413.5},7,cjs.Ease.quartOut).wait(2));

	// Layer_10
	this.instance_5 = new lib.Tween54("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-577.7,274.1);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween55("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(416.2,274.1);

	this.instr_en1 = new lib.Symbol63copy7();
	this.instr_en1.name = "instr_en1";
	this.instr_en1.parent = this;
	this.instr_en1.setTransform(569.6,337.3,0.746,0.746,0,0,0,209.1,85.6);
	new cjs.ButtonHelper(this.instr_en1, 0, 1, 1);

	this.instr_en2 = new lib.Symbol63copy9();
	this.instr_en2.name = "instr_en2";
	this.instr_en2.parent = this;
	this.instr_en2.setTransform(566.1,337.1,0.746,0.746,0,0,0,209.1,85.6);
	this.instr_en2.visible = false;
	new cjs.ButtonHelper(this.instr_en2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},7).to({state:[{t:this.instr_en2},{t:this.instr_en1}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({_off:false},0).to({_off:true,x:416.2},7,cjs.Ease.quartOut).wait(2));

	// Layer_7
	this.instance_7 = new lib.Tween56("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(-555.1,393.1);
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween57("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(438.8,393.1);

	this.colo_bac2_1 = new lib.Symbol1copy11();
	this.colo_bac2_1.name = "colo_bac2_1";
	this.colo_bac2_1.parent = this;
	this.colo_bac2_1.setTransform(417.5,554.4,0.63,0.627,0,0,0,272.1,37);

	this.instance_9 = new lib.question();
	this.instance_9.parent = this;
	this.instance_9.setTransform(596,255,0.557,0.557);

	this.instance_10 = new lib.question();
	this.instance_10.parent = this;
	this.instance_10.setTransform(596,470,0.557,0.557);

	this.instance_11 = new lib.question();
	this.instance_11.parent = this;
	this.instance_11.setTransform(596,360,0.557,0.557);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},7).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.colo_bac2_1}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({_off:false},0).to({_off:true,x:438.8},7,cjs.Ease.quartOut).wait(2));

	// Layer_1
	this.instance_12 = new lib.Tween64("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(-558.5,400);
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween65("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(411.5,400);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},7).to({state:[{t:this.instance_13}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(1).to({_off:false},0).to({_off:true,x:411.5},7,cjs.Ease.quintOut).wait(2));

	// Layer_9
	this.settend_2 = new lib.Symbol82copy();
	this.settend_2.name = "settend_2";
	this.settend_2.parent = this;
	this.settend_2.setTransform(374.3,409.4,1,1,0,0,0,664.3,409.3);
	this.settend_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.settend_2).wait(9).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.setting = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
		 exportRoot.sett.colo_bac1.gotoAndStop(0);
		/*this.bbbbbb.addEventListener("mousedown", fl2_ClickToGoToclic_bbbbbb.bind(this));
			function fl2_ClickToGoToclic_bbbbbb() {
				
			this.gotoAndStop(0);
				
			}*/
		
		this.colos_bt1.addEventListener("mousedown", fl2_ClickToGoToclic_colbak_1.bind(this));
			function fl2_ClickToGoToclic_colbak_1() {
				this.colo_bac1.visible =true;
				this.colo_bac1.gotoAndPlay(1);
				
				 this.bak_311.visible = true;	
				 	    	 		
				}
				
		this.bak_311.addEventListener("mousedown", fl2_ClickToGoToclic_bak_311.bind(this));
			function fl2_ClickToGoToclic_bak_311() {
				
			  this.colo_bac1.gotoAndStop(0);
			  this.colo_bac1.visible =false;
			  this.bak_311.visible = false;
				 
				}
		
		 
		this.eng_1.addEventListener("mousedown", fl2_ClickToGoToclic_eng_1.bind(this));
		function fl2_ClickToGoToclic_eng_1() {
		 	this.gotoAndStop(0);
			exportRoot.sett_en.gotoAndStop(9);
			
			
		 exportRoot.text_en.visible = true;
		 exportRoot.text_ar.visible = false;
			
		//exportRoot.lib_en.visible = true;	
			
		exportRoot.lib_ar.text = "All the tools are on the lab table";
			
		exportRoot.btnen_1.visible = true;	
		exportRoot.btnen_2.visible = true;
		exportRoot.btnen_3.visible = true;
		exportRoot.btnen_4.visible = true;
		exportRoot.btnen_5.visible = true;
		exportRoot.btnen_6.visible = true;
		exportRoot.btnen_7.visible = true;
		 
			
		exportRoot.btn_1.visible = false;
		exportRoot.btn_2.visible = false;
		exportRoot.btn_3.visible = false;
		exportRoot.btn_4.visible = false;
		exportRoot.btn_5.visible = false;
		exportRoot.btn_6.visible = false;
		exportRoot.btn_7.visible = false;
			
		 
		if(exportRoot.bord_1.visible == true){
			exportRoot.borden_1.visible = true;
			exportRoot.bord_1.visible = false;
		}
		if(exportRoot.bord_2.visible == true){
			exportRoot.borden_2.visible = true;
			exportRoot.bord_2.visible = false;
		}
		if(exportRoot.bord_3.visible == true){
			exportRoot.borden_3.visible = true;
			exportRoot.bord_3.visible = false;
		}
		if(exportRoot.bord_4.visible == true){
			exportRoot.borden_4.visible = true;
			exportRoot.bord_4.visible = false;
		}
		if(exportRoot.bord_5.visible == true){
			exportRoot.borden_5.visible = true;
			exportRoot.bord_5.visible = false;
		}
		if(exportRoot.bord_6.visible == true){
			exportRoot.borden_6.visible = true;
			exportRoot.bord_6.visible = false;
		}
		if(exportRoot.bord_7.visible == true){
			exportRoot.borden_7.visible = true;
			exportRoot.bord_7.visible = false;
		}
		 
		if(exportRoot.tools.visible == true){
			exportRoot.tools_en.visible = true;
			exportRoot.tools.visible = false;
		}
		if(exportRoot.maemly.visible == true){
			exportRoot.maemly_en.visible = true;
			exportRoot.maemly.visible = false;
		}
		if(exportRoot.sabora.visible == true){
			exportRoot.sabora_en.visible = true;
			exportRoot.sabora.visible = false;
		}
		if(exportRoot.maemly2.visible == true){
			exportRoot.maemly2_en.visible = true;
			exportRoot.maemly2.visible = false;
		}
		
		 		}
		
		
		this.fulscen_1.addEventListener("mousedown", toggleFullscreenen.bind(this));
		//function fl2_ClickToGoToclic_fulsc_1() {
				
		function toggleFullscreenen(event) {
			this.fulscen_2.visible = true;
			this.fulscen_1.visible = false;
			
			
		    var element = document.body;
		
		    if (event instanceof HTMLElement) {
		        element = event;
		    }
		
		    var isFullscreen = document.webkitIsFullScreen || document.mozFullScreen || false;
		
		    element.requestFullScreen = element.requestFullScreen || element.webkitRequestFullScreen ||   element.mozRequestFullScreen || element.msRequestFullscreen || function () {
		        return false;
		    };
		    document.cancelFullScreen = document.cancelFullScreen || document.webkitCancelFullScreen ||  document.mozCancelFullScreen || document.msExitFullscreen || function () {
		        return false;
		    };
		
		    isFullscreen ? document.cancelFullScreen() : element.requestFullScreen();
		} 
		
		this.fulscen_2.addEventListener("mousedown", toggleFullscreen2en.bind(this));
		//function fl2_ClickToGoToclic_fulsc_1() {
				
		function toggleFullscreen2en(event) {
			this.fulscen_1.visible = true;
			this.fulscen_2.visible = false;
			
		    var element = document.body;
		
		    if (event instanceof HTMLElement) {
		        element = event;
		    }
		
		    var isFullscreen = document.webkitIsFullScreen || document.mozFullScreen || false;
		
		    element.requestFullScreen = element.requestFullScreen || element.webkitRequestFullScreen ||   element.mozRequestFullScreen || element.msRequestFullscreen || function () {
		        return false;
		    };
		    document.cancelFullScreen = document.cancelFullScreen || document.webkitCancelFullScreen ||  document.mozCancelFullScreen || document.msExitFullscreen || function () {
		        return false;
		    };
		
		    isFullscreen ? document.cancelFullScreen() : element.requestFullScreen();
		} 
		
		
		
		
		this.settend_1.addEventListener("mousedown", fl2_ClickToGoToclic_bak_1.bind(this));
			function fl2_ClickToGoToclic_bak_1() {
				
				this.gotoAndStop(0);		
				 document.getElementById("holder").style.display= "block";
				if (exportRoot.settng.visible == true){
					exportRoot.intro_ar.gotoAndPlay(1);
					exportRoot.settng.visible = false;
				}
			}
				
		this.ok_1.addEventListener("mousedown", fl2_ClickToGoToclic_ok1.bind(this));
			function fl2_ClickToGoToclic_ok1() {
				
				this.gotoAndStop(0);	
				 document.getElementById("holder").style.display= "block";
			if (exportRoot.settng.visible == true){
					exportRoot.intro_ar.gotoAndPlay(1);
					exportRoot.settng.visible = false;
				}
				
			}
		
			
		this.instr_1.addEventListener("mousedown", fl2_ClickToGoToinstr_1.bind(this));
			function fl2_ClickToGoToinstr_1() {
				
				this.instr_1.visible = false;
				this.instr_2.visible = true;
				exportRoot.techer_1.visible = false;
				exportRoot.text_1.visible = false;
				exportRoot.text_ar.visible = false;
				exportRoot.text_en.visible = false;
				
			}
		
		this.instr_2.addEventListener("mousedown", fl2_ClickToGoToinstr_2.bind(this));
			function fl2_ClickToGoToinstr_2() {
				
				this.instr_2.visible = false;
				this.instr_1.visible = true;
				exportRoot.techer_1.visible = true;
				exportRoot.text_1.visible = true;
				exportRoot.text_ar.visible = true;
				exportRoot.text_en.visible = true;
				
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_2
	this.colo_bac1 = new lib.Symbol1copy11();
	this.colo_bac1.name = "colo_bac1";
	this.colo_bac1.parent = this;
	this.colo_bac1.setTransform(417.5,554.4,0.63,0.627,0,0,0,272.1,37);
	this.colo_bac1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.colo_bac1).wait(9).to({_off:false},0).wait(1));

	// Layer_5
	this.bak_311 = new lib.Symbol59();
	this.bak_311.name = "bak_311";
	this.bak_311.parent = this;
	this.bak_311.setTransform(410.1,390.1,0.645,0.9,0,0,0,589.5,411.1);
	this.bak_311._off = true;
	this.bak_311.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.bak_311).wait(9).to({_off:false},0).wait(1));

	// Layer_6
	this.instance = new lib.Tween19("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-374.5,329.3);
	this.instance._off = true;

	this.instance_1 = new lib.Tween22("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(638.5,329.3);

	this.instance_2 = new lib.question();
	this.instance_2.parent = this;
	this.instance_2.setTransform(566,260,0.557,0.557);

	this.instance_3 = new lib.question();
	this.instance_3.parent = this;
	this.instance_3.setTransform(557,482,0.557,0.557);

	this.instance_4 = new lib.question();
	this.instance_4.parent = this;
	this.instance_4.setTransform(557,368,0.557,0.557);

	this.instance_5 = new lib.question();
	this.instance_5.parent = this;
	this.instance_5.setTransform(680,141,0.625,0.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},7).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({_off:true,x:638.5},7,cjs.Ease.quintOut).wait(2));

	// Layer_4
	this.instance_6 = new lib.Tween23("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-598.8,326.4);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween24("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(414.2,326.4);

	this.instr_1 = new lib.Symbol63copy6();
	this.instr_1.name = "instr_1";
	this.instr_1.parent = this;
	this.instr_1.setTransform(562,335.2,0.725,0.725,0,0,0,209.2,85.5);
	new cjs.ButtonHelper(this.instr_1, 0, 1, 1);

	this.instr_2 = new lib.Symbol63copy4();
	this.instr_2.name = "instr_2";
	this.instr_2.parent = this;
	this.instr_2.setTransform(561.7,335.2,0.725,0.725,0,0,0,209.1,85.7);
	this.instr_2.visible = false;
	new cjs.ButtonHelper(this.instr_2, 0, 1, 1);

	this.fulscen_2 = new lib.Symbol63copy();
	this.fulscen_2.name = "fulscen_2";
	this.fulscen_2.parent = this;
	this.fulscen_2.setTransform(415.8,377.6,0.627,0.627,0,0,0,209.1,85.5);
	this.fulscen_2.visible = false;
	new cjs.ButtonHelper(this.fulscen_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},7).to({state:[{t:this.fulscen_2},{t:this.instr_2},{t:this.instr_1}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({_off:false},0).to({_off:true,x:414.2},7,cjs.Ease.quintOut).wait(2));

	// Layer_3
	this.instance_8 = new lib.Tween44("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-599.5,407.5);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween49("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(413.5,407.5);

	this.ok_1 = new lib.Symbol80();
	this.ok_1.name = "ok_1";
	this.ok_1.parent = this;
	this.ok_1.setTransform(420.5,650.5,1,1,0,0,0,145.5,66.5);
	new cjs.ButtonHelper(this.ok_1, 0, 1, 1);

	this.arab_1 = new lib.Symbol67();
	this.arab_1.name = "arab_1";
	this.arab_1.parent = this;
	this.arab_1.setTransform(547.5,153.5,1,1,0,0,0,141.5,55.5);
	new cjs.ButtonHelper(this.arab_1, 0, 1, 1);

	this.eng_1 = new lib.Symbol66();
	this.eng_1.name = "eng_1";
	this.eng_1.parent = this;
	this.eng_1.setTransform(277.5,154,1,1,0,0,0,139.5,52);
	new cjs.ButtonHelper(this.eng_1, 0, 1, 1);

	this.colos_bt1 = new lib.Symbol65();
	this.colos_bt1.name = "colos_bt1";
	this.colos_bt1.parent = this;
	this.colos_bt1.setTransform(415.5,481.4,0.627,0.627,0,0,0,207.6,83.5);
	new cjs.ButtonHelper(this.colos_bt1, 0, 1, 1);

	this.fulscen_1 = new lib.Symbol63();
	this.fulscen_1.name = "fulscen_1";
	this.fulscen_1.parent = this;
	this.fulscen_1.setTransform(412.7,377.2,0.627,0.627,0,0,0,209.1,85.5);
	new cjs.ButtonHelper(this.fulscen_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},7).to({state:[{t:this.fulscen_1},{t:this.colos_bt1},{t:this.eng_1},{t:this.arab_1},{t:this.ok_1}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({_off:false},0).to({_off:true,x:413.5},7,cjs.Ease.quartOut).wait(2));

	// Layer_1
	this.instance_10 = new lib.Tween76("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(-563.5,400);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween77("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(411.5,400);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},7).to({state:[{t:this.instance_11}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1).to({_off:false},0).to({_off:true,x:411.5},7,cjs.Ease.quintOut).wait(2));

	// Layer_9
	this.settend_1 = new lib.Symbol82();
	this.settend_1.name = "settend_1";
	this.settend_1.parent = this;
	this.settend_1.setTransform(374.3,409.4,1,1,0,0,0,664.3,409.3);
	this.settend_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.settend_1).wait(9).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Scene_1_setting_En = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// setting_En
	this.sett_en = new lib.settingcopy3();
	this.sett_en.name = "sett_en";
	this.sett_en.parent = this;
	this.sett_en.setTransform(679.7,393.9,0.789,0.789,0,0,0,411.7,400.3);

	this.timeline.addTween(cjs.Tween.get(this.sett_en).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_setting_En, null, null);


(lib.Scene_1_setting_ar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// setting_ar
	this.sett = new lib.setting();
	this.sett.name = "sett";
	this.sett.parent = this;
	this.sett.setTransform(679.7,393.9,0.789,0.789,0,0,0,411.7,400.3);

	this.timeline.addTween(cjs.Tween.get(this.sett).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_setting_ar, null, null);


(lib.Scene_1_put_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// put_2
	this.myput = new lib.Symbol34();
	this.myput.name = "myput";
	this.myput.parent = this;
	this.myput.setTransform(977.4,589.8,1.36,1.08,0,13.6,0,134.1,34.3);
	this.myput.visible = false;
	new cjs.ButtonHelper(this.myput, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.myput).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_put_2, null, null);


(lib.Scene_1_navig_en = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// navig_en
	this.maemly2_en = new lib.Symbol16_1();
	this.maemly2_en.name = "maemly2_en";
	this.maemly2_en.parent = this;
	this.maemly2_en.setTransform(65,129.8,1.047,1.047,0,0,0,92.3,59.9);
	this.maemly2_en.visible = false;
	new cjs.ButtonHelper(this.maemly2_en, 0, 1, 2);

	this.maemly_en = new lib.Symbol12();
	this.maemly_en.name = "maemly_en";
	this.maemly_en.parent = this;
	this.maemly_en.setTransform(1056.7,144.9,1.047,1.047,0,0,0,92.7,57.1);
	this.maemly_en.visible = false;
	new cjs.ButtonHelper(this.maemly_en, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.maemly_en},{t:this.maemly2_en}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_navig_en, null, null);


(lib.Scene_1_انشطة_تفاعلية = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// انشطة_تفاعلية
	this.bord_4 = new lib.Symbol7copy3_1();
	this.bord_4.name = "bord_4";
	this.bord_4.parent = this;
	this.bord_4.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);

	this.timeline.addTween(cjs.Tween.get(this.bord_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_انشطة_تفاعلية, null, null);


(lib.Scene_1_اختبارات = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// اختبارات
	this.bord_5 = new lib.Symbol7copy4_1();
	this.bord_5.name = "bord_5";
	this.bord_5.parent = this;
	this.bord_5.setTransform(-194.4,261.3,0.598,0.598,0,0,0,340.2,205);

	this.timeline.addTween(cjs.Tween.get(this.bord_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_اختبارات, null, null);


(lib.myhamel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hamellcopy3();
	this.instance.parent = this;
	this.instance.setTransform(39.9,68.7,0.506,0.458,0,0,0,-3.8,1.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:1.8,scaleX:0.59,scaleY:0.53,x:39.8},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,146.6,161.6);


(lib.Symbol9copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_5copy3();
	this.instance.parent = this;
	this.instance.setTransform(26.3,24.8,1,1,0,0,0,23.4,23.4);

	this.instance_1 = new lib.Path_17copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.8,25.2,1,1,0,0,0,20.4,20.4);
	this.instance_1.alpha = 0.512;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC200").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(29.4,24.2);

	this.instance_2 = new lib.Path_2_6copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.4,24.2,1,1,0,0,0,27.4,24.2);
	this.instance_2.alpha = 0.359;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AliACIAAgCILEAAIAAACg");
	this.shape_1.setTransform(96,34.9);

	this.text = new cjs.Text("Videos", "20px 'Arial'", "#003300");
	this.text.textAlign = "center";
	this.text.lineHeight = 26;
	this.text.parent = this;
	this.text.setTransform(89.9,10.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFC200").s().p("AnhDKQg1AAgpgiQgOgVgJgUIgMgaIgFgPQgLghgGgZIAAhMQAAg/AsgtQAsgtA/AAIO5AAQAfAAATAaIBkCMQALARAAASQAAAUgLAPIhkCOQgTAZgfAAg");
	this.shape_2.setTransform(87.8,24.6);

	this.instance_3 = new lib.Path_1_12copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(87.7,24.4,1,1,0,0,0,65.2,22.7);
	this.instance_3.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_3},{t:this.shape_2},{t:this.shape},{t:this.instance_1},{t:this.instance},{t:this.text},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.9,48.4);


(lib.Symbol8copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_4copy3();
	this.instance.parent = this;
	this.instance.setTransform(27.3,40.9,1,1,0,0,0,86.5,86.5);

	this.instance_1 = new lib.Path_15copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.8,25.2,1,1,0,0,0,20.4,20.4);
	this.instance_1.alpha = 0.512;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC200").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(29.4,24.2);

	this.instance_2 = new lib.Path_2_5copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.4,24.2,1,1,0,0,0,27.4,24.2);
	this.instance_2.alpha = 0.359;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0071BC").s().p("AliABIAAgBILEAAIAAABg");
	this.shape_1.setTransform(96,35.9);

	this.text = new cjs.Text("Links", "20px 'Arial'", "#003300");
	this.text.textAlign = "right";
	this.text.lineHeight = 25;
	this.text.parent = this;
	this.text.setTransform(112.8,11);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFC200").s().p("AnhDKQg1AAgpgiQgOgVgJgTIgMgbIgFgPQgLgggGgaIAAhMQAAhAAsgsQAsgtA/AAIO5AAQAfAAATAaIBkCNQALAQAAASQAAAUgLAPIhkCNQgTAagfAAg");
	this.shape_2.setTransform(87.8,24.6);

	this.instance_3 = new lib.Path_1_10copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(87.7,24.4,1,1,0,0,0,65.2,22.7);
	this.instance_3.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_3},{t:this.shape_2},{t:this.shape},{t:this.instance_1},{t:this.instance},{t:this.text},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.2,-45.6,173,173);


(lib.Symbol7copy2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_3copy3();
	this.instance.parent = this;
	this.instance.setTransform(28.4,23.5,1,1,0,0,0,22.6,25.1);

	this.instance_1 = new lib.Path_7copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.8,25.2,1,1,0,0,0,20.4,20.4);
	this.instance_1.alpha = 0.512;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFC200").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA8AUA8QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape_1.setTransform(29.4,24.2);

	this.instance_2 = new lib.Path_2_3copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.4,24.2,1,1,0,0,0,27.4,24.2);
	this.instance_2.alpha = 0.359;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F7931E").s().p("AliABIAAgCILEAAIAAACg");
	this.shape_2.setTransform(96,35.9);

	this.text_2 = new cjs.Text("Tests", "19px 'Arial'", "#003300");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 24;
	this.text_2.parent = this;
	this.text_2.setTransform(108.4,10.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFC200").s().p("AnhDKQg1AAgpgiQgOgVgJgTIgMgbIgFgQQgLgfgGgaIAAhNQAAg+AsgtQAsgtA/AAIO5AAQAfAAATAZIBkCOQALAQAAASQAAAUgLAQIhkCMQgTAagfAAg");
	this.shape_3.setTransform(87.8,24.6);

	this.instance_3 = new lib.Path_1_5copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(87.7,24.4,1,1,0,0,0,65.2,22.7);
	this.instance_3.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape_1},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_3},{t:this.shape_3},{t:this.shape_1},{t:this.instance_1},{t:this.instance},{t:this.text_2},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1.6,56.9,50.2);


(lib.Symbol6copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_2copy3();
	this.instance.parent = this;
	this.instance.setTransform(29.5,23.4,1,1,0,0,0,23.4,20.4);

	this.instance_1 = new lib.Path_5copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.8,25.2,1,1,0,0,0,20.4,20.4);
	this.instance_1.alpha = 0.512;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC200").s().p("AjKCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQCMAABhB5QAwA9AUA7QgeA8g1A9QhqB5h0AAQhkAAhHhHg");
	this.shape.setTransform(29.4,24.2);

	this.instance_2 = new lib.Path_1_4copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(87.7,24.4,1,1,0,0,0,65.2,22.7);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.Path_2_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(27.4,24.2,1,1,0,0,0,27.4,24.2);
	this.instance_3.alpha = 0.359;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7931E").s().p("AliACIAAgDILEAAIAAADg");
	this.shape_1.setTransform(96,34.9);

	this.text = new cjs.Text("Activities", "14px 'Arial'", "#003300");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.parent = this;
	this.text.setTransform(83.5,16.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFC200").s().p("AnhDKQg1AAgqgiQgMgVgKgUIgNgaIgDgPQgLghgHgZIAAhMQAAg/AtgtQArgtA/AAIO5AAQAfAAASAaIBkCMQAMARAAASQAAAUgMAPIhkCOQgSAZgfAAg");
	this.shape_2.setTransform(87.8,24.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.shape_2},{t:this.shape},{t:this.instance_1},{t:this.instance},{t:this.text},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.9,48.4);


(lib.Groupcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_34copy();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Groupcopy, new cjs.Rectangle(0,-0.4,27.9,33.6), null);


(lib.Group_7copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1copy2();
	this.instance.parent = this;
	this.instance.setTransform(19.6,2.1,1,1,0,0,0,19.6,2.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7copy, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.Group_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1copy();
	this.instance.parent = this;
	this.instance.setTransform(19.6,2.1,1,1,0,0,0,19.6,2.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.Group_6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_3copy2();
	this.instance.parent = this;
	this.instance.setTransform(19.4,2.1,1,1,0,0,0,19.4,2.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6copy, new cjs.Rectangle(0,0,38.7,4.3), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_3copy();
	this.instance.parent = this;
	this.instance.setTransform(19.4,2.1,1,1,0,0,0,19.4,2.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0,0,38.7,4.3), null);


(lib.Group_5copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_10copy();
	this.instance.parent = this;
	this.instance.setTransform(14.6,2.9,1,1,0,0,0,14.6,2.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5copy, new cjs.Rectangle(0,0,29.3,5.8), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_10();
	this.instance.parent = this;
	this.instance.setTransform(14.6,2.9,1,1,0,0,0,14.6,2.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,29.3,5.8), null);


(lib.Group_4copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_14copy();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.4,1,1,0,0,0,18.3,2.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4copy2, new cjs.Rectangle(0,-0.3,36.5,5.3), null);


(lib.Group_4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_14();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.4,1,1,0,0,0,18.3,2.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4copy, new cjs.Rectangle(0,-0.3,36.5,5.3), null);


(lib.Group_3copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_18copy();
	this.instance.parent = this;
	this.instance.setTransform(4,3.1,1,1,0,0,0,4,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3copy2, new cjs.Rectangle(0,-0.2,8.2,6.7), null);


(lib.Group_3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_18();
	this.instance.parent = this;
	this.instance.setTransform(4,3.1,1,1,0,0,0,4,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3copy, new cjs.Rectangle(0,-0.2,8.2,6.7), null);


(lib.Group_2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_22copy();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.1,1,1,0,0,0,3.6,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2copy, new cjs.Rectangle(-0.4,-0.2,8.2,6.7), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_22();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.1,1,1,0,0,0,3.6,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(-0.4,-0.2,8.2,6.7), null);


(lib.Group_1_0copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_30copy();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.4,1,1,0,0,0,30.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_0copy2, new cjs.Rectangle(-0.1,-0.3,61.9,23.5), null);


(lib.Group_1_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_30();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.4,1,1,0,0,0,30.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_0copy, new cjs.Rectangle(-0.1,-0.3,61.9,23.5), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_34();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,-0.4,27.9,33.6), null);


(lib.ClipGroup_26copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.Groupcopy();
	this.instance.parent = this;
	this.instance.setTransform(52.1,19.8,1,1,0,0,0,13.9,16.4);
	this.instance.alpha = 0.398;

	this.instance_1 = new lib.Group_1_0copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(36.5,23.9,1,1,0,0,0,30.9,11.4);
	this.instance_1.alpha = 0.18;

	this.instance_2 = new lib.ClipGroup_27copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(35.5,20.5,1,1,0,0,0,35.5,20.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26copy, new cjs.Rectangle(0,0,71,41), null);


(lib.ClipGroup_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(52.1,19.8,1,1,0,0,0,13.9,16.4);
	this.instance.alpha = 0.398;

	this.instance_1 = new lib.Group_1_0copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(36.5,23.9,1,1,0,0,0,30.9,11.4);
	this.instance_1.alpha = 0.18;

	this.instance_2 = new lib.ClipGroup_27();
	this.instance_2.parent = this;
	this.instance_2.setTransform(35.5,20.5,1,1,0,0,0,35.5,20.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26, new cjs.Rectangle(0,0,71,41), null);


(lib.Scene_1_buttonss = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// buttonss
	this.btnen_7 = new lib.Symbol9copy2();
	this.btnen_7.name = "btnen_7";
	this.btnen_7.parent = this;
	this.btnen_7.setTransform(-601.1,435.8,0.888,0.89,0,0,0,23.4,24.6);
	this.btnen_7.visible = false;
	new cjs.ButtonHelper(this.btnen_7, 0, 1, 1);

	this.btnen_6 = new lib.Symbol8copy3();
	this.btnen_6.name = "btnen_6";
	this.btnen_6.parent = this;
	this.btnen_6.setTransform(-599.9,390.1,0.888,0.89,0,0,0,24.7,25.2);
	this.btnen_6.visible = false;
	new cjs.ButtonHelper(this.btnen_6, 0, 1, 1);

	this.btnen_5 = new lib.Symbol7copy2_1();
	this.btnen_5.name = "btnen_5";
	this.btnen_5.parent = this;
	this.btnen_5.setTransform(-594.7,342.6,0.888,0.89,0,0,0,30.6,23.7);
	this.btnen_5.visible = false;
	new cjs.ButtonHelper(this.btnen_5, 0, 1, 1);

	this.btnen_4 = new lib.Symbol6copy2();
	this.btnen_4.name = "btnen_4";
	this.btnen_4.parent = this;
	this.btnen_4.setTransform(-598.5,297,0.888,0.89,0,0,0,26.3,24.3);
	this.btnen_4.visible = false;
	new cjs.ButtonHelper(this.btnen_4, 0, 1, 1);

	this.btnen_3 = new lib.Symbol5copy4();
	this.btnen_3.name = "btnen_3";
	this.btnen_3.parent = this;
	this.btnen_3.setTransform(-595.3,250.8,0.888,0.89,0,0,0,29.9,24.4);
	this.btnen_3.visible = false;
	new cjs.ButtonHelper(this.btnen_3, 0, 1, 1);

	this.btnen_2 = new lib.Symbol4copy4();
	this.btnen_2.name = "btnen_2";
	this.btnen_2.parent = this;
	this.btnen_2.setTransform(-622,182.8,0.888,0.89,0,0,0,-0.1,0.1);
	this.btnen_2.visible = false;
	new cjs.ButtonHelper(this.btnen_2, 0, 1, 1);

	this.btnen_1 = new lib.Symbol3copy3();
	this.btnen_1.name = "btnen_1";
	this.btnen_1.parent = this;
	this.btnen_1.setTransform(-622.1,137,0.888,0.89,0,0,0,-0.3,-0.1);
	this.btnen_1.visible = false;
	new cjs.ButtonHelper(this.btnen_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btnen_1},{t:this.btnen_2},{t:this.btnen_3},{t:this.btnen_4},{t:this.btnen_5},{t:this.btnen_6},{t:this.btnen_7}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_buttonss, null, null);


(lib.Group_1copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_26copy();
	this.instance.parent = this;
	this.instance.setTransform(35.5,20.5,1,1,0,0,0,35.5,20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy2, new cjs.Rectangle(-0.2,-0.3,71.5,41.8), null);


(lib.Group_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_26();
	this.instance.parent = this;
	this.instance.setTransform(35.5,20.5,1,1,0,0,0,35.5,20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy, new cjs.Rectangle(-0.2,-0.3,71.5,41.8), null);


(lib.Symbol1copy23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-37.1,-23.1)).s().p("AgKAJIAAgRIAVAAIAAARg");
	this.shape.setTransform(35,38.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-43.4,-17.8)).s().p("AlGBIIAAiOIKNAAIAABaIgFAAIAAAdIAFAAIAAAXg");
	this.shape_1.setTransform(31.2,45.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// MergedLayer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(31.3,44.9,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(31.8,44.6,1,0.905,0,0,0,35.5,20.6);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// MergedLayer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],73), null, new cjs.Matrix2D(0.234,0,0,0.234,-60.4,-71.9)).s().p("AlPAGIAAgKIKfAAIAAAKg");
	this.shape_2.setTransform(30.4,65);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// MergedLayer_2
	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(46.2,61.5,1,1,0,0,0,3.6,3.1);
	this.instance_2.alpha = 0.148;

	this.instance_3 = new lib.Group_3copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(16.9,61.5,1,1,0,0,0,4,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_4copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(32.1,59.9,1,1,0,0,0,18.3,2.4);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(31.8,63,1,1,0,0,0,14.6,2.9);
	this.instance_5.alpha = 0.398;

	this.instance_6 = new lib.ClipGroup_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(31.8,45.5,1,1,0,0,0,35.6,20.5);

	this.instance_7 = new lib.ClipGroup_1_0();
	this.instance_7.parent = this;
	this.instance_7.setTransform(31.6,30.7,1,1,0,0,0,35.6,10.8);

	this.instance_8 = new lib.Group_6();
	this.instance_8.parent = this;
	this.instance_8.setTransform(23.1,64.6,1,1,0,0,0,19.4,2.1);
	this.instance_8.alpha = 0.148;

	this.instance_9 = new lib.Group_7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(40.3,64.6,1,1,0,0,0,19.6,2.1);
	this.instance_9.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy23, new cjs.Rectangle(-4.4,19.8,72,47), null);


(lib.Symbol1copy21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-37.1,-23.1)).s().p("AgKAJIAAgRIAVAAIAAARg");
	this.shape.setTransform(35,38.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-43.4,-17.8)).s().p("AlGBIIAAiOIKNAAIAABaIgFAAIAAAdIAFAAIAAAXg");
	this.shape_1.setTransform(31.2,45.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(2));

	// MergedLayer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(31.3,44.9,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(31.8,44.6,1,0.905,0,0,0,35.5,20.6);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_1},{t:this.instance}]},1).wait(1));

	// MergedLayer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],72), null, new cjs.Matrix2D(0.234,0,0,0.234,-64.4,-66.4)).s().p("AlPFoIAArOIKfAAIAALOg");
	this.shape_2.setTransform(30.4,28.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],73), null, new cjs.Matrix2D(0.234,0,0,0.234,-60.4,-71.9)).s().p("AlPAGIAAgKIKfAAIAAAKg");
	this.shape_3.setTransform(30.4,65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[]},1).wait(1));

	// MergedLayer_2
	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(46.2,61.5,1,1,0,0,0,3.6,3.1);
	this.instance_2.alpha = 0.148;

	this.instance_3 = new lib.Group_3copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(16.9,61.5,1,1,0,0,0,4,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_4copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(32.1,59.9,1,1,0,0,0,18.3,2.4);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(31.8,63,1,1,0,0,0,14.6,2.9);
	this.instance_5.alpha = 0.398;

	this.instance_6 = new lib.ClipGroup_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(31.8,45.5,1,1,0,0,0,35.6,20.5);

	this.instance_7 = new lib.ClipGroup_1_0();
	this.instance_7.parent = this;
	this.instance_7.setTransform(31.6,30.7,1,1,0,0,0,35.6,10.8);

	this.instance_8 = new lib.Group_6();
	this.instance_8.parent = this;
	this.instance_8.setTransform(23.1,64.6,1,1,0,0,0,19.4,2.1);
	this.instance_8.alpha = 0.148;

	this.instance_9 = new lib.Group_7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(40.3,64.6,1,1,0,0,0,19.6,2.1);
	this.instance_9.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-7.5,72,74.3);


(lib.Symbol1copy20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-37.1,-23.1)).s().p("AgKAJIAAgRIAVAAIAAARg");
	this.shape.setTransform(35,38.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-43.4,-17.8)).s().p("AlGBIIAAiOIKNAAIAABaIgFAAIAAAdIAFAAIAAAXg");
	this.shape_1.setTransform(31.2,45.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// MergedLayer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(31.3,44.9,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(31.8,44.6,1,0.905,0,0,0,35.5,20.6);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// MergedLayer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],73), null, new cjs.Matrix2D(0.234,0,0,0.234,-60.4,-71.9)).s().p("AlPAGIAAgKIKfAAIAAAKg");
	this.shape_2.setTransform(30.4,65);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// MergedLayer_2
	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(46.2,61.5,1,1,0,0,0,3.6,3.1);
	this.instance_2.alpha = 0.148;

	this.instance_3 = new lib.Group_3copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(16.9,61.5,1,1,0,0,0,4,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_4copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(32.1,59.9,1,1,0,0,0,18.3,2.4);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(31.8,63,1,1,0,0,0,14.6,2.9);
	this.instance_5.alpha = 0.398;

	this.instance_6 = new lib.ClipGroup_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(31.8,45.5,1,1,0,0,0,35.6,20.5);

	this.instance_7 = new lib.ClipGroup_1_0();
	this.instance_7.parent = this;
	this.instance_7.setTransform(31.6,30.7,1,1,0,0,0,35.6,10.8);

	this.instance_8 = new lib.Group_6();
	this.instance_8.parent = this;
	this.instance_8.setTransform(23.1,64.6,1,1,0,0,0,19.4,2.1);
	this.instance_8.alpha = 0.148;

	this.instance_9 = new lib.Group_7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(40.3,64.6,1,1,0,0,0,19.6,2.1);
	this.instance_9.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy20, new cjs.Rectangle(-4.4,19.8,72,47), null);


(lib.Symbol1copy19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_1
	this.text = new cjs.Text("نترات صوديوم", "14px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 82;
	this.text.parent = this;
	this.text.setTransform(36.7,65.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(37.2,76);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(37.2,76);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).wait(1));

	// MergedLayer_3
	this.text_1 = new cjs.Text("3", "8px 'Arial'");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 15;
	this.text_1.lineWidth = 6;
	this.text_1.parent = this;
	this.text_1.setTransform(61.8,41.4);

	this.text_2 = new cjs.Text("NaNO", "19px 'Arial'");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 32;
	this.text_2.lineWidth = 50;
	this.text_2.parent = this;
	this.text_2.setTransform(56.5,36.8,1,0.785);

	this.instance = new lib.Group_0copy();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text_2},{t:this.text_1}]}).wait(2));

	// MergedLayer_1
	this.instance_2 = new lib.Bitmap1240();
	this.instance_2.parent = this;
	this.instance_2.setTransform(10,8,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

	// MergedLayer_2
	this.instance_3 = new lib.Group_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_3copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_4copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_5copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_6.alpha = 0.398;

	this.instance_7 = new lib.ClipGroup_7copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_8 = new lib.ClipGroup_1_0copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,8,72,65.3);


(lib.Symbol1copy18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_1
	this.text = new cjs.Text("كبريتات نحاس", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(36.9,66.1,0.585,1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(36.6,77);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(36.6,77);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).to({state:[]},1).wait(5));

	// MergedLayer_3
	this.text_1 = new cjs.Text("4", "8px 'Arial'");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 15;
	this.text_1.lineWidth = 6;
	this.text_1.parent = this;
	this.text_1.setTransform(59.4,41.4);

	this.text_2 = new cjs.Text("CuSO", "19px 'Arial'");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 32;
	this.text_2.lineWidth = 50;
	this.text_2.parent = this;
	this.text_2.setTransform(54.9,35.6,1,0.776);

	this.instance = new lib.Group_0copy();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text_2},{t:this.text_1}]}).to({state:[]},2).wait(5));

	// MergedLayer_1
	this.instance_2 = new lib.Bitmap1238();
	this.instance_2.parent = this;
	this.instance_2.setTransform(6,-3,0.387,0.387);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(5));

	// MergedLayer_2
	this.instance_3 = new lib.Group_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_3copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_4copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_5copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_6.alpha = 0.398;

	this.instance_7 = new lib.ClipGroup_7copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_8 = new lib.ClipGroup_1_0copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).to({state:[]},2).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-3,72,74.7);


(lib.Symbol1copy17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_1
	this.text = new cjs.Text("كربونات النحاس", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 105;
	this.text.parent = this;
	this.text.setTransform(34.9,66.1,0.699,1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(36.4,77);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(36.4,77);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).to({state:[]},1).wait(5));

	// MergedLayer_3
	this.text_1 = new cjs.Text("3", "8px 'Arial'");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 15;
	this.text_1.lineWidth = 6;
	this.text_1.parent = this;
	this.text_1.setTransform(61.8,43.4,1,0.702);

	this.text_2 = new cjs.Text("CuCO", "19px 'Arial'");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 32;
	this.text_2.lineWidth = 50;
	this.text_2.parent = this;
	this.text_2.setTransform(56.5,35.9,1,0.776);

	this.instance = new lib.Group_0copy();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text_2},{t:this.text_1}]}).to({state:[]},4).wait(3));

	// MergedLayer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjMCyQhXghgNgLQgCgCACgIQAEgaABgxQACgxA5hPQA5hQBAgWIBOgaQAUgFAVAAQASAAAVAFQAOAEA6AFQA5ADBJBnQBJBmgIAwQgJAwAEAUQAFAVgEAEQgKAJhZAbQhXAah0AAQh1AAhXgjg");
	mask.setTransform(34.8,24.3);

	// MergedLayer_1
	this.instance_2 = new lib.Bitmap1239();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-3,3,0.362,0.362);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},4).wait(3));

	// MergedLayer_2
	this.instance_3 = new lib.Group_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_3copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_4copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_5copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_6.alpha = 0.398;

	this.instance_7 = new lib.ClipGroup_7copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_8 = new lib.ClipGroup_1_0copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).to({state:[]},4).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,3,72,69);


(lib.Symbol1copy16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_2
	this.text = new cjs.Text("كربونات الصوديوم", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 132;
	this.text.parent = this;
	this.text.setTransform(36.1,66.1,0.587,1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(36.7,77);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(36.7,77);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).to({state:[]},1).wait(5));

	// Layer_1
	this.text_1 = new cjs.Text("3", "8px 'Arial'");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 15;
	this.text_1.lineWidth = 6;
	this.text_1.parent = this;
	this.text_1.setTransform(36,41.9);

	this.text_2 = new cjs.Text("2", "8px 'Arial'");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 15;
	this.text_2.lineWidth = 6;
	this.text_2.parent = this;
	this.text_2.setTransform(58.3,41.4);

	this.text_3 = new cjs.Text("Na CO", "19px 'Arial'");
	this.text_3.textAlign = "right";
	this.text_3.lineHeight = 32;
	this.text_3.lineWidth = 50;
	this.text_3.parent = this;
	this.text_3.setTransform(55,35.2,1,0.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1}]}).to({state:[]},2).wait(5));

	// MergedLayer_3
	this.instance = new lib.Group_0copy();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[]},2).wait(5));

	// MergedLayer_1
	this.instance_2 = new lib.Bitmap1241();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1,-3,0.239,0.239);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(5));

	// MergedLayer_2
	this.instance_3 = new lib.Group_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_3copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_4copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_5copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_6.alpha = 0.398;

	this.instance_7 = new lib.ClipGroup_7copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_8 = new lib.ClipGroup_1_0copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).to({state:[]},2).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-3,72,67.9);


(lib.Symbol1copy14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_2
	this.text = new cjs.Text("هيدروكسيد النحاس", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 156;
	this.text.parent = this;
	this.text.setTransform(36.2,64.5,0.495,1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(35.8,76);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(35.8,76);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).to({state:[]},1).wait(5));

	// Layer_1
	this.text_1 = new cjs.Text("2", "8px 'Arial'");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 15;
	this.text_1.lineWidth = 6;
	this.text_1.parent = this;
	this.text_1.setTransform(61.8,43.3,1,0.875);

	this.text_2 = new cjs.Text("Cu(OH)", "19px 'Arial'");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 32;
	this.text_2.lineWidth = 50;
	this.text_2.parent = this;
	this.text_2.setTransform(56.5,36.8,1,0.674);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.text_1}]}).to({state:[]},2).wait(5));

	// MergedLayer_3
	this.instance = new lib.Group_0copy();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[]},2).wait(5));

	// MergedLayer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjWC/QhZgkgMgNQgDgBACgJQAFgbAFhZQAFhXA0hHQA1hHBDgCQBCgBAOgEQAVgGAUAAQAUAAAUAGQAOAEB5ATQB5ATAOBfQANBfACApQACAqgIAfQgIAfgEADQgLALhZAdQhZAbh2AAQh2AAhYgkg");
	mask.setTransform(36.1,25.7);

	// MergedLayer_1
	this.instance_2 = new lib.Bitmap1235();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-12,3,0.301,0.301);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(5));

	// MergedLayer_2
	this.instance_3 = new lib.Group_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_3copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_4copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_5copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_6.alpha = 0.398;

	this.instance_7 = new lib.ClipGroup_7copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_8 = new lib.ClipGroup_1_0copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).to({state:[]},2).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,3,72,65.2);


(lib.Symbol1copy13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_3
	this.text = new cjs.Text("حديد", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(39.6,70.2,0.699,1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(39.4,81.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(39.4,81.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).to({state:[]},1).wait(5));

	// Layer_1
	this.text_1 = new cjs.Text("Fe", "19px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 50;
	this.text_1.parent = this;
	this.text_1.setTransform(37.8,38.1,1,0.761);

	this.instance = new lib.Group_0copy();
	this.instance.parent = this;
	this.instance.setTransform(35.2,46.5,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text_1}]}).to({state:[]},2).wait(5));

	// MergedLayer_3
	this.instance_1 = new lib.Group_1copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.5,48.4,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},2).wait(5));

	// MergedLayer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgvD/Qh1AAg/hAQg/hBgMgKQgDgCACgWQACgWAahgQAahhA3gsQA2gsAugIQAugHATgSQATgTANAQQANAQASAIQARAIBZgKQBZgKAbBUQAbBTABBHQABBIAOAgQAJAVgEADQgLAJhwA6QhwA5hzAAIgBAAg");
	mask.setTransform(34.7,29.5);

	// Layer_2
	this.instance_2 = new lib.Bitmap1236();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,8,0.1,0.109);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(5));

	// MergedLayer_2
	this.instance_3 = new lib.Group_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50,64.1,1,1,0,0,0,3.6,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_3copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(20.8,64.2,1,1,0,0,0,4,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_4copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(36,62.6,1,1,0,0,0,18.3,2.4);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_5copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.7,65.7,1,1,0,0,0,14.6,2.9);
	this.instance_6.alpha = 0.398;

	this.instance_7 = new lib.ClipGroup_7copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.6,48.1,1,1,0,0,0,35.6,20.5);

	this.instance_8 = new lib.ClipGroup_1_0copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(35.4,33.3,1,1,0,0,0,35.6,10.8);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(26.9,67.3,1,1,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(44.2,67.3,1,1,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).to({state:[]},2).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,8,72,61.4);


(lib.Symbol1copy12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_1
	this.text = new cjs.Text("خارصين", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(37.5,66.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(37.3,77);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(37.3,77);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).to({state:[]},1).wait(5));

	// MergedLayer_3
	this.text_1 = new cjs.Text("Zn", "19px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 50;
	this.text_1.parent = this;
	this.text_1.setTransform(34.4,36.1,1,0.834);

	this.instance = new lib.Group_0copy();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text_1}]}).to({state:[]},2).wait(5));

	// MergedLayer_1
	this.instance_2 = new lib.Bitmap1244();
	this.instance_2.parent = this;
	this.instance_2.setTransform(5,13,0.223,0.223);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(5));

	// MergedLayer_2
	this.instance_3 = new lib.Group_2copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_3copy2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_4copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_5copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_6.alpha = 0.398;

	this.instance_7 = new lib.ClipGroup_7copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_8 = new lib.ClipGroup_1_0copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).to({state:[]},2).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,13,72,51.9);


(lib.hamel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		exportRoot.myhand.gotoAndStop(49);
	}
	this.frame_8 = function() {
		this.stop();
		
		exportRoot.myhand.gotoAndStop(37);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(4).call(this.frame_8).wait(3));

	// tb9_png
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],11), null, new cjs.Matrix2D(1,0,0,1,-325.5,-172.6)).s().p("AieBAIAAh/IE9AAIAAB/g");
	this.shape.setTransform(-314.4,190.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(11));

	// Layer_7
	this.instance = new lib.Front4();
	this.instance.parent = this;
	this.instance.setTransform(-375,193,0.854,0.792);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).wait(9));

	// Layer_10
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(-0.367,0.065,0.064,0.368,137,-133.3)).s().p("AhSBnIAAjNIClAAIAADNg");
	this.shape_1.setTransform(-385.3,77.3);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(4).to({_off:false},0).to({_off:true},4).wait(3));

	// Layer_6
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],78), null, new cjs.Matrix2D(1.419,0,0,1.359,-40.3,-55.2)).s().p("AmSHhIAAvBIMlAAIAAPBg");
	this.shape_2.setTransform(-276.7,213.7);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(3).to({_off:false},0).wait(8));

	// Layer_13
	this.instance_1 = new lib.Symbol19();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-274.5,225.9,0.878,0.878,0,0,0,33.5,36);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).wait(3));

	// Layer_12
	this.instance_2 = new lib.Symbol19();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-332.1,87.7,0.878,0.878,0,0,0,33.5,35.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).wait(1).to({regX:33.6,regY:36,x:-291.1,y:119.6},0).wait(1).to({x:-277.2,y:171.7},0).wait(1).to({x:-274.3,y:225.9},0).to({_off:true},1).wait(3));

	// Layer_8
	this.tabc_2 = new lib.Symbol1copy20();
	this.tabc_2.name = "tabc_2";
	this.tabc_2.parent = this;
	this.tabc_2.setTransform(-348.5,78.8,0.934,0.938,0,92,-88,28.1,17.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(-0.367,0.065,0.064,0.368,134,-98.6)).s().p("ABTBjIlnAAIAAiLIFKg7IC8AAIAbCcIACAHIAGAjg");
	this.shape_3.setTransform(-385.3,47);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(-0.367,0.065,0.064,0.368,160.5,-161.7)).s().p("AodhBIC/AAIAAhzICEAAIAAipICJAAIAAibIAdAAIAAAQIAKAAIFnAAIAABlIilAAIAADPIhDAAIAADXIidAAIAAGxIltA/gAH5oLIgCgIIAmAAIABAIg");
	this.shape_4.setTransform(-408.7,105.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.tabc_2}]},4).to({state:[]},4).wait(3));

	// Layer_11
	this.term_0 = new lib.Symbol17copy();
	this.term_0.name = "term_0";
	this.term_0.parent = this;
	this.term_0.setTransform(-260.8,167,0.931,0.822,5.5,0,0,0.8,0.1);
	this.term_0._off = true;

	this.timeline.addTween(cjs.Tween.get(this.term_0).wait(10).to({_off:false},0).wait(1));

	// becker_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],78), null, new cjs.Matrix2D(1.419,0,0,1.359,-40.3,-3.5)).s().p("AmSAjIAAhFIMlAAIAABFg");
	this.shape_5.setTransform(-276.7,162);
	this.shape_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(3).to({_off:false},0).wait(8));

	// Layer_5
	this.hod_3 = new lib.Symbol31copy4();
	this.hod_3.name = "hod_3";
	this.hod_3.parent = this;
	this.hod_3.setTransform(-253.7,263,1.988,1.987,0,0,0,65,38.1);
	this.hod_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.hod_3).wait(2).to({_off:false},0).wait(9));

	// Layer_4
	this.lahbb_2 = new lib.hamellcopy8();
	this.lahbb_2.name = "lahbb_2";
	this.lahbb_2.parent = this;
	this.lahbb_2.setTransform(-268.1,371.7,0.457,0.432,0,0,0,0,0.4);
	this.lahbb_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.lahbb_2).wait(1).to({_off:false},0).wait(10));

	// Layer_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],11), null, new cjs.Matrix2D(1,0,0,1,-295.9,-158.8)).s().p("AwHHdIAAgMIJlAAIAAkSIliAAIAAiaIFlAAIAAlpIpoAAIAAiYIQgAAIPvAAIAAAlIvvAAIAAglIAAAlIlfAAIAAE4IMOAAIAADKIk/AAIAACAInPAAIAAESg");
	this.shape_6.setTransform(-344.1,176.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],11), null, new cjs.Matrix2D(1,0,0,1,-327.4,-352)).s().p("A1BUAMAAAgn/ILBAAIAABOIVNAAIAAYRIJ2AAIAAOgg");
	this.shape_7.setTransform(-312.6,352);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-447.2,128.6,269.3,351.4);


(lib.empty_ice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-37.1,-23.1)).s().p("AgKAJIAAgRIAVAAIAAARg");
	this.shape.setTransform(35,38.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],75), null, new cjs.Matrix2D(0.231,0,0,0.231,-43.4,-17.8)).s().p("AlGBIIAAiOIKNAAIAABaIgFAAIAAAdIAFAAIAAAXg");
	this.shape_1.setTransform(31.2,45.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// MergedLayer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(31.3,44.9,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(31.8,44.6,1,0.905,0,0,0,35.5,20.6);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// MergedLayer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],73), null, new cjs.Matrix2D(0.234,0,0,0.234,-60.4,-71.9)).s().p("AlPAGIAAgKIKfAAIAAAKg");
	this.shape_2.setTransform(30.4,65);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// MergedLayer_2
	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(46.2,61.5,1,1,0,0,0,3.6,3.1);
	this.instance_2.alpha = 0.148;

	this.instance_3 = new lib.Group_3copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(16.9,61.5,1,1,0,0,0,4,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_4copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(32.1,59.9,1,1,0,0,0,18.3,2.4);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(31.8,63,1,1,0,0,0,14.6,2.9);
	this.instance_5.alpha = 0.398;

	this.instance_6 = new lib.ClipGroup_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(31.8,45.5,1,1,0,0,0,35.6,20.5);

	this.instance_7 = new lib.ClipGroup_1_0();
	this.instance_7.parent = this;
	this.instance_7.setTransform(31.6,30.7,1,1,0,0,0,35.6,10.8);

	this.instance_8 = new lib.Group_6();
	this.instance_8.parent = this;
	this.instance_8.setTransform(23.1,64.6,1,1,0,0,0,19.4,2.1);
	this.instance_8.alpha = 0.148;

	this.instance_9 = new lib.Group_7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(40.3,64.6,1,1,0,0,0,19.6,2.1);
	this.instance_9.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.empty_ice, new cjs.Rectangle(-4.4,19.8,72,47), null);


(lib.Scene_1_tools_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// tools_3
	this.bt_ice_2 = new lib.Symbol1copy21();
	this.bt_ice_2.name = "bt_ice_2";
	this.bt_ice_2.parent = this;
	this.bt_ice_2.setTransform(995.4,423.7,1.053,1.053,0,0,0,28.1,17.7);

	this.term_0 = new lib.Symbol17();
	this.term_0.name = "term_0";
	this.term_0.parent = this;
	this.term_0.setTransform(904.7,599.9,0.765,0.765,-64.7,0,0,0,0.5);

	this.lahb_1 = new lib.myhamel();
	this.lahb_1.name = "lahb_1";
	this.lahb_1.parent = this;
	this.lahb_1.setTransform(971.8,542.9,0.598,0.598,0,0,0,74.4,81.7);
	new cjs.ButtonHelper(this.lahb_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lahb_1},{t:this.term_0},{t:this.bt_ice_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_tools_3_1, null, null);


(lib.Scene_1_tools_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// tools_3
	this.emptyice = new lib.empty_ice();
	this.emptyice.name = "emptyice";
	this.emptyice.parent = this;
	this.emptyice.setTransform(997.7,428.1,1.124,1.066,0,0,0,28.1,17.7);
	this.emptyice.visible = false;

	this.arrow_7 = new lib.arrow_1();
	this.arrow_7.name = "arrow_7";
	this.arrow_7.parent = this;
	this.arrow_7.setTransform(997.6,351.4,0.598,0.598,0,0,0,32.2,50);
	this.arrow_7.visible = false;

	this.myhod3 = new lib.Symbol31copy2();
	this.myhod3.name = "myhod3";
	this.myhod3.parent = this;
	this.myhod3.setTransform(333.4,569.7,1.276,1.275,0,0,0,65,38);
	this.myhod3.visible = false;

	this.hhml_22 = new lib.hamel();
	this.hhml_22.name = "hhml_22";
	this.hhml_22.parent = this;
	this.hhml_22.setTransform(642,465.8,0.65,0.65,0,0,180,-322.9,243.1);
	this.hhml_22.visible = false;

	this.arrow_4 = new lib.arrow_1();
	this.arrow_4.name = "arrow_4";
	this.arrow_4.parent = this;
	this.arrow_4.setTransform(246.7,334.5,0.598,0.598,0,0,0,30.1,41.5);
	this.arrow_4.visible = false;

	this.arrow_5 = new lib.arrow_1();
	this.arrow_5.name = "arrow_5";
	this.arrow_5.parent = this;
	this.arrow_5.setTransform(353.5,481.7,0.598,0.598,0,0,0,32.2,50);
	this.arrow_5.visible = false;

	this.arrow_3 = new lib.arrow_1();
	this.arrow_3.name = "arrow_3";
	this.arrow_3.parent = this;
	this.arrow_3.setTransform(850.7,464.4,0.598,0.598,0,0,0,32.2,50);
	this.arrow_3.visible = false;

	this.arrow_2 = new lib.arrow_1();
	this.arrow_2.name = "arrow_2";
	this.arrow_2.parent = this;
	this.arrow_2.setTransform(949.7,464.4,0.598,0.598,0,0,0,32.2,50);
	this.arrow_2.visible = false;

	this.arrow_6 = new lib.arrow_1();
	this.arrow_6.name = "arrow_6";
	this.arrow_6.parent = this;
	this.arrow_6.setTransform(975.3,509.9,0.598,0.598,0,0,0,32.2,50);
	this.arrow_6.visible = false;

	this.arrow_1 = new lib.arrow_1();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(1125.2,402.3,0.598,0.598,0,0,0,32.2,50);

	this.becker_2 = new lib.mybeker2();
	this.becker_2.name = "becker_2";
	this.becker_2.parent = this;
	this.becker_2.setTransform(975.3,589.4,1.925,1.924,0,0,0,32.4,29.3);
	new cjs.ButtonHelper(this.becker_2, 0, 1, 1);

	this.myhod2 = new lib.myhod2();
	this.myhod2.name = "myhod2";
	this.myhod2.parent = this;
	this.myhod2.setTransform(847.1,541.3,1.276,1.275,0,0,0,65,38);
	new cjs.ButtonHelper(this.myhod2, 0, 1, 1);

	this.hhml_12 = new lib.hamel();
	this.hhml_12.name = "hhml_12";
	this.hhml_12.parent = this;
	this.hhml_12.setTransform(1087.5,502.8,0.537,0.537,0,0,180,-322.8,243);

	this.coode_1 = new lib.Symbol53();
	this.coode_1.name = "coode_1";
	this.coode_1.parent = this;
	this.coode_1.setTransform(1281.5,55.4,0.598,0.598,0,0,0,1.4,-1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.coode_1},{t:this.hhml_12},{t:this.myhod2},{t:this.becker_2},{t:this.arrow_1},{t:this.arrow_6},{t:this.arrow_2},{t:this.arrow_3},{t:this.arrow_5},{t:this.arrow_4},{t:this.hhml_22},{t:this.myhod3},{t:this.arrow_7},{t:this.emptyice}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_tools_3, null, null);


(lib.Symbol4copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{becker_0:26});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_67 = function() {
		this.gotoAndStop(39);
	}
	this.frame_76 = function() {
		this.stop();
	}
	this.frame_80 = function() {
		this.gotoAndPlay(77);
	}
	this.frame_86 = function() {
		this.gotoAndPlay(83);
		
		 
		/*
		if (this.aood_1.text == "1")
		{
		 createjs.Sound.play("sound_7");
			this.aood_1.text = "2";
		}
		 */
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(64).call(this.frame_67).wait(9).call(this.frame_76).wait(4).call(this.frame_80).wait(6).call(this.frame_86).wait(4));

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-371.3,-348.1)).s().p("Aj9DYIAAmvIAmAAIAAAaIHNAAIAAgaIAIAAIAAGvg");
	this.shape.setTransform(14.5,118.7);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.952,0.416,-0.305,1.297,-334.1,-587.2)).s().p("AMjJxIzcAAIh+h+Ig1g2IA+AAIAAkGIAkAAIAAjlIgkAAIAAgMIiiAAQASghABgqIAtgkIiTlUIFZAAIAAgzIAAgvIAKAYIAxgpQAFAMANAHQAKAGAXAAIAmACQAcACAMgHQAUADAbAIQAeANAOAEQA4ARAlgLQAhgPAQgDIAVAAIATAAQAZgHANABQAOAEAIAAQAKAAASgNIFiM0ICIhtIDfIDg");
	this.shape_1.setTransform(303.2,-17.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.952,0.24,-0.305,0.75,-268.2,-305.9)).s().p("AiQAiIgEAAIgzhDIGDAAIgBAAIABAAIAAAAIAMARIAAAyg");
	this.shape_2.setTransform(237.4,-71.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.952,0.099,-0.305,0.31,-257.3,-116.4)).s().p("AhZBXIjPhyICYgcIgIgFICIgaIE5Ctg");
	this.shape_3.setTransform(226.4,-83.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.952,0.376,-0.305,1.172,-355.1,-593.1)).s().p("AnfA9IgLgFQgtgVgRgMQgKgHgjgcIg2gwITcAAIA7B5g");
	this.shape_4.setTransform(324.3,51.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.952,0.305,-0.305,0.952,-385.3,-560.1)).s().p("AmqmpQAAgXgFgXQgLgugsg8QgGgIgIgEQgJgFgGAGQgMgRgVgPQgOgJgagMIgwgXIgig6IgnAYIhIggIAAAAIRsAAIGvLdIoSLYg");
	this.shape_5.setTransform(354.4,130.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(1.038,-0.508,0.209,0.862,-498.1,-31)).s().p("AjWB8IBpkuIB3hOIDJAAIgBABQAJBDgJA7IgDASIgKAAIAAAqQgWBEgvA7IgGAHQgRAUgUAUIjnCYg");
	this.shape_6.setTransform(44.1,5.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.862,-0.508,0.508,0.862,-521.4,-14.8)).s().p("AAdAyIgfAAIAAgRQAIg7gIhDIAAgBIjJAAIAAAAICLh3IgSgUIAGgGIEYFJIivCWg");
	this.shape_7.setTransform(65.5,-10.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.876,-0.508,0.114,0.862,-387.1,-28.3)).s().p("AhLAPIAXhCICAhkIhoEvg");
	this.shape_8.setTransform(25.6,2.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},29).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},5).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},2).to({state:[{t:this.shape}]},1).to({state:[]},10).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape}]},10).to({state:[]},11).to({state:[]},2).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(29).to({x:44.5,y:-232.9},0).wait(1).to({x:14.5,y:118.7},0).wait(5).to({_off:true},2).wait(1).to({_off:false},0).to({_off:true},10).wait(11).to({_off:false},0).to({_off:true},11).wait(19));

	// Layer_9
	this.text = new cjs.Text("HgO", "19px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 23;
	this.text.lineWidth = 49;
	this.text.parent = this;
	this.text.setTransform(225.2,-38.7,1.719,2.219,-90);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape_9.setTransform(249,-35.3,1.719,2.219,-90);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],8), null, new cjs.Matrix2D(0.98,0.421,-0.421,0.98,12.1,-137.5)).s().p("AqCI4IAAiiIGivNINjAAIAARvg");
	this.shape_10.setTransform(-53.9,112.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9},{t:this.text}]},38).to({state:[]},1).to({state:[{t:this.shape_10}]},32).to({state:[{t:this.shape_10}]},2).to({state:[{t:this.shape_10}]},1).to({state:[]},13).wait(3));

	// Layer_8
	this.instance = new lib.Front();
	this.instance.parent = this;
	this.instance.setTransform(131,1.9,1.721,2.22,-90);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(38).to({_off:false},0).to({_off:true},1).wait(51));

	// Layer_11 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_38 = new cjs.Graphics().p("Ai1DWQgTgDgggCQgsgDgXgGQgYgFghgOIg5gYQgTgIgsgNQgqgNgWgJQgXgJgpgUQgrgWgVgJQgtgTgwgJQgogIhDgGIhhgKIAAjXIeLAAIAAGrgAvFDWIAAgiIBGAFQBLAFAsANIAiALg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_graphics_38,x:227.6,y:-19.5}).wait(1).to({graphics:null,x:0,y:0}).wait(51));

	// Layer_10
	this.instance_1 = new lib.Symbol42();
	this.instance_1.parent = this;
	this.instance_1.setTransform(219.3,-39.1,1.721,3.708,-90,0,0,22.8,25.6);
	this.instance_1._off = true;
	this.instance_1.filters = [new cjs.ColorFilter(0.33, 0.33, 0.33, 1, 170.85, 0, 0, 0)];
	this.instance_1.cache(-2,-2,50,55);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(38).to({_off:false},0).to({_off:true},1).wait(51));

	// Layer_6
	this.text_1 = new cjs.Text("Mg", "19px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 49;
	this.text_1.parent = this;
	this.text_1.setTransform(-94.7,84.8,3.514,3.022);

	this.instance_2 = new lib.Group_0copy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-95.7,109.6,3.514,3.512,0,0,0,33,7);
	this.instance_2.alpha = 0.621;

	this.instance_3 = new lib.Group_1copy2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-93.9,108.2,3.514,3.512,0,0,0,35.5,20.5);
	this.instance_3.alpha = 0.59;

	this.instance_4 = new lib.Group_2copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-43.5,167.9,3.514,3.512,0,0,0,3.6,3.1);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_3copy2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-146.3,168.1,3.514,3.512,0,0,0,4,3.1);
	this.instance_5.alpha = 0.148;

	this.instance_6 = new lib.Group_4copy2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-92.9,162.5,3.514,3.512,0,0,0,18.3,2.4);
	this.instance_6.alpha = 0.148;

	this.instance_7 = new lib.Group_5copy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-93.9,173.4,3.514,3.512,0,0,0,14.6,2.9);
	this.instance_7.alpha = 0.398;

	this.instance_8 = new lib.ClipGroup_7copy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-94.1,111.7,3.514,3.512,0,0,0,35.6,20.5);

	this.instance_9 = new lib.Group_6copy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-124.7,179,3.514,3.512,0,0,0,19.4,2.1);
	this.instance_9.alpha = 0.148;

	this.instance_10 = new lib.Group_7copy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-64.1,179,3.514,3.512,0,0,0,19.6,2.1);
	this.instance_10.alpha = 0.148;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("Aq9UUMAAAgonITvAAIAAIiICMAAMAAAAgFg");
	this.shape_11.setTransform(-63.8,84);

	this.text_2 = new cjs.Text("HCl", "19px 'Arial'", "#FFFFFF");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 23;
	this.text_2.lineWidth = 49;
	this.text_2.parent = this;
	this.text_2.setTransform(-59.9,69.7,3.167,3.167);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape_12.setTransform(-59.6,112,3.167,3.167);

	this.instance_11 = new lib.Symbol42();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-59,126.3,3.171,3.171,0,0,0,22.7,25.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],68), null, new cjs.Matrix2D(1,0,0,0.886,-94,-122.3)).s().p("AurTHMAAAgmNIWZAAIAAGXIG+AAIAAf2g");
	this.shape_13.setTransform(-57,96.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],70), null, new cjs.Matrix2D(1.243,0,0,0.788,-83.2,-51.3)).s().p("ApMIBIAAsIIj0AAIAAj4IXuAAIAAGYIBBAAIAAAcIBSAAIAAJMg");
	this.shape_14.setTransform(-48,77.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFE500").s().p("AgvAsIgEgpIAjg/IA9AlIAHAbIgBAiIgsAXg");
	this.shape_15.setTransform(-208,55.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFE500").s().p("AgfApIgRglIAbghIAxgfIADAaIARAeIgFAuIgeATg");
	this.shape_16.setTransform(-203.5,39.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFE500").s().p("AgsAnIAEgbIAOgiIA1gpIACAmIAQAdIAAAmIgmAWg");
	this.shape_17.setTransform(-198.9,42.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFE500").s().p("AgeAjIgOgdIgCgXIA1gtIAoAnIgJAgIAEAjIgkASg");
	this.shape_18.setTransform(-216.8,44.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFE500").s().p("Ag0AeIAEgXIAZggIANgcIAvAZIAPAeIABAmIg1AOg");
	this.shape_19.setTransform(-200.8,46.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFE500").s().p("AgiAlIgPgVIARhTIBCAtIAQAWIgxBEg");
	this.shape_20.setTransform(-200.6,39.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFE500").s().p("AgmAxIgIgnIAIggIAUggIA2AdIALAUIgCA8g");
	this.shape_21.setTransform(-206.6,45.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFE500").s().p("AgnAnIACg4IAGADIAmguIAIAbIAaAhIgaA0IgKAJg");
	this.shape_22.setTransform(-204.6,41);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFE500").s().p("AgqAmIABguIASgVIAsghIABApIAVAMIgCAtIggAbg");
	this.shape_23.setTransform(-211.9,37);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFE500").s().p("AgTB0IgogZIgqg4IBYirIBzCwIg6BbIg3AGg");
	this.shape_24.setTransform(-199.8,52.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFE500").s().p("AgsA2IAbhOIgGgmIArAmIAZAdIABAyIg8AIg");
	this.shape_25.setTransform(-210.5,48.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFE500").s().p("AgvAZIALgzIgBgCIAmgTIAdAIIASAXIgeArIADAVg");
	this.shape_26.setTransform(-198.1,39.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFE500").s().p("AghAjIADgkIAVgnIAJgdIAiAkIgCBDIgyAkg");
	this.shape_27.setTransform(-210.1,47.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFE500").s().p("AAKA/IgWgHIgjg3IAVg/IAoAYIAiA0IAAAxg");
	this.shape_28.setTransform(-197.4,35.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFE500").s().p("AghAgIgGgZIAchEIAzAMIgBA7IgJAkIgkAQg");
	this.shape_29.setTransform(-199.3,41.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFE500").s().p("AgcAvIgIhEIAIgJIABgWIAqAKIAWAgIgaA/g");
	this.shape_30.setTransform(-199.7,29.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFE500").s().p("AgnAXIgDgbIAigZIAzgdIgFATIgPAaIgKAkIAEAlg");
	this.shape_31.setTransform(-202.7,48.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFE500").s().p("AgQAAIgbgLIAfglIgegKIAngCIgJAMIA4ATIgBAPIgRAwIgTAbg");
	this.shape_32.setTransform(-216,47.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFE500").s().p("AgqgWIAVgdIBAARIgQA7IgLAJIgnASg");
	this.shape_33.setTransform(-189.1,36.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFE500").s().p("AgcABIADgTIAagSIgDAhIAOAHIARAcIgpADIgIACg");
	this.shape_34.setTransform(-191,32.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFE500").s().p("AgZAaIgHgIIALg0IAOgTIAeAyIAKgPIgIApIggAfg");
	this.shape_35.setTransform(-201.1,43.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFE500").s().p("AgNAiIgIggIgIgUIAvgWIgDAeIAPAKIgNAkIAEAFg");
	this.shape_36.setTransform(-198.4,26.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFE500").s().p("AgXAXIAVgnIAEgVIAAAiIAMAUIAKAFIgMAQg");
	this.shape_37.setTransform(-205.5,44.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFE500").s().p("AgHgLIgKgDIARgLIAFAQIAOAPIgEAOIgZgDIgFAJg");
	this.shape_38.setTransform(-197.9,35.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFE500").s().p("AgTANIAFgTIAigRIgLAKIgJARIAIgBIgBAVg");
	this.shape_39.setTransform(-195.6,34.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFE500").s().p("AgGAKIAFgNIgBAAIAAgHIAIAIIgFACIAFALgAAGgCIABgBIgBACgAAGgCg");
	this.shape_40.setTransform(-200.4,31.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFE500").s().p("AgFAKIABgIIgCgBIAEgMIAIAKIgEAGIAFACIgCAFg");
	this.shape_41.setTransform(-201.4,28.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FF8C00").s().p("AghArIgRhUIgQgDIAOgKIgBgCIACABIBQg/IAlCRIgBAXIhBBFg");
	this.shape_42.setTransform(-213.5,40.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FF8C00").s().p("Ag4gqIBhg3IAGA4IgLAcIggArIA1A+IhlAGg");
	this.shape_43.setTransform(-192.3,23.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FF8C00").s().p("AAfAyIAmAIIgbA9gAhEAbIAUgUIgChBIArg8IA5BZIgaAjIAHAsg");
	this.shape_44.setTransform(-194.6,31.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FF8C00").s().p("AgWAkIgDgHIgLhLIBKgpIgmAYIACBGIAYAFIg7BMg");
	this.shape_45.setTransform(-201.8,28.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FF8C00").s().p("Ag3AWIgOhkIBhAaIAmAiIAEAzIgfARIASAaIhEADg");
	this.shape_46.setTransform(-193.2,44.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FF8C00").s().p("AgnBKIACg6IgNgOIAkhVIA7BEIgfAxIAlARIgKAhg");
	this.shape_47.setTransform(-200.2,32.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FF8C00").s().p("AgwBMIAkhrIgCgDIgLgrIBBA3IgeAUIAfBQgAAogWIAJgHIgCANgAAogWg");
	this.shape_48.setTransform(-200.6,38.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FF8C00").s().p("AhGAuIAThJIB6g6IgmAiIgnA9IAkgBIgEBNgAgwgqIgDAPIgCAAgAgzgbg");
	this.shape_49.setTransform(-194.6,39.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FF8C00").s().p("AgegrIgkgMIA9gmIAXA4IAwA7IgMAwIhbgMIgWAkg");
	this.shape_50.setTransform(-197.4,39.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FF8C00").s().p("Ag6A3IA1heIAIg1IADBUIAcAwIAZAOIgcAng");
	this.shape_51.setTransform(-205.3,44.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FF8C00").s().p("AgeBTIgUhOIgWgxIB1g1IgIBHIAkAbIggBWIALALg");
	this.shape_52.setTransform(-197.7,28.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FF8C00").s().p("AgtAvIgNgOIAUhfIAZgjIA3BbIARgdIgPBMIg5A5g");
	this.shape_53.setTransform(-201.1,43.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FF8C00").s().p("Ag0ADIAGglIAvggIgHA8IAaAOIAhAxIhMAFIgOAFg");
	this.shape_54.setTransform(-190.3,32.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FF8C00").s().p("Ag9ghIAegpIBdAXIgFAMIgRBLIgQANIg7Aag");
	this.shape_55.setTransform(-188.9,35.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FF8C00").s().p("AgYAAIgogPIAvg3IgrgPIA4gCIgNARIBSAcIgCAVIgaBGIgbAng");
	this.shape_56.setTransform(-216.4,47.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FF8C00").s().p("Ag5AhIgEgnIAwgkIBLgrIgIAbIgVAlIgNA1IAEA2g");
	this.shape_57.setTransform(-202.6,47.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FF8C00").s().p("AgqBDIgLhhIALgOIACggIA9AOIAhAvIgmBcg");
	this.shape_58.setTransform(-199.7,28.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FF8C00").s().p("AgxAuIgIgkIAohhIBLAQIgDBXIgLAzIg2AVg");
	this.shape_59.setTransform(-199.1,40.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FF8C00").s().p("AAOBbIgfgKIgzhPIAfhcIA5AiIAwBMIABBHg");
	this.shape_60.setTransform(-197.4,33.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FF8C00").s().p("AgwA0IADg2IAeg4IAPgqIAwA1IACA/IgFAhIhIA0g");
	this.shape_61.setTransform(-210.1,46.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FF8C00").s().p("AhFAkIARhLIgCgBIA3gcIArALIAaAiIgsA/IAFAdg");
	this.shape_62.setTransform(-197.9,38.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FF8C00").s().p("AhBBNIAohwIgJg2IA+A0IAkAtIACBHIhYAMg");
	this.shape_63.setTransform(-210.6,46.9);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FF8C00").s().p("AgcCoIg5gkIg9hRICAj3IClD9IgmBHIgtA+IhPAHg");
	this.shape_64.setTransform(-199.9,48.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FF8C00").s().p("Ag9A2IAAhBIAcghIA/guIABA8IAfAQIgDBDIgvAmg");
	this.shape_65.setTransform(-212,35.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FF8C00").s().p("Ag6A4IAFhQIAHADIA4hCIALAnIAmAwIgmBLIgOAOg");
	this.shape_66.setTransform(-204.3,39.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FF8C00").s().p("Ag3BFIgNg2IANgwIAcgtIBPAqIARAdIgEBWg");
	this.shape_67.setTransform(-206.5,43.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FF8C00").s().p("AgyA3IgVgeIAZh6IBfBCIAXAfIhHBig");
	this.shape_68.setTransform(-200.4,38.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FF8C00").s().p("AhLAqIAHggIAjgwIATgnIBEAkIAVArIABA2IhLAWg");
	this.shape_69.setTransform(-200.9,45.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FF8C00").s().p("AgsAxIgUgpIgDggIBOhBIA4A4IgMAtIAGAyIgzAdg");
	this.shape_70.setTransform(-217,43.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FF8C00").s().p("AhAA4IAFgnIAVgyIBNg7IACA2IAYAsIAAA2Ig3Ahg");
	this.shape_71.setTransform(-199,40.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FF8C00").s().p("AguA7IgXg2IAngwIBHgtIAEAmIAZArIgJBEIgqAcg");
	this.shape_72.setTransform(-203.7,38.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FF8C00").s().p("AhFBAIgEg8IAxhcIBYA2IAKAoIgBAxIg/Aig");
	this.shape_73.setTransform(-208.2,54.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FF8C00").s().p("Ag5AuIgIgzIAHgYIBXg3IAYAtIANAqIgVA8Ig1AWg");
	this.shape_74.setTransform(-189.5,50.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FF8C00").s().p("AgcApIgThBIAVggIBCBhIgJAQIAVAYgAgmhIIAPAKIgDAGgAgzhRIAIACIAFAHg");
	this.shape_75.setTransform(-196.1,35.8);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FF3300").s().p("AhfBjIAHiRIBYhKIBgBJIgHAoIABBuIhuASg");
	this.shape_76.setTransform(-192.3,28.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FF3300").s().p("AhZBIIgMhQIAMgmICFhUIAlBFIAVBDIggBcIhSAgg");
	this.shape_77.setTransform(-189.3,42.2);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FF3300").s().p("AhrBhIgGhcIApg+IAjhPICIBTIAPA9IgCBMIhhA1g");
	this.shape_78.setTransform(-208.4,46);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FF3300").s().p("AhHBbIgjhUIA7hKIBvhEIAFA7IAnBBIgPBoIhAArg");
	this.shape_79.setTransform(-204.1,30.9);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FF3300").s().p("AhjBXIAJg9IAehMIB5hcIACBVIAlBCIAABUIhUAyg");
	this.shape_80.setTransform(-199.2,32.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FF3300").s().p("AhFBLIgeg/IgEgyIB5hlIBWBXIgTBHIAJBNIhPArg");
	this.shape_81.setTransform(-217.4,35.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FF3300").s().p("Ah1BBIAMgwIA0hMIAfg8IBpA4IAgBDIADBTIh2Ahg");
	this.shape_82.setTransform(-200.8,37.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FF3300").s().p("AhNBTIghguIAXhNIAPhuICTBlIAjAxIhsCXg");
	this.shape_83.setTransform(-200,30);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FF3300").s().p("AgHB1IhQgKIgRhUIAShJIAshHIB5BBIAaAsIgFCGg");
	this.shape_84.setTransform(-206.4,35.7);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FF3300").s().p("AhaBWIAHh8IAMAFIBWhmIAQA9IA8BJIg6B1IgWAUg");
	this.shape_85.setTransform(-203.7,31.9);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FF3300").s().p("AheBUIAAhlIArgyIBhhJIABBdIAwAYIgFBoIhIA8g");
	this.shape_86.setTransform(-212.3,28);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FF3300").s().p("AgqECIhag4Ihdh8IDGl8ID9GGIg7BuIhDBeIh7ALg");
	this.shape_87.setTransform(-200.1,36.8);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FF3300").s().p("AhlB3IA+ivIgOhSIBgBRIA4BFIADBtIiHASg");
	this.shape_88.setTransform(-210.9,38.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FF3300").s().p("AhpA3IAYhzIgDgCIBXgrIBBARIAmAzIhBBiIAHAtg");
	this.shape_89.setTransform(-197.5,31.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FF3300").s().p("AhLBPIAGhTIAvhWIAWhAIBMBQIgGCWIhxBPg");
	this.shape_90.setTransform(-210.2,38.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FF3300").s().p("AAWCNIgxgRIhOh5IAfhOIAQhBIBZA1IBLB1IAABvg");
	this.shape_91.setTransform(-197.5,25.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FF3300").s().p("AhMBHIgMg4IAbhLIAjhLIBzAaIgECGIgTBOIhTAhg");
	this.shape_92.setTransform(-198.9,32.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FF3300").s().p("AhABmIgTiVIASgVIACgxIBgAWIAzBHIg6COg");
	this.shape_93.setTransform(-199.7,20.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FF3300").s().p("AhYA0IgGg/IBIg3IB1hCIgMAqIggA6IgVBSIAHBTg");
	this.shape_94.setTransform(-202.4,39.7);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FF3300").s().p("AgmAAIg8gZIBHhUIhCgXIBWgCIgUAZIB+ArIgCAiIgnBsIgqA7g");
	this.shape_95.setTransform(-217.2,40.8);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FF3300").s().p("AhegyIAvhBICOAlIgiCGIgaATIhZApg");
	this.shape_96.setTransform(-188.8,28.3);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FF3300").s().p("AhQAFIAJg7IBIgwIgKBcIAoAWIAyBMIh0AIIgXAHg");
	this.shape_97.setTransform(-189.5,24.3);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FF3300").s().p("AhHBIIgTgWIAgiRIAkg2IBWCLIAbgtIgWB3IhbBWg");
	this.shape_98.setTransform(-201.2,35.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FF3300").s().p("AgvB/Igfh3IghhNICyhSIgKBuIA3AqIgyCEIARATg");
	this.shape_99.setTransform(-197,19.8);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FF3300").s().p("AhaBVIBQiSIAOhRIAECBIAsBLIAmAVIgrA8g");
	this.shape_100.setTransform(-205,34.7);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FF3300").s().p("AguhCIg4gTIBfg6IAkBVIBKBcIgUBKIiMgSIgjA2g");
	this.shape_101.setTransform(-197.2,31.8);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FF3300").s().p("AhtBHIAehxIC9haIg7A1Ig8BgIA4gDIgIB3gAhJhBIgGAXIgDABgAhPgqg");
	this.shape_102.setTransform(-193.9,32.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FF3300").s().p("AhLB0IA4ikIgEgEIgQhDIBlBVIguAgIAuB6gAA+giIAPgKIgFATgAA+gig");
	this.shape_103.setTransform(-200.6,31.7);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FF3300").s().p("Ag9ByIAChZIgTgWIA3iDIBdBpIgxBLIA6AbIgQAyg");
	this.shape_104.setTransform(-199.4,23.8);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FF3300").s().p("AhVAiIgViaICVAoIA6AzIAGBPIgwAaIAcApIhoAEg");
	this.shape_105.setTransform(-193.3,37.4);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FF3300").s().p("AgjA3IgEgKIgSh0IBzg/Ig6AlIADBrIAkAIIhbB1g");
	this.shape_106.setTransform(-201.3,21.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FF3300").s().p("AAvBMIA7ANIgqBegAhpAqIAfggIgFhkIBDhcIBZCJIgoA3IAKBCg");
	this.shape_107.setTransform(-194.2,23.5);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FF3300").s().p("AhXhAICVhWIAKBXIgRArIgwBBIBRBgIibAKg");
	this.shape_108.setTransform(-192.4,15.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FF3300").s().p("AgyBCIgciCIgXgFIAUgPIgBgCIADABIB9hhIA4DgIAAAjIhnBqg");
	this.shape_109.setTransform(-214.2,33.5);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FF3300").s().p("AgqA9IgfhjIAfgwIgSgaIAXARIgFAJIBoCTIgOAaIAfAngAhOh9IALADIAHAKg");
	this.shape_110.setTransform(-194.5,26.9);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FF3300").s().p("Ag6CSIgJADIgihvIBWjKIB1D/Ig6AtIgIgOIAIArg");
	this.shape_111.setTransform(-197.2,25.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FF3300").s().p("AhYCyIASg8IgUgpIBvkfIBGElIg/gWIADCXg");
	this.shape_112.setTransform(-198.4,31.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFE500").s().p("AgbB4IgggMIgng7IBYiwIBtCrIgQA9Ig0ARIgYAGg");
	this.shape_113.setTransform(-199,52.4);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFE500").s().p("AgnAoIgFgtIAVggIA3gYIAAAfIAOAfIAAAtIgyAQg");
	this.shape_114.setTransform(-211.6,43.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFE500").s().p("AgqAuIgMguIAYggIALgaIBBAXIAJBJIg3AVg");
	this.shape_115.setTransform(-198.7,41.8);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFE500").s().p("AgsAoIgBghIATgqIAcgbIAfAbIANArIgNAkIgmATg");
	this.shape_116.setTransform(-196.1,40.1);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFE500").s().p("AAOA1Ig0gQIgEgpIAMgOIAjgiIAiAXIgDApIAHApg");
	this.shape_117.setTransform(-189.4,47.5);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFE500").s().p("AgiAgIgNggIAGgaIA+ggIAAALIAbArIgLApIgoAWg");
	this.shape_118.setTransform(-201.1,44.5);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFE500").s().p("AgkA2IgMgyIARgeIAfgfIAZAPIAMAdIAMBCIg5AFg");
	this.shape_119.setTransform(-202.5,42);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFE500").s().p("AglApIAGhTIAvgcIAKAVIABA1IALAfIgaAkg");
	this.shape_120.setTransform(-207.7,51.8);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFE500").s().p("AgkAdIAAg5IgFgUIBKgUIgEASIANBVIg3Aig");
	this.shape_121.setTransform(-210.6,39.9);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFE500").s().p("AgcBAIgRg5IAZgnIAEgoIA+AiIgCAbIgNA1IgeAfg");
	this.shape_122.setTransform(-202,48.4);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFE500").s().p("AgogOIAMgaIgFgYIAyAPIAYAeIggAxIgmAjg");
	this.shape_123.setTransform(-184.7,38.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFE500").s().p("AgjAbIgPgXIALglIAwgYIAIAlIAigBIgGBOIgaABg");
	this.shape_124.setTransform(-192.9,36.6);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFE500").s().p("AgmANIAKgQIgLg5IBEABIgXAZIAiAFIgXBag");
	this.shape_125.setTransform(-191.5,47.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFE500").s().p("AgrgVIAfgdIASgGIAbAAIALAjIgBAgIg0Aug");
	this.shape_126.setTransform(-203.3,43.3);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFE500").s().p("AgUA3IgOgqIAChGIAjAPIARADIAKAYIAFA6IgQAPg");
	this.shape_127.setTransform(-213.6,44.6);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFE500").s().p("AgMBnIg8gaIgcgcIBairIBvCaIggBEIgjAPIhCAIg");
	this.shape_128.setTransform(-197.8,52.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFE500").s().p("AgPAyIACgcIgRg7IAegaIATA9IAHACIAFA5IgoAHg");
	this.shape_129.setTransform(-208.9,46.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFE500").s().p("AgkAcIAMgaIAMgGIgagsIBFAKIgKAxIASAPIgFAXg");
	this.shape_130.setTransform(-191.4,50.2);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFE500").s().p("AgcCGIgHgNIgwggIBPj0IBYC8IgEBXIhZAkg");
	this.shape_131.setTransform(-199.6,49.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFE500").s().p("AgNAOIgEgYIAWgZIgFgJIAUgHIgPAQIARAsIgaAnIgRAEg");
	this.shape_132.setTransform(-195.6,26.8);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFE500").s().p("AgRgXIgXgPIACgIIAoAbIAnAQIgSAZIgWAKIgXAPg");
	this.shape_133.setTransform(-199.8,28.9);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFE500").s().p("AgWAhIgEgyIAWAGIACgiIAdANIgLASIgEAyIgRAKg");
	this.shape_134.setTransform(-191.6,29.4);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFE500").s().p("AgNAlIgMgnIATgbIAAgUIAMAPIAJAuIALACIgTAkg");
	this.shape_135.setTransform(-210.9,37.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFE500").s().p("AgOgGIAMgDIARgQIgJAMIAIAFIgMAig");
	this.shape_136.setTransform(-190.8,41);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFE500").s().p("AgPAWIAGgLIAAgnIAYAWIgDASIAEAPIgRACg");
	this.shape_137.setTransform(-205.6,44.1);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFE500").s().p("AADAMIAFgCIgGADgAgHABIAJgGIgDgGIAJAAIgGAGIAGAIIgFAJIgGAAg");
	this.shape_138.setTransform(-199.3,22.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFE500").s().p("AgHAFIAFAAIACgHIgCgCIAKgMIgHAMIgBACIAEACIgCARg");
	this.shape_139.setTransform(-198.4,27);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FF8C00").s().p("AAuBYIgDgIIhYhVIALhNIgngmIAyAiIBhBoIgHBng");
	this.shape_140.setTransform(-198.9,24);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FF8C00").s().p("AgiA7IAQgTIgpgNIAUgtIAkgHIAagiIASAaIg7BJIBOAXgAgVg+IgSAsIgJADg");
	this.shape_141.setTransform(-195.8,28.3);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FF8C00").s().p("AgiBbIAzhpIgWgfIggg8IA3BBIAEAPIgFALIAWAdIATBTIhzAJg");
	this.shape_142.setTransform(-208.7,35.8);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FF8C00").s().p("AgpDWIAwg8Ih1iYIAyjZICrDkIglBDIgeCIg");
	this.shape_143.setTransform(-198.9,45.5);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FF8C00").s().p("AgyAkIAcgwIAJgpIA2gnIgxBZIAcgeIAfA+IgPBAg");
	this.shape_144.setTransform(-212.2,28);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FF8C00").s().p("AgyATIAUhGIADgaIA6AfIAGAGIAOB1IhGgoIgJApg");
	this.shape_145.setTransform(-206.3,37.3);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FF8C00").s().p("AgIBDIASgPIABgOIg6AcIAUhEIgzhzIBqBpIAzAJIhFA3IgGBCg");
	this.shape_146.setTransform(-200.8,29.3);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FF8C00").s().p("AAsA9IhRgdIAsgZIgShXIAvAnIAhAwIADBKgAhHAUIAiAMIgEACgAglAgg");
	this.shape_147.setTransform(-200.5,36.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FF8C00").s().p("AgSAmIgLgRIgfgBIAriBIA0B2IgUAvIAtAtIgVAJg");
	this.shape_148.setTransform(-214.9,33.8);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FF8C00").s().p("Ag7AjIAnAGIAUg9IgQgOIBMhXIg4BZIgEAMIAeAZIgHAaIgJBbg");
	this.shape_149.setTransform(-197.9,32.9);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FF8C00").s().p("AAVBQIAfgGIglASgAg9AJIA+gpIAMgMIgbgrIBMgEIgxAvIAoBAIggA8IgyAJg");
	this.shape_150.setTransform(-198.9,28.7);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FF8C00").s().p("Ag4BPIARgoIgBiQIBdBQIgLBDIAPA5IhBAHg");
	this.shape_151.setTransform(-206,47.3);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FF8C00").s().p("Ag3gXIArgOIBEg4IgiAqIAcAUIgqB9g");
	this.shape_152.setTransform(-191.2,45.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FF8C00").s().p("AgiBZIgchgIAshBIACgvIAeAlIAXBuIAaAFIgvBYg");
	this.shape_153.setTransform(-211.5,39);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FF8C00").s().p("Ag2BQIgJh7IA2AOIADhRIBGAgIgaAsIgIB4IgpAZg");
	this.shape_154.setTransform(-191.5,32);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FF8C00").s().p("AgggqIgqgbIAGgPIBHAyIBIAdIghAsIhTAug");
	this.shape_155.setTransform(-199.4,29.9);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FF8C00").s().p("AgYAZIgIgsIAogtIgIgQIAigNIgaAdIATAnIAMApIgvBHIgeAHg");
	this.shape_156.setTransform(-195.6,27.2);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FF8C00").s().p("AgpDDIgKgTIhFgwIBxlgICBEQIgHB+IiBAzg");
	this.shape_157.setTransform(-200.2,45.6);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FF8C00").s().p("Ag0ApIASgnIARgIIgmg/IBjAOIgMBHIAYAXIgGAfg");
	this.shape_158.setTransform(-191.6,49);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FF8C00").s().p("AgXBJIAEgpIgYhWIAsglIAaBZIALACIAGBTIg5AJg");
	this.shape_159.setTransform(-208.9,45);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FF8C00").s().p("AgSCWIhWgmIgpgpICCj4IChDgIguBiIg0AXIheAKg");
	this.shape_160.setTransform(-197.7,48.9);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FF8C00").s().p("AgeBPIgUg9IAEhkIAzAVIAXADIAPAjIAIBWIgXAUg");
	this.shape_161.setTransform(-213.3,43.5);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FF8C00").s().p("AghAZIgcg3IAqgrIAcgIIAmgBIAQA0IgBAtIhLBEg");
	this.shape_162.setTransform(-203.5,42.7);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FF8C00").s().p("Ag3ATIAPgYIgRhTIBiACIggAkIAxAJIgZBPIgIAzg");
	this.shape_163.setTransform(-191.2,47.3);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FF8C00").s().p("AgyAoIgWgjIAQg2IBGghIALA1IAwgBIgJBwIgjABg");
	this.shape_164.setTransform(-192.9,35.3);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FF8C00").s().p("AgtAsIgNhBIASglIgIgjIBJAXIAiAqIgtBHIg5Azg");
	this.shape_165.setTransform(-184.1,37.4);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FF8C00").s().p("AgpBcIgYhTIAjg3IAGg7IBaAzIgBAmIgVBNIgsAtg");
	this.shape_166.setTransform(-202.1,47.1);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FF8C00").s().p("Ag2ApIABhSIgGgcIBrgeIgHAaIATB7IhQAyg");
	this.shape_167.setTransform(-210.6,39.3);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FF8C00").s().p("Ag2A7IAJh6IBFgoIAOAfIACBOIAPAsIgmA2g");
	this.shape_168.setTransform(-207.6,50.9);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FF8C00").s().p("Ag1BNIgQhIIAXgsIAugrIAlAUIARAqIAQBfIhSAIg");
	this.shape_169.setTransform(-202.4,40.9);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FF8C00").s().p("AgwAuIgVgvIAKgkIBagvIgBAPIAoA/IgQA8Ig7Afg");
	this.shape_170.setTransform(-200.7,43.5);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FF8C00").s().p("AAVBMIhLgWIgHg8IARgVIA0gxIAwAiIgDA7IAJA8g");
	this.shape_171.setTransform(-189.4,46.3);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FF8C00").s().p("AhAA5IgCgwIAcg9IAqgmIAsAnIASA/IgRAzIg4Acg");
	this.shape_172.setTransform(-196,38.8);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FF8C00").s().p("Ag9BCIgRhDIAhgvIARglIBeAiIANBpIhPAgg");
	this.shape_173.setTransform(-198.7,40.8);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FF8C00").s().p("Ag5A5IgHhBIAdgvIBQghIAAAsIAUAtIAABBIhHAXg");
	this.shape_174.setTransform(-211.7,42);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FF8C00").s().p("AgpCtIgtgRIg4hVIB/j/ICeD3IgYBYIhsAig");
	this.shape_175.setTransform(-199.1,48.5);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FF8C00").s().p("AhDA2IAMhFIgGgjIBUgdIAmAjIAHAiIgEA/IhEAbg");
	this.shape_176.setTransform(-186.1,40);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FF8C00").s().p("AgsBcIALhCIAGgHIAgg4IgZg4IBBgCIgcC/g");
	this.shape_177.setTransform(-198.1,29.5);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FF3300").s().p("AhuBBIAkh1IA0hAIBrA0IAaA0Ig1BUIg2Asg");
	this.shape_178.setTransform(-194.7,29.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FF3300").s().p("AhoBSIAShrIgJg0ICBgtIA7A2IAMAzIgGBhIhqArg");
	this.shape_179.setTransform(-186,31.7);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FF3300").s().p("Ag/ELIhFgbIhXiDIDFmIIDyF8IgkCIIhzAnIg1AMg");
	this.shape_180.setTransform(-199.5,35.6);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FF3300").s().p("AhYBYIgMhkIAuhIIB8g0IgBBEIAfBFIAABkIhuAkg");
	this.shape_181.setTransform(-211.8,33.6);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FF3300").s().p("AhfBmIgbhpIA0hHIAag4ICRA0IAWChIh7Awg");
	this.shape_182.setTransform(-198.8,32.9);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FF3300").s().p("AhjBYIgDhKIArheIBBg7IBEA8IAdBhIgcBPIhXArg");
	this.shape_183.setTransform(-195.8,30.5);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FF3300").s().p("AAgB2Ih1gjIgJhdIAaghIBPhKIBLAyIgFBdIAOBcg");
	this.shape_184.setTransform(-189.4,38.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FF3300").s().p("AhLBHIgghKIAPg3ICNhIIgEAXIA+BhIgZBcIhbAwg");
	this.shape_185.setTransform(-200,35.8);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#FF3300").s().p("AhTB2IgZhvIAmhEIBGhCIA4AfIAaBAIAbCUIh/AMg");
	this.shape_186.setTransform(-202.2,32.8);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FF3300").s().p("AhUBbIAOi7IBqg+IAXAwIADB4IAXBDIg7BSg");
	this.shape_187.setTransform(-207.4,43.2);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FF3300").s().p("AhTA/IABh+IgJgtIClguIgKAqIAcC+Ih6BMg");
	this.shape_188.setTransform(-210.7,32.1);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FF3300").s().p("AhACNIgjh+IA1hWIAIhbICKBOIAAA7IggB4IhDBEg");
	this.shape_189.setTransform(-202.4,38.8);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#FF3300").s().p("AhGBEIgUhkIAbg5IgLg2IBwAiIA0BCIhEBtIhYBOg");
	this.shape_190.setTransform(-183,29.9);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FF3300").s().p("AhNA8Igjg0IAZhUIBsgzIARBSIBKgDIgMCuIg4ACg");
	this.shape_191.setTransform(-192.8,27);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#FF3300").s().p("AhWAeIAXgnIgZh+ICZADIgzA3IBLANIgnB7IgMBNg");
	this.shape_192.setTransform(-190.5,40.6);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FF3300").s().p("AgyAnIgthWIBChBIAsgOIA7AAIAWBOIAABIIhzBng");
	this.shape_193.setTransform(-204,35.6);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FF3300").s().p("AgvB6IgeheIAFiaIBPAgIAmAFIAVA2IAMCEIgkAeg");
	this.shape_194.setTransform(-212.8,35.6);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FF3300").s().p("AgdDoIiEg8IhAg/IDJl+ID6FZIhICXIhRAjIiRAPg");
	this.shape_195.setTransform(-197.4,37.2);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#FF3300").s().p("AgkBxIAFhAIgkiEIBFg6IAnCIIARAFIAKCAIhYAOg");
	this.shape_196.setTransform(-208.8,36.7);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FF3300").s().p("AhQA/IAbg8IAagMIg7hiICaAXIgUBtIAnAjIgMAwg");
	this.shape_197.setTransform(-192,41);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FF3300").s().p("Ag+EsIgQgeIhshIICwogIDFGjIgKDCIhcAhIhqAvg");
	this.shape_198.setTransform(-201.3,32.5);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FF3300").s().p("AglAnIgMhGIA9hFIgLgYIA0gUIgpAsIAeA8IATBAIhJBtIgwAMg");
	this.shape_199.setTransform(-195.7,19.1);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#FF3300").s().p("AgyhCIhAgpIAJgWIBvBMIBtAtIgyBFIg+AdIhDApg");
	this.shape_200.setTransform(-198.9,22.6);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FF3300").s().p("AhVB7IgMi+IBTAWIAGh8IBrAwIgoBEIgMC6IhAAlg");
	this.shape_201.setTransform(-191.4,24.3);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FF3300").s().p("Ag0CJIgsiVIBGhkIAChIIAwA4IAiCrIAnAHIhICHg");
	this.shape_202.setTransform(-212.1,30.6);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FF3300").s().p("AgpAeIgshCIBCgVIBphXIg0BBIArAeIhBDCg");
	this.shape_203.setTransform(-191.6,38.2);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FF3300").s().p("AhXB5IAag/IAAjcICPB7IgSBoIAYBXIhkALg");
	this.shape_204.setTransform(-206.2,38.8);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FF3300").s().p("AAgB8IAxgJIg7AbgAhfAOIBghBIASgRIgqhDIB2gGIhMBJIA/BiIgyBeIhMANg");
	this.shape_205.setTransform(-198.8,21);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#FF3300").s().p("AhcA1IA+AJIAfheIgZgVIB1iGIhWCIIgGATIAuAmIgKAoIgPCOg");
	this.shape_206.setTransform(-197.6,25.3);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FF3300").s().p("AgdA7IgQgaIgvgDIBAjHIBSC4IgfBHIBGBGIghANg");
	this.shape_207.setTransform(-215.5,24.6);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FF3300").s().p("ABDBeIh9gtIBCgmIgbiGIBKA8IAzBKIAEBxgAhtAfIAzASIgGADgAg6Axg");
	this.shape_208.setTransform(-200.5,27.2);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FF3300").s().p("AgMBmIAbgWIACgWIhYArIAchpIhNiwICjChIBOAMIhqBXIgKBlg");
	this.shape_209.setTransform(-201.2,20.4);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#FF3300").s().p("AhNAdIAfhsIAEgoIBaAxIAKAIIAUC1Ihsg+IgNA/g");
	this.shape_210.setTransform(-205.8,30.3);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#FF3300").s().p("AgNBeIALgRIgfgPIAdh0IANA7IAHgjIgQgtIAbgTIgLBAIASAwIgkA7IAkASg");
	this.shape_211.setTransform(-201.8,17.4);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#FF3300").s().p("AhNA4IArhLIAPg/IBTg8IhMCIIAsguIAuBgIgWBjg");
	this.shape_212.setTransform(-212.7,20.1);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FF3300").s().p("AhAFJIBMhbIi2jqIBMlQIEJFhIg5BnIguDQg");
	this.shape_213.setTransform(-199.2,34);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#FF3300").s().p("Ag0CMIBOijIghgvIgzhcIBVBlIAHAVIgIARIAiAvIAcB+IivANg");
	this.shape_214.setTransform(-209.7,27);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#FF3300").s().p("Ag1BaIAYgdIg+gTIAehEIA4gNIApg0IAcAnIhdBxIB5AkgAghhgIgcBGIgNACgAg9gag");
	this.shape_215.setTransform(-194.6,20.5);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#FF3300").s().p("AgIA2IAOhEIAtg4IAAgRIAZg8IgIA4IgRAVIgBBnIgagCIhkB1g");
	this.shape_216.setTransform(-210.7,25.1);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FF3300").s().p("ABHCHIgFgMIiGiEIAPh2Ig8g6IBPAzICUCiIgKCeg");
	this.shape_217.setTransform(-199.4,15.8);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#FF3300").s().p("AhFCOIAThlIAJgKIAwhYIgnhXIBmgDIgsEng");
	this.shape_218.setTransform(-197.6,21.5);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FF3300").s().p("AACAgIgJgwIgRgDIAUgNIAYAUIgSAOIAXAfg");
	this.shape_219.setTransform(-199.5,-6.6);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#FF3300").s().p("Ag8AMIgPgZIAmgGIAQgfIAmgfIA6AFIhAAuIgwALIgRAdIBcBJg");
	this.shape_220.setTransform(-199.7,22.4);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FF3300").s().p("AALAwIAHgMIALg3IgxAVIAZgcIg0gOIBYgcIgkAqIArAKIgGAFIgYAvIgHAhg");
	this.shape_221.setTransform(-216.3,17.1);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#FF3300").s().p("AgOgGIgNgLIgFgYIA7AIIgOAgIAJACIgYApgAAbghIACgHIAEAIgAAbghg");
	this.shape_222.setTransform(-191.6,4.1);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#FF3300").s().p("AgfATIAfAGIgCAagAAAAZIAAgJIgRgJIgYAEIAjgkIAGAaIAAAPIApASgAAAAZgAgJgkIAYgOIgVAZg");
	this.shape_223.setTransform(-187.9,2.8);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#FF3300").s().p("AgGAaIAFgxIgVghIAWAPIgBASIARAbIgCAJIgPAsgAgIARIACAJIgBAGgAAQAEIAGglIAAAwg");
	this.shape_224.setTransform(-201.2,12.4);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FF3300").s().p("AAHAqIgFgBIgLgpIgXgYIA1gUIgUAiIAUAHIgOAtIAZABIgbACg");
	this.shape_225.setTransform(-199.1,-4.3);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#FF3300").s().p("AgRAoIAKgPIgIgOIAVgyIAJAbIgWAlIAEAJIAWgMIgCAQIgFACg");
	this.shape_226.setTransform(-204.4,13.7);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#FF3300").s().p("AgSAMIAJAEIgKAegAgJAQIAJgfIAVAgIgCANgAgJAQgAgCgTIABgOIgTAGIATgSIAAAMIAHgCIgGAUg");
	this.shape_227.setTransform(-199.6,4.3);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#FF3300").s().p("AgnAPIACgCIAdgcIASA8gAglAKIAKgWIgKAFIAWgiIgMAdIAPgHIAMgPIAqgKIg2AZIgZAdIAAADIgEABg");
	this.shape_228.setTransform(-193.4,7.2);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#FF3300").s().p("AAAgDIgRgXIAIgBIgSgQIATAQIAUgFIAAAAIAAABIAFAaIgMgJIgFALIAcAkIguALg");
	this.shape_229.setTransform(-201.2,4.2);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#FF3300").s().p("AgiAjIgOhiIBOAxIgBAVIAEAiIgcgGIAsAPIgmAOg");
	this.shape_230.setTransform(-190.1,10.7);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#FF3300").s().p("AgIgLIgPAPIgGgsIA+gHIgpAWIAHAmIgfAjgAgBANIAGgHIgEAVgAgBANg");
	this.shape_231.setTransform(-202.8,-1.8);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#FFE500").s().p("AgmAeIgEhHIA8gSIACAaIAXAaIgFAtIgkAWg");
	this.shape_232.setTransform(-191.9,47.7);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#FFE500").s().p("AgfAlIgRgpIATgfIAYgZIAoAWIAOAjIgIAgIgpAgg");
	this.shape_233.setTransform(-202,44.1);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#FFE500").s().p("AgkAoIgFgrIAGgxIArgGIAZASIAJAcIgBAxIgnAWg");
	this.shape_234.setTransform(-212.1,47.8);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#FFE500").s().p("AgaB0IgtgRIgZguIBli5IBcCvIgbBBIglARIg0AIg");
	this.shape_235.setTransform(-197.7,51.8);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#FFE500").s().p("AgbAuIgJhSIAYgcIAoAuIAGAPIADAxIgoATg");
	this.shape_236.setTransform(-208.3,49.2);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#FFE500").s().p("AgnAmIAGgkIAKgRIgCgsIA7AbIgBAmIAHAbIgaAag");
	this.shape_237.setTransform(-191.3,52.4);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#FFE500").s().p("AgkCJIgyg8IBWjjIBXDDIgQBIIghAUIgsAOg");
	this.shape_238.setTransform(-198.7,50.5);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#FFE500").s().p("AgfA4IABhPIAzgmIgFAQIAMAgIAEAlIgjAmg");
	this.shape_239.setTransform(-196.6,30.9);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#FFE500").s().p("AgpA5IAJhDIgQgWIATgbIBNA6IgSApIgdATg");
	this.shape_240.setTransform(-200,31.8);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#FFE500").s().p("AgnA3IgChHIATgGIAVgwIArAeIgJAaIgDBIIgmAOg");
	this.shape_241.setTransform(-191.8,35);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#FFE500").s().p("AgdA4IgPg5IAcgoIAKgiIAgAcIAPA6IAEAXIgmAqg");
	this.shape_242.setTransform(-209.9,43.3);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#FFE500").s().p("AgaAZIgMgjIBCg3IgDAgIAOAYIgPAxIgXAag");
	this.shape_243.setTransform(-190.2,48.6);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#FFE500").s().p("AgpA1IAVh8IA7AxIADBOIgpAQg");
	this.shape_244.setTransform(-205.4,52);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#FFE500").s().p("AgWA5IgSgxIA1gyIgCgEIAXgPIgVATIAcAxIgQAzIgBAEg");
	this.shape_245.setTransform(-200.5,33.2);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#FFE500").s().p("AgjAgIAPgLIAPgsIApg1IgYAzIAWAdIgCAcIgUAtg");
	this.shape_246.setTransform(-198.1,36.9);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#FFE500").s().p("AgSAfIgKgUIgLgMIAnhGIAhA/IgKAgIAQAjIgWANg");
	this.shape_247.setTransform(-213.5,39.1);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#FFE500").s().p("AguAaIAMgHIAagaIAAguIAkAbIASAhIABAuIghABg");
	this.shape_248.setTransform(-199.6,40.8);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#FFE500").s().p("AgPAhIgZAAIAKgrIgNhCIA/A9IAYAOIgpAvIgEAgg");
	this.shape_249.setTransform(-199.2,34);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#FFE500").s().p("AgGAoIgTAMIgLgoIAKgqIAKgaIArAaIAHAOIADBJg");
	this.shape_250.setTransform(-205,40.6);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#FFE500").s().p("AACAxIAAAAIgZgPIAJg4IAGASIARgxIgEASIATAoIgWAsIAIAFg");
	this.shape_251.setTransform(-202.1,34);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#FFE500").s().p("AgbAaIAHghIAKgVIAdgYIgNAqIAPgDIAHAkIgQAeg");
	this.shape_252.setTransform(-209.8,30);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#FFE500").s().p("AgDBGIgTgTIgagnIAihkIA/BoIgdBIIgeABg");
	this.shape_253.setTransform(-198.3,48.3);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#FFE500").s().p("AgUAlIAQgtIABgIIgNgaIAhAwIAEAgIgmAFg");
	this.shape_254.setTransform(-207.1,38.8);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#FFE500").s().p("AgOALIAFgRIATgJIAFAJIgPAWgAgHgNIgCAHIgCAAgAgJgGg");
	this.shape_255.setTransform(-197.2,27.4);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#FFE500").s().p("AgEgBIAJgRIADgNIAEAPIAAAWIgEAFIgTAVg");
	this.shape_256.setTransform(-207.9,36.4);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#FFE500").s().p("AADANIgDgBIgHgMIABgJIgBgFIAHAFIAIAMIAAAMg");
	this.shape_257.setTransform(-196.7,22.2);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#FFE500").s().p("AgFAGIAAgDIADgHIgBgIIAJABIgDAXIgGABg");
	this.shape_258.setTransform(-198.1,27.8);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#FF8C00").s().p("AgvAoIgRiFIBlA2IARAkIAEA1IgiAFIApAaIg8ANg");
	this.shape_259.setTransform(-191.5,36.4);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#FF8C00").s().p("AgGgQIAwBbIhTAKgAAJglIAWgLIAEAkgAgMgbIAMgFIgGAQgAACgsIAHAHIgJAFgAgmhUIAmAmIgIAHgAAAguIAEgEIgCAGgAAAgug");
	this.shape_260.setTransform(-199.3,31.4);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#FF8C00").s().p("AhGAoIAWhEIgMAGIAYgrIgMAlIA8ggIACgCIA5gcIg7AeIg1BRIAuggIAQBmg");
	this.shape_261.setTransform(-192.6,33.1);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#FF8C00").s().p("AgnAtIAEACIgQA+gAgjAvIAdhzIgwADIAzgrIAHBAIAyBNIgJAqgAgjAvg");
	this.shape_262.setTransform(-197.5,32.3);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#FF8C00").s().p("AgvBSIAjhDIgCgEIAWhtIAGA/IgaAyIAXAzIAlgIIgPAqg");
	this.shape_263.setTransform(-203,36.7);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#FF8C00").s().p("AAdBoIABgBIgkgFIgYheIgjg4IBzg3IgbBRIAnAXIggBqIAkAGg");
	this.shape_264.setTransform(-197,20.6);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#FF8C00").s().p("AgjAqIgFAIIAPh9IgJgiIBAB3IgDAZIgpBLgAAeAKIALg/IgJBBgAAeAKg");
	this.shape_265.setTransform(-199.8,36.8);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#FF8C00").s().p("AgmAtIAKACIgEgqIAWAEIAxAsIhDgGIABAWgAggAFIgEgBIAEgGIgEgnIAkgaIggBBIAAAHg");
	this.shape_266.setTransform(-188,24.7);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#FF8C00").s().p("AgmgGIgOgeIAJguIBgAVIgWBOIAAAJIgwA5g");
	this.shape_267.setTransform(-190.1,29.3);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#FF8C00").s().p("AAJgQIg2AKIApg0Ig7gUIBbgYIggAsIBEAWIg1CLg");
	this.shape_268.setTransform(-214.7,41.3);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#FF8C00").s().p("Ag2AWIgIgiIA+gcIANgKIATgZIAfgLIgyAkIgIAMIgVA7IAtBCg");
	this.shape_269.setTransform(-199.9,41.4);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#FF8C00").s().p("AgPBIIgSh1IAIgDIgWgUIAzgKIAsAyIgdArIASBAg");
	this.shape_270.setTransform(-199.1,20.3);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#FF8C00").s().p("AgpAmIgBgWIAXg3IgCg3IBAAIIgUCsIg0AJg");
	this.shape_271.setTransform(-197.2,33.5);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#FF8C00").s().p("AAFBUIg/hWIAOhCIgNgqIAyAkIBCBeIgDBbg");
	this.shape_272.setTransform(-196.6,27.4);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#FF8C00").s().p("AgZAyIAIg5IAkg9IAKguIANA0IgBBVIgLAQIhHBMg");
	this.shape_273.setTransform(-208.5,40.6);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#FF8C00").s().p("Ag2AdIAUhBIgHADIANgYIgGAVIBFgcIAUAeIg3BRIAuASg");
	this.shape_274.setTransform(-196.6,32.6);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#FF8C00").s().p("AgyBYIAphsIABgTIgeg/IBRBxIAIBRIhcAKg");
	this.shape_275.setTransform(-207.5,40.4);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#FF8C00").s().p("AgICpIgugtIg/hfIBRjzICaD8IgiBIIgiBmIhMADg");
	this.shape_276.setTransform(-198.5,46.2);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#FF8C00").s().p("AgyAwIAOg8IAQgmIA2gtIgYBNIAcgHIANBEIgcA1g");
	this.shape_277.setTransform(-210.1,30.5);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#FF8C00").s().p("AADBZIAAgBIgtgaIAQhnIAKAhIAhhYIgJAgIAjBJIgoBPIARAJg");
	this.shape_278.setTransform(-201.9,34.6);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#FF8C00").s().p("AgKA7IgbASIgQg7IAPg+IAOglIA/AnIAKASIAFBqg");
	this.shape_279.setTransform(-204.8,39.6);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#FF8C00").s().p("AgWAwIglgBIAQg9IgThhIBcBZIAiAUIg8BEIgHAug");
	this.shape_280.setTransform(-199,32.4);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#FF8C00").s().p("AhDAmIARgJIAmgoIAAhBIA1AmIAZAwIACBCIgvABg");
	this.shape_281.setTransform(-199.6,39.2);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#FF8C00").s().p("AgbAtIgOgdIgPgSIA3hmIAxBcIgOAwIAXAyIghATg");
	this.shape_282.setTransform(-213.8,37.4);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#FF8C00").s().p("AgzAvIAVgRIAVhAIA9hNIgjBKIAgAqIgCAqIgdBBg");
	this.shape_283.setTransform(-198.2,35.7);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#FF8C00").s().p("AggBSIgZhGIBLhIIgDgHIAjgVIggAcIApBHIgXBJIgBAFg");
	this.shape_284.setTransform(-200.6,32);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#FF8C00").s().p("Ag8BLIAeiyIBVBHIgBA4IAHA6Ig9AWg");
	this.shape_285.setTransform(-205.5,50.6);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#FF8C00").s().p("AgmAjIgRgyIBghPIgFAuIAUAiIgWBHIgiAmg");
	this.shape_286.setTransform(-190.3,47.6);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#FF8C00").s().p("AgqBSIgVhTIAng7IAPgxIAvApIAaB0Ig3A+g");
	this.shape_287.setTransform(-210.2,42);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#FF8C00").s().p("Ag4BPIgEhnIAbgIIAfhGIA/AsIgOAmIgEBpIg3ASg");
	this.shape_288.setTransform(-191.7,33.8);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#FF8C00").s().p("Ag6BSIALhiIgWgfIAbglIBwBSIgaA9IgrAbg");
	this.shape_289.setTransform(-199.8,30.7);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#FF8C00").s().p("AguBQIAChxIBKg3IgHAWIARAvIAHA2IgzA2g");
	this.shape_290.setTransform(-196.6,29.6);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#FF8C00").s().p("Ag0DGIhJhXIB9lIIB+EaIgYBnIguAeIhBAUg");
	this.shape_291.setTransform(-199.1,46.5);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#FF8C00").s().p("Ag6A4IAJg2IAPgYIgDg/IBWAoIgCA2IALAoIglAkg");
	this.shape_292.setTransform(-191.2,51.2);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#FF8C00").s().p("AgnBDIgCg4IgMhAIAigpIA7BEIAJAVIAFBIIg6Acg");
	this.shape_293.setTransform(-208.3,48);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#FF8C00").s().p("AgmCnIhAgWIglhEICSkLICFD9IgmBdIg2AZIhLAKg");
	this.shape_294.setTransform(-197.6,48.1);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#FF8C00").s().p("Ag0A6IgIg/IAKhGIA+gKIAlAbIAMAoIgBBJIg5Afg");
	this.shape_295.setTransform(-211.8,46.9);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#FF8C00").s().p("AgtA2IgYg7IAbguIAggjIA9AeIATA0IgKAvIg9Asg");
	this.shape_296.setTransform(-202,43);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#FF8C00").s().p("Ag3ArIgGhoIBZgZIAAAmIAiAmIgHBCIgzAfg");
	this.shape_297.setTransform(-191.7,46.6);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#FF8C00").s().p("Ag5AzIgPgwIAVgtIA+gqIAZAsIAlAaIgJBQIg0ASg");
	this.shape_298.setTransform(-192.7,35.8);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#FF8C00").s().p("AgNAbIACAKIgjA7gAgLAlIAGgMIgGASgAgLAlgAgNAbIgDgWIASgLIgPAhgAgagzIAKA4IgFADgAgagzIgBgYIBKgUIhJAsg");
	this.shape_299.setTransform(-200.4,22.3);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#FF3300").s().p("AhUBrIgOhlIAVhFIAzhGIBtBGIAQA5IgZBWIhXA2g");
	this.shape_300.setTransform(-201.2,38.3);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#FF3300").s().p("AhZBQIgXhKIAhhHIBgg/IAmBDIA5AmIgNB9IhSAbg");
	this.shape_301.setTransform(-192.6,27);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#FF3300").s().p("AhVBDIgJihICIgnIABA7IA0A7IgLBkIhPAxg");
	this.shape_302.setTransform(-191.3,38.4);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#FF3300").s().p("AhGBTIglhcIAphHIAzg2IBeAvIAdBPIgQBJIheBFg");
	this.shape_303.setTransform(-202.1,34.9);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#FF3300").s().p("AhQBZIgNhhIAPhsIBggPIA4ApIAUA9IgCBwIhYAxg");
	this.shape_304.setTransform(-211.3,39.3);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#FF3300").s().p("Ag7ECIhjgjIg4hoIDgmdIDNGGIg6CRIhUAlIhzARg");
	this.shape_305.setTransform(-197.3,35.5);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#FF3300").s().p("Ag+BnIgBhWIgThjIA1g/IBbBqIANAfIAIBvIhaAqg");
	this.shape_306.setTransform(-208.3,39.8);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#FF3300").s().p("AhZBVIANhQIAXgmIgFhiICGA9IgFBUIATA+Ig7A4g");
	this.shape_307.setTransform(-191.2,42.8);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#FF3300").s().p("AhREvIhviEIDAn5IDBGyIgjCfIhHAsIhlAgg");
	this.shape_308.setTransform(-199.7,33.1);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#FF3300").s().p("AhHB7IAHhgIgDhOIBxhWIgLAjIAaBKIALBSIhPBUg");
	this.shape_309.setTransform(-196.5,21.2);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#FF3300").s().p("AhaB/IASiXIgkgxIAsg6ICtB/IgpBfIhBApg");
	this.shape_310.setTransform(-199.3,22.3);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#FF3300").s().p("AhYB5IgFieIAqgNIAvhsIBiBFIgWA5IgFChIhWAdg");
	this.shape_311.setTransform(-191.5,25.5);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#FF3300").s().p("AhAB8Igih/IA+haIAVhLIBKBAIAoCzIhTBeg");
	this.shape_312.setTransform(-210.8,33.4);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#FF3300").s().p("Ag7A3IgahPICUh6IgHBHIAeA1IghBtIgzA8g");
	this.shape_313.setTransform(-190.5,39.6);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#FF3300").s().p("AhcB0IAJhTIAUhMIAPh0ICEBuIgBBWIAKBYIhdAjg");
	this.shape_314.setTransform(-205.7,42);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#FF3300").s().p("AgxB+IgnhsIB0hwIgFgJIA1giIgwArIA+BuIgkB6g");
	this.shape_315.setTransform(-200.8,23.7);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#FF3300").s().p("AhOBIIAggaIAghjIBdh2Ig1ByIAyBBIgFBBIgsBjg");
	this.shape_316.setTransform(-198.4,27.5);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#FF3300").s().p("AgqBGIgVguIgYgcIBVicIBMCOIgWBJIAkBMIgzAeg");
	this.shape_317.setTransform(-214.3,28.3);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#FF3300").s().p("AhnA6IAagOIA6g9IABhmIBRA+IAnBJIACBmIhIACg");
	this.shape_318.setTransform(-199.7,30.1);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#FF3300").s().p("AgjBKIg4gCIAWhfIgbiUICNCHIA1AhIhdBpIgKBGg");
	this.shape_319.setTransform(-198.7,23.5);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#FF3300").s().p("AgQBbIgqAbIgXhaIAVhgIAWg5IBgA7IARAcIAICkg");
	this.shape_320.setTransform(-204.5,31.7);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#FF3300").s().p("AAECJIABgCIhGgpIAYieIAPAzIA0iGIgNAvIA1ByIg9B5IAYANg");
	this.shape_321.setTransform(-201.8,26.4);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#FF3300").s().p("AhNBJIAVhcIAZg6IBThGIgkB3IArgKIATBoIgrBSg");
	this.shape_322.setTransform(-210.4,22.2);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#FF3300").s().p("AgOEDIhGhGIhgiRIB8l2IDtGDIg1BwIg0CdIh0AFg");
	this.shape_323.setTransform(-198.7,34);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#FF3300").s().p("AhOCHIA/imIADgeIgvhgIB7CvIAPB7IiPARg");
	this.shape_324.setTransform(-207.7,31.5);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#FF3300").s().p("AhUAtIAfhlIBsgrIAeAvIhUB9IBGAbgAgshXIgJAfIgMAFgAg1g4g");
	this.shape_325.setTransform(-196.1,25);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#FF3300").s().p("AgnBNIANhYIA3hfIAQhGIATBRIAACCIgSAaIhtB0g");
	this.shape_326.setTransform(-209,32.5);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#FF3300").s().p("AAHCBIhhiEIAWhmIgVhAIBNA2IBnCRIgFCMg");
	this.shape_327.setTransform(-196.5,18.8);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#FF3300").s().p("AhBA7IAAgjIAihUIgChVIBjANIgeEHIhSAPg");
	this.shape_328.setTransform(-196.6,25.2);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#FF3300").s().p("AgYBuIgbi0IANgEIgigfIBOgQIBDBNIgsBDIAbBjg");
	this.shape_329.setTransform(-199.6,12.3);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#FF3300").s().p("AhUAiIgNg1IBggrIAYgSIAbgkIAvgRIhKA1IgQAUIghBcIBGBmg");
	this.shape_330.setTransform(-199.1,33.3);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#FF3300").s().p("AAOgZIhTAPIA9hQIhZgfICMgkIgzBDIBqAkIhQDUg");
	this.shape_331.setTransform(-216,34.9);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#FF3300").s().p("Ag/gLIgWgsIAOhIICUAhIgiB4IABAPIhMBXgABNheIAAgBIAIACgABNheg");
	this.shape_332.setTransform(-189.6,21.6);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#FF3300").s().p("Ag7BFIAOACIgEhAIAhAHIBMBEIhpgLIACAigAg3AGIAEgIIgEg/IA3gnIgzBmIACAJg");
	this.shape_333.setTransform(-186.9,15.8);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#FF3300").s().p("Ag2BBIgIAMIAYjBIgOg0IBjC3IgGAnIhABzgAAvAPIAQhgIgNBjgAAvAPg");
	this.shape_334.setTransform(-200,27.9);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#FF3300").s().p("AAtChIAAgDIg3gIIgliQIg1hXICvhVIgpB9IA+AkIgzCjIA4AIg");
	this.shape_335.setTransform(-196.2,11.5);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#FF3300").s().p("AhJB9IA2hlIgEgIIAkioIAJBgIgpBQIAkBOIA5gNIgXBAg");
	this.shape_336.setTransform(-202.6,25.4);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#FF3300").s().p("Ag8BGIAGACIgXBfgAg2BIIAsixIhJAFIBMhCIANBhIBOB4IgOBAgAg2BIg");
	this.shape_337.setTransform(-197.3,24.7);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#FF3300").s().p("AhrA9IAhhoIgSAJIAjhCIgRA5IBegyIABgDIBXgsIhYAvIhVB8IBJgwIAYCeg");
	this.shape_338.setTransform(-191.2,26.3);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#FF3300").s().p("AgKgZIBKCNIh/APgAAOg6IAggPIAHA1gAgUgqIASgIIgIAZgAAChFIAMALIgQAIgAAOg6gAg8iCIA8A7IgOAMgAAAhHIAFgGIgDAIg");
	this.shape_339.setTransform(-198.9,24.7);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#FF3300").s().p("AgTBDIACgsIgTABIAJhbIA1BEIggApIAhgBIAKAbg");
	this.shape_340.setTransform(-199.3,5.4);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#FF3300").s().p("AhIA+IgajNICaBSIAbA4IAHBTIg2AGIBAApIhbATg");
	this.shape_341.setTransform(-191.4,28.9);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#FF3300").s().p("AgUAqIABAOIg0BagAgTA4IAKgSIgIAcgAgaAIIAdgRIgXAzgAgrh0IBzgdIhwBCIAOBXIgJAEgAgaAIg");
	this.shape_342.setTransform(-199.6,14.5);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#FF3300").s().p("AABAMIAbAHIgVAmgAgbAFIALgDIgGgdIAPgdIATAuIgMANIABAJg");
	this.shape_343.setTransform(-192.5,2.4);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#FF3300").s().p("AghgmIAbgKIAdgYIgJArIgHAPIgVAZIAwAwIg8AOg");
	this.shape_344.setTransform(-189.8,-6.5);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#FF3300").s().p("AgJgIIgRgDIANgQIgBgCIACABIAVgdIASBKIAAAGIgaAjg");
	this.shape_345.setTransform(-210.2,10.2);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#FF3300").s().p("AAPA0IAGAAIAeASgAAVA0IgdgRIgOg6IAuBLgAgWgXIgcguIAEAGIArANIgTAbg");
	this.shape_346.setTransform(-196.5,9.7);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#FFE500").s().p("AhLBoIgGhiIA3iWIBhBXIALBCIgBBPIhGA5g");
	this.shape_347.setTransform(-211.5,22.5);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#FFE500").s().p("AgyBhIgahZIArhOIBOhJIAEA9IAcBHIgKBtIgtAug");
	this.shape_348.setTransform(-204.4,-15.3);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#FFE500").s().p("AhHBcIAHhAIAWhRIBVhhIADBZIAaBHIAABZIg9A1g");
	this.shape_349.setTransform(-197.1,-9.7);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#FFE500").s().p("AgxBRIgWhFIgCg1IBVhqIA+BdIgNBLIAGBQIg5Aug");
	this.shape_350.setTransform(-225.5,-3.8);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#FFE500").s().p("AhTBFIAGg0IAnhPIAWhAIBLA6IAYBJIABBYIhTAig");
	this.shape_351.setTransform(-200,0.3);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#FFE500").s().p("Ag2BYIgYgxIAajGIBqBrIAZA0IhOCgg");
	this.shape_352.setTransform(-199.7,-15.5);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#FFE500").s().p("Ag9ByIgOhZIAOhQIAfhJIBWBEIAUAvIgFCOg");
	this.shape_353.setTransform(-209.2,-2.6);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#FFE500").s().p("Ag/BbIADiEIAJAGIA9hsIANBAIApBOIgpB8IgPAVg");
	this.shape_354.setTransform(-206,-12.5);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#FFE500").s().p("AhDBZIAChtIAcgzIBHhNIABBiIAhAaIgDBuIgzA/g");
	this.shape_355.setTransform(-217.6,-21.9);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#FFE500").s().p("AgeERIhAg6IhDiEICNmUIC2GfIhbDXIhZANg");
	this.shape_356.setTransform(-198.4,14);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#FFE500").s().p("AhHB/IAri5IgKhZIBFBXIAoBJIABBzIhfAUg");
	this.shape_357.setTransform(-215.4,4.7);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#FFE500").s().p("AhLA6IASh6IgDgCIA9guIAwASIAbA3IgvBoIAEAwg");
	this.shape_358.setTransform(-195.8,-16.4);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#FFE500").s().p("Ag0BUIADhYIAihbIAPhEIA2BVIgDCfIhRBTg");
	this.shape_359.setTransform(-214.8,3.3);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#FFE500").s().p("AAQCVIgjgSIg4iAIAhiXIA/A5IA3B8IAAB0g");
	this.shape_360.setTransform(-194.6,-25.9);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#FFE500").s().p("Ag2BLIgIg6IAsihIBRAbIgBCOIgOBTIg7Alg");
	this.shape_361.setTransform(-197.6,-11.8);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#FFE500").s().p("AguBtIgNifIANgWIABg1IBFAZIAkBLIgqCXg");
	this.shape_362.setTransform(-198.3,-40.1);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#FFE500").s().p("Ag/A4IgEhEIA1g6IBShFIgIAsIgYA9IgPBXIAFBXg");
	this.shape_363.setTransform(-203,5.3);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#FFE500").s().p("AgbAAIgrgbIAyhZIgvgYIA+gCIgPAaIBbAuIgCAkIgbBzIgfA+g");
	this.shape_364.setTransform(-224.2,2.6);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#FFE500").s().p("AhDg1IAhhFIBmAoIgZCOIgSAUIg/Aqg");
	this.shape_365.setTransform(-181.4,-22.2);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#FFE500").s().p("AgtADIAEgxIAqgoIgGBOIAXARIAcBBIhCAHIgMAGg");
	this.shape_366.setTransform(-184.4,-31.4);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#FFE500").s().p("AgoA9IgLgSIASh8IAVgtIAxB2IAPglIgMBiIg0BKg");
	this.shape_367.setTransform(-200.5,-6.7);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#FFE500").s().p("AgUBQIgOhLIgNgxIBLg0IgEBGIAYAaIgVBUIAHANg");
	this.shape_368.setTransform(-196.1,-45.7);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#FFE500").s().p("AglA1IAhhcIAGgzIACBSIATAwIAPAMIgSAng");
	this.shape_369.setTransform(-207.6,-3.9);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#FFE500").s().p("AgMgbIgQgIIAbgZIAJAkIAVAnIgGAfIgmgHIgLAWg");
	this.shape_370.setTransform(-195.4,-25.8);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#FFE500").s().p("AgeAeIAJg4IgBAKIA1gnIgQAWIgQApIAOgCIgBAyg");
	this.shape_371.setTransform(-191.7,-28.4);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#FFE500").s().p("AgKAZIAIgiIgBAAIgCgQIANAUIgHAFIAHAagAAIgFIADgDIgBAEgAAIgFg");
	this.shape_372.setTransform(-199.4,-34.4);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#FFE500").s().p("AgJAYIACgSIgDgEIAHgdIANAXIgHAPIAIAGIgDALg");
	this.shape_373.setTransform(-201,-42.2);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#FF8C00").s().p("Ag1BlIgbjIIgZgHIAVgWIgBgEIADABICBiTIA7FWIgCA1IhoCig");
	this.shape_374.setTransform(-220.3,-13);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#FF8C00").s().p("AhahjICaiDIAKCGIgQBAIgzBlIBUCSIihAQg");
	this.shape_375.setTransform(-186.4,-54.4);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#FF8C00").s().p("AAyB1IA7ATIgrCRgAhsA+IAggvIgEiaIBEiNIBcDSIgqBUIAMBng");
	this.shape_376.setTransform(-190.2,-33.7);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#FF8C00").s().p("AgjBUIgGgPIgSi0IB3hgIg8A5IADCmIAlALIhdC1g");
	this.shape_377.setTransform(-201.7,-41);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#FF8C00").s().p("AhXA0IgXjsICaA9IA8BPIAHB5IgyApIAdA+IhrAFg");
	this.shape_378.setTransform(-188,-4);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#FF8C00").s().p("Ag/CuIADiJIgUghIA5jIIBfCfIgyB0IA7AqIgQBMg");
	this.shape_379.setTransform(-199,-32.5);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#FF8C00").s().p("AhOCyIA6j8IgEgHIgQhlIBnCBIgvAwIAwC8gAA/g1IAQgPIgFAdgAA/g1g");
	this.shape_380.setTransform(-199.6,-18);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#FF8C00").s().p("AhwBtIAeivIDDiIIg9BRIg+CSIA6gEIgHC2gAhMhlIgGAjIgDACgAhShCg");
	this.shape_381.setTransform(-190.2,-16.6);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#FF8C00").s().p("AgwhmIg5gdIBhhZIAlCDIBNCMIgUByIiRgcIgkBUg");
	this.shape_382.setTransform(-194.7,-16.1);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#FF8C00").s().p("AhdCCIBUjgIAMh8IAGDFIAuB0IAnAgIgtBcg");
	this.shape_383.setTransform(-207.1,-4);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#FF8C00").s().p("AgwDCIghi2Igih1IC5h9IgLCmIA5BBIg0DLIARAbg");
	this.shape_384.setTransform(-195,-42.4);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#FF8C00").s().p("AhJBvIgUgiIAfjgIAohSIBZDWIAchEIgYCzIhdCGg");
	this.shape_385.setTransform(-200.5,-6.5);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#FF8C00").s().p("AhSAHIAIhZIBLhKIgLCMIAqAiIAzB1Ih3AMIgZAKg");
	this.shape_386.setTransform(-183.3,-31.6);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#FF8C00").s().p("AhhhOIAvhiICUA3IgHAcIgcCyIgaAeIheA+g");
	this.shape_387.setTransform(-181.1,-24.5);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#FF8C00").s().p("AgnAAIg/gmIBKiCIhEgiIBZgEIgVAmICDBCIgDAzIgoCoIgrBag");
	this.shape_388.setTransform(-224.9,2);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#FF8C00").s().p("AhcBPIgFhgIBLhVIB4hkIgNBAIghBYIgVB+IAIB/g");
	this.shape_389.setTransform(-202.8,2.8);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#FF8C00").s().p("AhDCcIgSjkIASghIADhLIBhAiIA1BtIg8Dag");
	this.shape_390.setTransform(-198.3,-42.4);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#FF8C00").s().p("AhOBtIgMhWIA/jnIB3AoIgFDOIgSB4IhWAzg");
	this.shape_391.setTransform(-197.3,-14.4);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#FF8C00").s().p("AAYDYIg0gaIhRi4IAyjdIBbBSIBNC0IABCpg");
	this.shape_392.setTransform(-194.7,-29.3);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#FF8C00").s().p("AhOB5IAGh+IAwiFIAXhiIBOB7IACCXIgHBOIh0B5g");
	this.shape_393.setTransform(-214.8,0.6);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#FF8C00").s().p("AhtBUIAaixIgDgCIBYhEIBEAbIAoBRIhECVIAHBGg");
	this.shape_394.setTransform(-195.5,-18.1);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#FF8C00").s().p("AhoC3IBAkLIgPiBIBjB+IA6BqIADCoIiLAbg");
	this.shape_395.setTransform(-215.6,1.5);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#FF8C00").s().p("AgtGLIhbhVIhgi+IDKpHIEIJWIg+CoIhHCRIh+AQg");
	this.shape_396.setTransform(-198.6,5.9);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#FF8C00").s().p("AhhCBIAAidIAshMIBlhuIABCOIAxAmIgECgIhMBZg");
	this.shape_397.setTransform(-217.8,-24.6);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#FF8C00").s().p("AheCEIAJi/IALAIIBZicIARBcIA+ByIg9CzIgWAeg");
	this.shape_398.setTransform(-205.5,-15.2);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#FF8C00").s().p("AgHCyIhSgPIgTiAIAThyIAthrIB+BjIAbBFIgFDNg");
	this.shape_399.setTransform(-209.1,-5.6);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#FF8C00").s().p("AhQCAIghhFIAnkhICYCcIAkBKIhwDng");
	this.shape_400.setTransform(-199.4,-18.9);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#FF8C00").s().p("Ah4BjIALhKIA4h0IAehcIBtBWIAhBmIACB/Ih4A0g");
	this.shape_401.setTransform(-200.1,-2.6);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#FF8C00").s().p("AhHB0IgghhIgDhOIB8iZIBZCFIgTBtIAKB1IhSBCg");
	this.shape_402.setTransform(-225.8,-7);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#FF8C00").s().p("AhnCFIAKhdIAgh2IB8iNIACCBIAnBoIAAB/IhXBPg");
	this.shape_403.setTransform(-197.2,-12.6);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#FF8C00").s().p("AhJCLIglh/IA+hzIBxhpIAGBZIAoBmIgOCfIhCBDg");
	this.shape_404.setTransform(-204.7,-17.9);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#FF8C00").s().p("AhvCWIgFiNIBNjZICNB+IAQBfIgCB0IhkBQg");
	this.shape_405.setTransform(-211.7,19.2);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#FF8C00").s().p("AhbBuIgNh7IALg6ICLiAIAmBoIAVBnIghCNIhUAzg");
	this.shape_406.setTransform(-182.1,9.9);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#FF8C00").s().p("AgsBfIgfiZIAghJIgSgmIAYAXIgGAPIBsDiIgPAoIAhA5gAhSjAIANAFIAIASg");
	this.shape_407.setTransform(-192.6,-24.6);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#FF3300").s().p("AiZDoIANlXICNitICZCsIgMBdIACEGIixAqg");
	this.shape_408.setTransform(-186.6,-42.7);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#FF3300").s().p("AiOCoIgSi8IAShaIDTjEIA7ChIAhCfIgyDZIiDBMg");
	this.shape_409.setTransform(-181.8,-9.7);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#FF3300").s().p("AiqDmIgKjZIBAiVIA4i5IDaDBIAXCTIgDCyIiaB9g");
	this.shape_410.setTransform(-212.1,-0.6);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#FF3300").s().p("AhxDWIg5jFIBfixICwifIAJCJIA9CcIgWDzIhmBog");
	this.shape_411.setTransform(-205.3,-36.3);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#FF3300").s().p("AieDMIAOiPIAwi1IDBjZIAEDIIA6CfIAADFIiFB3g");
	this.shape_412.setTransform(-197.4,-31.6);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#FF3300").s().p("AhuCzIgxiVIgFh6IDAjsICJDOIgeCoIAPC0Ih+Bng");
	this.shape_413.setTransform(-226.4,-26.4);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#FF3300").s().p("Ai6CYIAShwIBTizIAxiPICnCEIAzCgIAFDDIi6BOg");
	this.shape_414.setTransform(-200,-21.6);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#FF3300").s().p("Ah7DFIg0hsIAji3IAZkEIDrDuIA4BzIiuFkg");
	this.shape_415.setTransform(-198.8,-38.4);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#FF3300").s().p("AgMETIh+gXIgcjFIAdiwIBGilIDBCZIApBoIgJE8g");
	this.shape_416.setTransform(-208.9,-24.7);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#FF3300").s().p("AiQDJIALklIASAOICMjyIAZCPIBeCsIhbEXIgkAvg");
	this.shape_417.setTransform(-204.7,-33.7);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#FF3300").s().p("AiWDGIAAjxIBEh0ICbirIABDZIBNA7IgHD2IhzCLg");
	this.shape_418.setTransform(-218.3,-43.1);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#FF3300").s().p("AhEJfIiPiCIiUkmIE7uAIGUOYIheEDIhsDeIjEAag");
	this.shape_419.setTransform(-198.9,-22.3);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#FF3300").s().p("AihEZIBjmdIgXjDICaDAIBZCjIAEECIjXAqg");
	this.shape_420.setTransform(-216,-17.9);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#FF3300").s().p("AioCCIAnkRIgFgEICKhnIBpAoIA8B7IhnDnIAKBrg");
	this.shape_421.setTransform(-194.8,-34.8);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#FF3300").s().p("Ah3C7IAJjGIBKjKIAjiXIB5C9IgIFiIi1C6g");
	this.shape_422.setTransform(-214.9,-17.9);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#FF3300").s().p("AAjFLIhPgoIh8kdIAyi3IAZiZICOB7IB2EXIACEDg");
	this.shape_423.setTransform(-194.8,-48.9);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#FF3300").s().p("Ah5CnIgSiDIApizIA4ixIC2A9IgFE9IgdC5IiFBOg");
	this.shape_424.setTransform(-197.1,-32.9);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#FF3300").s().p("AhnDxIgdlgIAbgzIAFh0ICXA1IBSCoIhdFQg");
	this.shape_425.setTransform(-198.3,-60.6);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#FF3300").s().p("AiNB6IgJiVIB0iCIC5ibIgUBjIgyCIIghDDIALDDg");
	this.shape_426.setTransform(-202.6,-15.5);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#FF3300").s().p("Ag9AAIhgg8IBxjHIhog1ICIgFIggA6IDKBlIgEBRIg9EAIhDCLg");
	this.shape_427.setTransform(-226.1,-12.9);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#FF3300").s().p("AiWh3IBKiZIDjBWIg2E9IgpAtIiPBhg");
	this.shape_428.setTransform(-180.9,-42.4);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#FF3300").s().p("Ah/AKIANiLIB1hvIgTDXIBCA0IBOC1Ii4ASIgkAPg");
	this.shape_429.setTransform(-182.1,-51.7);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#FF3300").s().p("AhxCqIgfgzIAylZIA7h/ICJFJIArhpIgjEWIiRDNg");
	this.shape_430.setTransform(-200.7,-26.3);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#FF3300").s().p("AhLEsIgxkZIg1i1IEcjCIgRECIBYBlIhPE2IAaArg");
	this.shape_431.setTransform(-194,-62.4);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#FF3300").s().p("AiPDIIB/laIAVi+IAIEvIBGCzIA9AxIhGCOg");
	this.shape_432.setTransform(-206.7,-27.2);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#FF3300").s().p("AhJidIhZgsICWiKIA5DIIB2DbIggCvIjegtIg4CCg");
	this.shape_433.setTransform(-194.2,-33.9);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#FF3300").s().p("AitCnIAvkMIEsjTIhdB9IhgDiIBZgGIgMEYgAh1ibIgJA2IgEADgAh+hlg");
	this.shape_434.setTransform(-189.1,-33);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#FF3300").s().p("Ah5ESIBZmEIgFgKIgZidICgDIIhIBLIBJEggABihRIAYgZIgHAugABihRg");
	this.shape_435.setTransform(-199.8,-34.3);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#FF3300").s().p("AhiELIAFjQIgfg0IBYk2ICTD4IhOCwIBcBCIgZB1g");
	this.shape_436.setTransform(-197.8,-52.8);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#FF3300").s().p("AiGBQIgjlsIDuBdIBcB7IAJC6IhMA9IAuBhIinAJg");
	this.shape_437.setTransform(-188.1,-20.8);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#FF3300").s().p("Ag3CDIgJgYIgckUIC5iWIhdBZIAFD/IA5ASIiREVg");
	this.shape_438.setTransform(-200.9,-59);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#FF3300").s().p("ABLC0IBdAfIhCDdgAinBiIAxhKIgHjuIBpjZICOFEIhACCIARCdg");
	this.shape_439.setTransform(-189.6,-53.7);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#FF3300").s().p("AiLiYIDujKIAQDMIgbBkIhOCcICCDiIj4AXg");
	this.shape_440.setTransform(-186.7,-73.4);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#FF3300").s().p("AhRCcIgrk0IgmgMIAhgjIgCgGIAEADIDIjkIBZIRIgBBSIijD6g");
	this.shape_441.setTransform(-221.2,-30.1);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#FF3300").s().p("AhECRIgwjrIAxhyICmFdIgWA+IAxBagAhgkJIAmAnIgJAWgAh+koIASAHIAMAYg");
	this.shape_442.setTransform(-190,-45.6);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#FF3300").s().p("AhdFZIgOAGIg2kFICJndIC6JYIhdBrIgNghIANBlg");
	this.shape_443.setTransform(-194.3,-49.9);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#FF3300").s().p("AiMGjIAciMIgfhjICxqlIBuK2Ihjg1IAFFig");
	this.shape_444.setTransform(-196.3,-35.5);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#FFE500").s().p("AguEVIgzgbIhAiJICQmXICzGLIgbCOIhUAoIgoAMg");
	this.shape_445.setTransform(-202.3,25.4);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#FFE500").s().p("AhABcIgJhpIAihLIBbg2IAABHIAWBIIAABoIhRAmg");
	this.shape_446.setTransform(-223.1,4.6);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#FFE500").s().p("AhGBqIgThtIAnhJIASg8IBrA2IAPCpIhaAyg");
	this.shape_447.setTransform(-201.9,1.1);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#FFE500").s().p("AhIBcIgDhNIAghhIAug/IA0A/IAVBmIgVBSIg/Asg");
	this.shape_448.setTransform(-197.6,-3);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#FFE500").s().p("AAXB5IhVgkIgHhgIATghIA5hOIA4A1IgEBgIALBgg");
	this.shape_449.setTransform(-186.6,14.2);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#FFE500").s().p("Ag3BJIgWhMIAKg5IBmhLIgBAYIAsBlIgSBfIhDAzg");
	this.shape_450.setTransform(-205.8,7.3);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#FFE500").s().p("Ag9B8IgSh0IAchHIAzhGIApAiIAUBDIATCZIhdANg");
	this.shape_451.setTransform(-208.2,1.4);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#FFE500").s().p("Ag9BfIAJjCIBPhBIAQAyIACB8IASBHIgsBUg");
	this.shape_452.setTransform(-216.6,23.9);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#FFE500").s().p("Ag8BDIAAiEIgHguIB5gwIgHAqIAVDFIhbBQg");
	this.shape_453.setTransform(-221.3,-3.4);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#FFE500").s().p("AgvCTIgaiDIAohZIAGhfIBlBRIgBA9IgYB8IgwBHg");
	this.shape_454.setTransform(-207.4,16.1);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#FFE500").s().p("AhCghIAUg8IgJg3IBTAiIAnBEIg0BzIhABRg");
	this.shape_455.setTransform(-178.9,-7.4);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#FFE500").s().p("Ag5A+IgZg2IAShWIBPg3IANBWIA3gEIgJC2IgqADg");
	this.shape_456.setTransform(-192.4,-11.1);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#FFE500").s().p("Ag/AfIARgoIgSiEIBvADIgmA5IA4AOIglDRg");
	this.shape_457.setTransform(-190.2,14.6);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#FFE500").s().p("AhGgxIAxhEIAfgOIAsAAIARBSIgBBKIhUBrg");
	this.shape_458.setTransform(-209.5,4.5);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#FFE500").s().p("AghB+IgXhgIADiiIA6AiIAcAFIAQA4IAICIIgaAig");
	this.shape_459.setTransform(-226.3,7.3);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#FFE500").s().p("AgUDwIhig9IgvhCICUmMIC3FlIg1CdIg6AlIhsAQg");
	this.shape_460.setTransform(-200.5,25);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#FFE500").s().p("AgaB1IAEhDIgciIIAzg8IAeCOIANAEIAHCEIhCAPg");
	this.shape_461.setTransform(-218.6,11.3);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#FFE500").s().p("Ag7BBIAUg8IATgPIgrhlIBxAXIgPBxIAdAlIgIAzg");
	this.shape_462.setTransform(-189.9,20.3);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#FFE500").s().p("AgvE3IgLgfIhPhLICCo1ICRG0IgIDJIiRBUg");
	this.shape_463.setTransform(-203.4,19.3);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#FFE500").s().p("AgVAgIgHg6IAkg4IgIgVIAggRIgYAmIAcBmIgrBbIgcAKg");
	this.shape_464.setTransform(-196.9,-33.6);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#FFE500").s().p("Agdg3IgmgiIAFgTIBBA/IBAAmIgdA5IgkAYIgnAig");
	this.shape_465.setTransform(-203.7,-28.9);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#FFE500").s().p("AglBNIgGh1IAkAOIADhPIAwAeIgSArIgGB0IgcAWg");
	this.shape_466.setTransform(-190.3,-27.8);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#FFE500").s().p("AgXBVIgThcIAfg+IABguIAUAkIAPBqIASAEIggBVg");
	this.shape_467.setTransform(-221.9,-9.8);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#FFE500").s().p("AgYgPIATgIIAegkIgQAaIAPANIgUBQg");
	this.shape_468.setTransform(-188.9,-0.9);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#FFE500").s().p("AgYAzIAIgaIAAhbIAoAzIgEAqIAFAkIgcAFg");
	this.shape_469.setTransform(-213.2,6.4);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#FFE500").s().p("AAEAbIgKABIgHgZIANgNIADgEIgFgNIAQgBIgLAOIAJAUIgIAVIAIgDIgJAFg");
	this.shape_470.setTransform(-202.8,-43.1);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#FFE500").s().p("AgNALIAKABIADgRIgDgFIARgcIgNAcIgBAFIAHAHIgFAlg");
	this.shape_471.setTransform(-201.4,-33.2);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#FF8C00").s().p("ABMDLIgGgSIiPjGIAQiyIhAhXIBUBNICfDzIgLDtg");
	this.shape_472.setTransform(-202.2,-40.3);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#FF8C00").s().p("Ag5CHIAbgsIhDgcIAghpIA8gSIArhNIAdA7IhhCpICAA2gAgjiQIgeBmIgOAFgAhBgqg");
	this.shape_473.setTransform(-197.2,-30.3);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#FF8C00").s().p("Ag4DSIBUjzIglhHIg1iNIBbCZIAHAgIgIAbIAkBEIAfC/Ii9AUg");
	this.shape_474.setTransform(-218.3,-13);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#FF8C00").s().p("AhEHuIBQiJIjAleIBQn6IEZIRIg9CcIgwE5g");
	this.shape_475.setTransform(-202.2,9.4);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#FF8C00").s().p("AhSBTIAuhxIAOheIBZhaIhRDNIAuhFIAzCRIgYCUg");
	this.shape_476.setTransform(-224,-30.8);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#FF8C00").s().p("AhSAsIAhijIAEg8IBfBIIALAOIAWEQIhzheIgOBfg");
	this.shape_477.setTransform(-214.4,-9.5);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#FF8C00").s().p("AgNCZIAdghIACghIhfBBIAgifIhTkIICuDyIBTATIhxCCIgLCYg");
	this.shape_478.setTransform(-205.3,-27.8);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#FF8C00").s().p("ABHCNIiEhDIBIg5IgfjLIBPBaIA2BwIAECrgAh1AvIA4AbIgHAFgAg9BKg");
	this.shape_479.setTransform(-204.8,-12.3);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#FF8C00").s().p("AgfBXIgRgmIgygEIBEkrIBXEUIggBrIBKBpIgjAVg");
	this.shape_480.setTransform(-228.4,-17.5);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#FF8C00").s().p("AhhBQIBAAOIAhiPIgagfIB8jIIhcDMIgGAbIAyA7IgMA8IgPDTg");
	this.shape_481.setTransform(-200.5,-19.5);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#FF8C00").s().p("AAjC5IhUAVIg0i4IBnhjIATgZIBBCUIgzCLIAygOIg+AqgAAVhmIgthmIB9gIIhQBug");
	this.shape_482.setTransform(-202.3,-29.3);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#FF8C00").s().p("AhcC2IAchdIgClNICaC5IgTCcIAYCFIhqAOg");
	this.shape_483.setTransform(-213.8,13.7);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#FF8C00").s().p("Ahag3IBGgeIBviEIg3BiIAvAuIhGEjg");
	this.shape_484.setTransform(-189.7,9.8);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#FF8C00").s().p("Ag4DNIgvjfIBJiWIADhuIAyBXIAmD/IAqAMIhNDKg");
	this.shape_485.setTransform(-222.8,-5.6);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#FF8C00").s().p("AhaC5IgOkeIBZAiIAGi8IByBKIgqBlIgOEYIhDA4g");
	this.shape_486.setTransform(-190.1,-21.8);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#FF8C00").s().p("Ag1hjIhEg+IAJgiIB2ByIB0BEIg1BnIiIBqg");
	this.shape_487.setTransform(-203.1,-26.5);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#FF8C00").s().p("AgnA6IgOhoIBChoIgNgkIA4gfIgrBDIAgBaIATBhIhOCkIgxAQg");
	this.shape_488.setTransform(-196.9,-32.7);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#FF8C00").s().p("AhDHDIgRgsIhyhuIC6swIDTJ2IgLEiIjTB3g");
	this.shape_489.setTransform(-204.4,9.8);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#FF8C00").s().p("AhVBfIAdhZIAcgWIg/iSICjAiIgVCkIApA1IgMBKg");
	this.shape_490.setTransform(-190.3,17.7);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#FF8C00").s().p("AgmCqIAGhgIgnjHIBJhXIArDNIASAHIAJDAIhdAVg");
	this.shape_491.setTransform(-218.6,8.2);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#FF8C00").s().p("AgeFbIiNhZIhEhfIDWo9IEJIGIhLDiIhWA1IibAYg");
	this.shape_492.setTransform(-200.3,17.5);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#FF8C00").s().p("AgyC3IgfiNIAFjoIBUAwIAmAHIAYBRIAMDHIglAug");
	this.shape_493.setTransform(-225.8,4.8);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#FF8C00").s().p("Ag2A6IgviAIBFhjIAvgTIA+gCIAZB2IgBBsIh5Cbg");
	this.shape_494.setTransform(-209.9,3);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#FF8C00").s().p("AhbAuIAZg8Igci+IChAEIg0BUIBQATIgpC6IgNB0g");
	this.shape_495.setTransform(-189.6,13.7);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#FF8C00").s().p("AhSBbIglhPIAbh+IByhOIASB7IBQgDIgOEGIg7ACg");
	this.shape_496.setTransform(-192.4,-14.1);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#FF8C00").s().p("AhKBnIgViYIAdhVIgOhRIB4AzIA4BjIhKClIhdB0g");
	this.shape_497.setTransform(-178,-9.3);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#FF8C00").s().p("AhEDVIgmi/IA5iBIAIiIICUB1IgCBYIghC0IhHBmg");
	this.shape_498.setTransform(-207.5,13.1);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#FF8C00").s().p("AhYBfIABi/IgKhCICvhFIgLA9IAfEeIiDB0g");
	this.shape_499.setTransform(-221.4,-4.9);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#FF8C00").s().p("AhZCIIAOkZIByhdIAYBIIACC0IAZBmIg+B7g");
	this.shape_500.setTransform(-216.5,21.9);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#FF8C00").s().p("AhYCyIgainIAnhnIBLhjIA8AvIAbBgIAcDeIiHASg");
	this.shape_501.setTransform(-208,-1.2);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#FF8C00").s().p("AhPBrIgihwIAPhSICVhsIgCAiIBBCSIgbCLIhgBIg");
	this.shape_502.setTransform(-205.2,4.9);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#FF8C00").s().p("AAjCwIh8g0IgLiMIAbgxIBWhvIBPBMIgGCMIAPCJg");
	this.shape_503.setTransform(-186.7,11.4);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#FF8C00").s().p("AhqCFIgChvIAuiPIBFhZIBIBbIAeCSIgdB4IhcBAg");
	this.shape_504.setTransform(-197.5,-6);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#FF8C00").s().p("AhlCZIgcicIA2hsIAchWICbBPIAWD0IiCBIg");
	this.shape_505.setTransform(-201.9,-1.4);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#FF8C00").s().p("AhdCFIgNiYIAxhsICDhOIAABnIAhBoIgBCWIh0A2g");
	this.shape_506.setTransform(-223.1,1.5);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#FF8C00").s().p("AhEGQIhKgoIhbjFIDQpNIEDI8IgnDLIh6A6Ig4AUg");
	this.shape_507.setTransform(-202.6,16.4);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#FF8C00").s().p("AhvB9IATihIgIhQICJhEIA+BRIANBOIgHCSIhwBAg");
	this.shape_508.setTransform(-181.2,-3.2);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#FF8C00").s().p("AhJDUIATiYIAKgPIA0iDIgpiEIBrgDIgvG7g");
	this.shape_509.setTransform(-201,-27.4);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#FF3300").s().p("Ai1CVIA7kPIBUiSICyB3IAqB4IhXDDIhZBng");
	this.shape_510.setTransform(-195.4,-28.2);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#FF3300").s().p("AirC+IAdj4IgOh6IDUhnIBgB8IAUB3IgLDgIisBkg");
	this.shape_511.setTransform(-181.2,-22.4);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#FF3300").s().p("AhnJpIhyg/IiOkuIFBuLIGONvIg8E5Ii7BbIhXAcg");
	this.shape_512.setTransform(-203.2,-13.3);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#FF3300").s().p("AiQDMIgTjqIBLimIDLh4IgCCdIAzCiIgBDnIizBTg");
	this.shape_513.setTransform(-223.3,-17.9);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#FF3300").s().p("AicDrIgrjyIBVilIApiDIDvB4IAiF3IjJBwg");
	this.shape_514.setTransform(-202.1,-19.7);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#FF3300").s().p("AijDMIgEisIBGjZIBqiKIBwCLIAvDiIgsC3IiQBjg");
	this.shape_515.setTransform(-197.1,-25.1);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#FF3300").s().p("AA1EPIjAhQIgQjYIArhMICCirIB6B1IgIDXIAYDVg");
	this.shape_516.setTransform(-186.7,-7.4);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#FF3300").s().p("Ah7CkIg0irIAYiAIDnimIgGA0IBmDhIgqDVIiVBxg");
	this.shape_517.setTransform(-204,-13);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#FF3300").s().p("AiJESIgokBIA9ifIB0iZIBcBJIApCUIAtFVIjRAdg");
	this.shape_518.setTransform(-207.6,-19.8);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#FF3300").s().p("AiKDSIAWmxICwiPIAlBvIAFEVIAlCdIhgC8g");
	this.shape_519.setTransform(-216.2,4.2);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#FF3300").s().p("AiICSIACklIgPhnIENhpIgPBeIAsG3IjHCzg");
	this.shape_520.setTransform(-221.5,-21.4);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#FF3300").s().p("AhqFGIg5kkIBYjHIAMjSIDjC1IAACIIg0EVIhuCdg");
	this.shape_521.setTransform(-208,-6);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#FF3300").s().p("AhzCeIggjpIAtiEIgUh8IC5BOIBVCZIhxD9IiQCzg");
	this.shape_522.setTransform(-176.2,-26.5);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#FF3300").s().p("Ah+CLIg5h5IAojDICyh2IAcC9IB5gGIgVGUIhcAEg");
	this.shape_523.setTransform(-192.3,-33.2);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#FF3300").s().p("AiMBFIAlhbIgqkkID7AHIhSB/IB6AfIhAEcIgUC0g");
	this.shape_524.setTransform(-188.5,-1.8);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#FF3300").s().p("AhUBbIhIjJIBriWIBJggIBhAAIAkC1IgBCnIi8Dtg");
	this.shape_525.setTransform(-210.6,-13.5);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#FF3300").s().p("AhNEZIgxjYIAIlnICCBLIA9AMIAjB7IATEyIg6BJg");
	this.shape_526.setTransform(-225,-13.3);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#FF3300").s().p("AgwIWIjXiJIhqiRIFKtzIGZMdIh1FdIiGBQIjsAlg");
	this.shape_527.setTransform(-199.8,-9.6);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#FF3300").s().p("Ag7EEIAJiTIg8kyIBxiFIBBE6IAcAMIAPEnIiRAgg");
	this.shape_528.setTransform(-218.4,-10.9);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#FF3300").s().p("AiECTIAsiLIAsgfIhijhID9AzIggD+IBABQIgUBwg");
	this.shape_529.setTransform(-190.9,-0.9);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#FF3300").s().p("AhnK1IgahEIixioIEgzpIFFPJIgRHBIiYBMIisBrg");
	this.shape_530.setTransform(-206.1,-20.5);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#FF3300").s().p("Ag9BaIgViiIBmigIgTg3IBWgwIhDBnIAxCLIAeCVIh3D8IhPAcg");
	this.shape_531.setTransform(-196.9,-51.5);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#FF3300").s().p("AhTibIhnheIANg0IC3CvICyBqIhRCfIhmBEIhuBfg");
	this.shape_532.setTransform(-202.3,-43.5);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#FF3300").s().p("AiLEdIgVm3ICIAxIAKkgICvBxIhACcIgVGwIhqBWg");
	this.shape_533.setTransform(-189.9,-39.4);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#FF3300").s().p("AhWE7IhIlXIByjnIAEioIBOCCIA4GLIBBARIh2E5g");
	this.shape_534.setTransform(-223.8,-24.8);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#FF3300").s().p("AhDBFIhIiZIBsgxICrjKIhUCWIBHBHIhrHCg");
	this.shape_535.setTransform(-190.3,-7.3);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#FF3300").s().p("AiOEZIAoiSIAAn+IDtEcIgdDxIAlDJIijAZg");
	this.shape_536.setTransform(-214.2,-5.9);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#FF3300").s().p("AA1EdIh+AgIhSkbICdiYIAdgnIBnDjIhRDXIBQgVIhgA+gAglk5IDBgMIh9Cog");
	this.shape_537.setTransform(-202.1,-47.1);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#FF3300").s().p("AiWB6IBjAWIA0jZIgqgzIDBk0IiNE5IgKAuIBLBYIgRBdIgXFFg");
	this.shape_538.setTransform(-200,-37.3);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#FF3300").s().p("AgwCHIgZg6IhOgIIBqnMICFGqIgyCkIByChIg2Agg");
	this.shape_539.setTransform(-229.5,-38.9);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#FF3300").s().p("ABsDYIjMhnIBuhYIguk3IB6CLIBUCsIAHEGgAi0BHIBUAqIgKAHgAhgBxg");
	this.shape_540.setTransform(-204.9,-32.7);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#FF3300").s().p("AgVDrIAtgzIADgyIiRBjIAvj0Ih+mVIELFzICAAcIiuDJIgQDpg");
	this.shape_541.setTransform(-206,-48.5);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#FF3300").s().p("Ah/BEIAyj7IAHhdICUBwIAQAUIAiGjIiziPIgUCRg");
	this.shape_542.setTransform(-213.5,-25.8);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#FF3300").s().p("AgXDZIATgoIA8ArgAg3CPIAwkMIAWCJIALhSIgahpIAtgtIgTCWIAeBvIg8CIg");
	this.shape_543.setTransform(-207,-55.5);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#FF3300").s().p("Ah/CBIBHivIAXiRICJiLIh+E8IBJhrIBNDeIgkDmg");
	this.shape_544.setTransform(-224.8,-49.2);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#FF3300").s().p("AhoL4IB7jTIkqobIB8sKIGyMvIhdDvIhLHjg");
	this.shape_545.setTransform(-202.7,-17.1);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#FF3300").s().p("AhWFEICAl5Ig3hsIhSjYICMDrIALAwIgOApIA5BrIAuEkIkgAgg");
	this.shape_546.setTransform(-219.9,-33.3);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#FF3300").s().p("AhXDPIAnhDIhmgrIAxigIBdgdIBDh4IAtBbIiYEFIDHBUgAg2jfIgvCgIgUAFgAhlg/g");
	this.shape_547.setTransform(-195.3,-48.3);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#FF3300").s().p("AgOB+IAXigIBLiBIAAgoIApiKIgOCBIgbAxIgCDwIgrgEIijEOg");
	this.shape_548.setTransform(-221.6,-37.7);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#FF3300").s().p("AB0E3IgJgaIjbkyIAZkQIhjiHICBB2ID0F2IgRFtg");
	this.shape_549.setTransform(-203,-59);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#FF3300").s().p("AhyFHIAfjoIAPgXIBQjMIhBjLICogFIhJKpg");
	this.shape_550.setTransform(-200.1,-45.9);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#FF3300").s().p("AADBKIgPhwIgcgGIAigfIAmAuIgdAjIAmBHg");
	this.shape_551.setTransform(-203.2,-110.9);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#FF3300").s().p("AhjAbIgYg5IA9gRIAbhFIA/hKIBgAOIhqBqIhQAXIgcBGICYCog");
	this.shape_552.setTransform(-203.5,-44);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#FF3300").s().p("AASBwIALgdIASiAIhRAyIAqhDIBGAYIgJALIgoBuIgLBMgAAIg+IhVghICRg/Ig8Bgg");
	this.shape_553.setTransform(-230.8,-56);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#FF3300").s().p("AgXgQIgVgZIgIg3IBfATIgWBKIAPAGIgoBegAArhNIAFgPIAGAQgAArhNg");
	this.shape_554.setTransform(-190.2,-86.3);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#FF3300").s().p("Ag0ArIA0AQIgDA6gAAAA7IAAgWIBEArgAAAA7gAgeASIglAIIA5hWIgGgZIApgfIgjA4IAKA+IAAAjg");
	this.shape_555.setTransform(-184.2,-89.1);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#FF3300").s().p("AgLA8IAJhzIAcBBIgDAVIgZBkgAgOAnIADAVIgBAOgAAaAKIALhYIAABxgAAaAKgAgkiCIAkAiIgCApg");
	this.shape_556.setTransform(-206,-67);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#FF3300").s().p("AAMBgIgJgBIgThfIgkg4IBYgvIgjBOIAjAQIgYBpIAqADIgtAFg");
	this.shape_557.setTransform(-202.6,-105.6);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#FF3300").s().p("AgeBdIARgkIgLggIAih1IAPA+IgmBXIAIAWIAkgcIgDAmIgHAEg");
	this.shape_558.setTransform(-211.3,-63.9);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#FF3300").s().p("AgfAaIAQAKIgRBHgAgPAkIAPhHIgEgKIABgfIANgHIgKAwIAjBKIgEAdgAgPAkgAgChqIgBAeIgfAMg");
	this.shape_559.setTransform(-203.4,-85.6);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#FF3300").s().p("AhBAkIADgHIAwhAIAfCKgAg9AXIgBAGIgGAFgAg+AdgAgugdIAZgPIAVgkIBFgXIhaA7IgoBDgAgZhhIgVBEIgQAMg");
	this.shape_560.setTransform(-193.3,-79);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#FF3300").s().p("AAAgIIgcg2IAMgCIgdgkIAfAkIAggKIABgDIgBAFIAKA9IgUgYIgIAbIAuBUIhLAZg");
	this.shape_561.setTransform(-206,-86);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#FF3300").s().p("Ag4BRIgYjjICBBwIgBAzIAGBOIgugNIBIAiIg+Afg");
	this.shape_562.setTransform(-187.8,-70.9);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#FF3300").s().p("AgOgbIgZAlIgJhoIBmgPIhEAxIAMBcIgzBOgAgCAgIAKgSIgHAxgAgCAgg");
	this.shape_563.setTransform(-208.7,-99.8);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#FFE500").s().p("AhEBEIgGihIBqgpIADA8IAoA6IgJBmIg+Axg");
	this.shape_564.setTransform(-187.3,17.6);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#FFE500").s().p("Ag3BVIgdhfIAhhGIAog3IBJAwIAXBPIgMBKIhKBGg");
	this.shape_565.setTransform(-205.2,9.5);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#FFE500").s().p("AhABZIgJhhIALhtIBNgPIArAqIAQA9IgCBxIhFAxg");
	this.shape_566.setTransform(-222.9,17.8);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#FFE500").s().p("AgvEDIhOgkIgshnICymgIChGJIgvCQIhBAnIhbARg");
	this.shape_567.setTransform(-197.6,26.8);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#FFE500").s().p("AgwBnIgQi4IAphAIBIBpIALAgIAFBvIhHArg");
	this.shape_568.setTransform(-216.3,21);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#FFE500").s().p("AhGBVIALhQIARgnIgDhjIBpA+IgDBVIAOA9IguA6g");
	this.shape_569.setTransform(-186.2,28.2);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#FFE500").s().p("AhBEyIhXiFICYn+ICZG3IgcCfIg5AtIhQAgg");
	this.shape_570.setTransform(-199.4,24);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#FFE500").s().p("Ag4B8IACiwIBbhWIgKAjIAVBJIAJBVIg/BUg");
	this.shape_571.setTransform(-195.7,-19.9);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#FFE500").s().p("AhICBIAPiYIgcgyIAig7ICICAIgfBfIg0Aqg");
	this.shape_572.setTransform(-201.7,-17.9);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#FFE500").s().p("AhGB7IgDigIAhgNIAmhtIBMBEIgRA7IgFCjIhDAdg");
	this.shape_573.setTransform(-187.1,-10.9);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#FFE500").s().p("AgzB+IgbiBIAxhbIAShMIA6BAIAaCDIAGAyIhDBgg");
	this.shape_574.setTransform(-219.1,7.9);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#FFE500").s().p("AguA3IgVhPIB1h7IgGBHIAYA2IgaBvIgpA7g");
	this.shape_575.setTransform(-184.4,19.8);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#FFE500").s().p("AhJB1IAkkVIBpBvIAGCvIhJAig");
	this.shape_576.setTransform(-211.1,27.3);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#FFE500").s().p("AgnB+IgghsIBehxIgEgKIApghIglArIAwBwIgbBwIgCAKg");
	this.shape_577.setTransform(-202.6,-14.8);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#FFE500").s().p("Ag+BJIAagbIAZhkIBKh2IgrByIAoBBIgEBCIgkBkg");
	this.shape_578.setTransform(-198.3,-6.5);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#FFE500").s().p("AghBGIgRgtIgSgdIBCidIA8COIgSBKIAdBOIgoAdg");
	this.shape_579.setTransform(-225.4,-1.6);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#FFE500").s().p("AhSA6IAVgOIAug8IAAhnIBAA9IAfBKIADBnIg7ABg");
	this.shape_580.setTransform(-200.9,2.2);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#FFE500").s().p("AgbBLIgtgDIAShfIgWiWIBvCKIAqAgIhIBqIgJBHg");
	this.shape_581.setTransform(-200.2,-13);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#FFE500").s().p("AgMBbIghAbIgThaIAShhIAQg4IBNA6IANAdIAFCkg");
	this.shape_582.setTransform(-210.4,1.8);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#FFE500").s().p("AADBvIABAAIgsgiIAOiAIALApIAfhtIgIAmIAhBcIglBkIAOAJg");
	this.shape_583.setTransform(-205.3,-13);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#FFE500").s().p("AgxA7IANhKIARgvIAzg4IgWBgIAbgIIAMBSIgcBDg");
	this.shape_584.setTransform(-218.8,-22.1);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#FFE500").s().p("AgGCdIghgqIguhXIA8jjIBvDqIgyCjIg2ACg");
	this.shape_585.setTransform(-198.6,18.9);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#FFE500").s().p("AglBTIAehlIABgSIgWg6IA7BqIAHBKIhFAJg");
	this.shape_586.setTransform(-214.2,-2.3);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#FFE500").s().p("AgaASIAJgnIgEABIAIgPIgEAOIAigSIAKATIgbAxIAXALg");
	this.shape_587.setTransform(-196.7,-27.2);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#FFE500").s().p("AgIgEIARgnIAGgcIAFAiIAAAyIgFALIgiAwg");
	this.shape_588.setTransform(-215.5,-7.6);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#FFE500").s().p("AAFAdIgDgDIgPgaIADgVIgDgMIALALIAQAcIAAAcg");
	this.shape_589.setTransform(-195.8,-39.3);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#FFE500").s().p("AgJAMIAAgGIAFgSIgBgQIAPADIgFAzIgMADg");
	this.shape_590.setTransform(-198.3,-26.9);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#FF8C00").s().p("AhUBaIgdkqICyB3IAdBRIAIB5Ig9AKIBJA6IhoAcg");
	this.shape_591.setTransform(-186.6,-7.8);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#FF8C00").s().p("AgMglIBWDOIiTAWgAAPhVIgRAMIAGgbIgEgEIAHgIIgDAMIALAPIAngXIAHBPgAgMglIgLgZIAVgLIgKAkgAhDi+IBDBWIgOARgAAAhog");
	this.shape_592.setTransform(-200.4,-18.9);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#FF8C00").s().p("Ah8BZIAniZIgUAOIAqhgIgWBSIBqhHIAEgGIBkg+IhoBEIheC1IBShHIAcDlg");
	this.shape_593.setTransform(-188.7,-14.9);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#FF8C00").s().p("AhGBmIAIAEIgbCJgAg+BqIAykDIhTAHIBYhgIAOCOIBZCvIgRBdgAg+Bqg");
	this.shape_594.setTransform(-197.2,-16.9);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#FF8C00").s().p("AARDQIhlgZIA/iVIgEgKIAnj2IALCOIguByIApBzIBBgTIgbBdg");
	this.shape_595.setTransform(-207,-7.1);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#FF8C00").s().p("AA0DqIACgEIhBgNIgrjQIg9iAIDKh7IgvC1IBHA2Ig5DtIA+AMg");
	this.shape_596.setTransform(-196.5,-43);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#FF8C00").s().p("Ag9BgIgKAQIAckZIgRhLIByEJIgHA6IhICmgAA2AVIASiMIgPCSgAA2AVg");
	this.shape_597.setTransform(-201.4,-6.8);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#FF8C00").s().p("AhEBlIARACIgGhbIAmAIIBYBjIh4gQIADAzgAg5AMIgHgDIAHgOIAAARgAhAheIBAg6Ig5CTg");
	this.shape_598.setTransform(-180.6,-33.9);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#FF8C00").s().p("AhDgRIgZhAIAPhnICqAtIgnCxIAAAVIhVB/g");
	this.shape_599.setTransform(-184.2,-23.6);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#FF8C00").s().p("AAQglIhgAWIBIh1IhngsICgg1Ig5BhIB4A0IhcE2g");
	this.shape_600.setTransform(-227.5,3.4);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#FF8C00").s().p("AhgAxIgOhMIBtg/IAYgYIAig3IA2gZIhYBQIgPAbIgkCGIBPCUg");
	this.shape_601.setTransform(-201.5,3.6);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#FF8C00").s().p("AgcChIggkIIAQgFIgnguIBZgWIBOBwIgyBiIAfCPg");
	this.shape_602.setTransform(-200.1,-43.6);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#FF8C00").s().p("AhJBWIgBgyIAoh8IgEh8IBxASIgiGCIhdAVg");
	this.shape_603.setTransform(-196.8,-14.2);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#FF8C00").s().p("AAJC8IhwjBIAaiUIgYhdIBXBPIB1DTIgDDMg");
	this.shape_604.setTransform(-195.6,-27.8);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#FF8C00").s().p("AgrBwIAMiAIBAiKIAShnIAXB2IgBC+IgUAlIh9Cqg");
	this.shape_605.setTransform(-216.7,1.7);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#FF8C00").s().p("AhfBAIAjiRIB6hAIAiBEIhfC3IBRAogAgziAIgJAvIgNAGgAg8hRg");
	this.shape_606.setTransform(-195.6,-16.2);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#FF8C00").s().p("AhZDEIBHjyIADgqIg1iNICOEAIAQCzIijAXg");
	this.shape_607.setTransform(-214.8,1.2);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#FF8C00").s().p("AgQF6IhQhlIhujUICOohIEPI1Ig8ChIg7DmIiGAFg");
	this.shape_608.setTransform(-199,14.3);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#FF8C00").s().p("AhYBrIAXiHIAdhVIBfhmIgoCvIAwgQIAXCYIgzB3g");
	this.shape_609.setTransform(-219.4,-20.9);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#FF8C00").s().p("AAFDHIABgCIhRg7IAcjnIASBKIA7jEIgQBGIA+ClIhGCxIAcATg");
	this.shape_610.setTransform(-205.1,-11.6);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#FF8C00").s().p("AgTCFIgvAoIgciEIAbiMIAZhTIBuBWIASApIAIDug");
	this.shape_611.setTransform(-210.1,-0.5);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#FF8C00").s().p("AgoBsIhAgDIAaiKIghjZICjDHIA8AuIhoCZIgNBng");
	this.shape_612.setTransform(-199.9,-16.5);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#FF8C00").s().p("Ah2BVIAegVIBDhaIAAiTIBdBYIAtBrIACCVIhTADg");
	this.shape_613.setTransform(-201,-1.4);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#FF8C00").s().p("AgwBmIgZhDIgbgoIBhjkIBXDNIgZBsIAqBvIg7Arg");
	this.shape_614.setTransform(-225.9,-5.4);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#FF8C00").s().p("AhaBqIAlgnIAkiRIBsirIg9CkIA5BgIgEBfIg0CQg");
	this.shape_615.setTransform(-198.5,-9.1);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#FF8C00").s().p("Ag4C4IguieICGijIgGgNIA+gxIg4A+IBHCiIgnCjIgCAMg");
	this.shape_616.setTransform(-202.8,-17.6);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#FF8C00").s().p("AhpCpIAzmRICYCeIgDCBIALB/IhpAzg");
	this.shape_617.setTransform(-211.3,24.2);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#FF8C00").s().p("AhDBPIgfhyICqiyIgIBnIAjBOIgnCgIg7BWg");
	this.shape_618.setTransform(-184.6,17.5);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#FF8C00").s().p("AhKC2Igmi5IBGiEIAZhuIBUBcIAtEGIhgCJg");
	this.shape_619.setTransform(-219.6,4.8);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#FF8C00").s().p("AhkCwIgHjnIAxgSIA2idIBwBjIgZBVIgHDrIhiAqg");
	this.shape_620.setTransform(-187,-13.5);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#FF8C00").s().p("AhnC3IAVjcIgphHIAxhTIDGC4IguCKIhLA9g");
	this.shape_621.setTransform(-201.3,-20.5);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#FF8C00").s().p("AhSCzIAEj+ICDh7IgNAwIAeBrIANB5IhbB5g");
	this.shape_622.setTransform(-195.6,-22.8);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#FF8C00").s().p("AhcG6IiAjBIDcrgIDdJ5IgqDnIhRBBIhzAug");
	this.shape_623.setTransform(-200,14.8);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#FF8C00").s().p("AhmB8IAPh2IAbg3IgGiOICYBYIgEB7IAVBaIhDBSg");
	this.shape_624.setTransform(-186.2,25.4);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#FF8C00").s().p("AhGCVIgDh7IgViRIA8hcIBpCZIAPAuIAJChIhoA/g");
	this.shape_625.setTransform(-216.3,18.4);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#FF8C00").s().p("AhEF3IhwgzIhBiWIEBpZIDqI3IhDDSIhfA2IiEAYg");
	this.shape_626.setTransform(-197.3,18.6);

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#FF8C00").s().p("AhbCDIgQiOIATieIBugWIBAA8IAWBZIgDCkIhkBGg");
	this.shape_627.setTransform(-222.5,15.9);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#FF8C00").s().p("AhQB4IgqiGIAuhnIA7hNIBrBCIAhB1IgSBqIhrBkg");
	this.shape_628.setTransform(-205.2,7.1);

	this.shape_629 = new cjs.Shape();
	this.shape_629.graphics.f("#FF8C00").s().p("AhhBgIgLjpICcg4IABBVIA8BVIgMCTIhbBGg");
	this.shape_629.setTransform(-187,15.2);

	this.shape_630 = new cjs.Shape();
	this.shape_630.graphics.f("#FF8C00").s().p("AhlBzIgbhrIAmhnIBthdIAsBjIBCA4IgQC2IhdAog");
	this.shape_630.setTransform(-188.8,-9.1);

	this.shape_631 = new cjs.Shape();
	this.shape_631.graphics.f("#FF8C00").s().p("AgYA8IAEAWIg9CEgAgUBSIALgaIgKApgAgUBSgAgYA8IgFgxIAggZIgbBKgAgthyIAQB9IgJAHgAgdALgAgwioICCgtIh/Bjg");
	this.shape_631.setTransform(-202.4,-39.2);

	this.shape_632 = new cjs.Shape();
	this.shape_632.graphics.f("#FF3300").s().p("AiVDwIgZjkIAmiaIBaicIDACaIAdCCIgtDDIiZB2g");
	this.shape_632.setTransform(-203.8,-3.4);

	this.shape_633 = new cjs.Shape();
	this.shape_633.graphics.f("#FF3300").s().p("AidCxIgoilIA5ifICoiOIBFCYIBlBVIgYEZIiQA9g");
	this.shape_633.setTransform(-188.7,-28.8);

	this.shape_634 = new cjs.Shape();
	this.shape_634.graphics.f("#FF3300").s().p("AiWCVIgQlpIDvhWIADCDIBbCEIgTDiIiLBsg");
	this.shape_634.setTransform(-186.3,-3.1);

	this.shape_635 = new cjs.Shape();
	this.shape_635.graphics.f("#FF3300").s().p("Ah7C5IhCjOIBJieIBZh5IClBoIA0CyIgcCjIimCcg");
	this.shape_635.setTransform(-205.4,-10.9);

	this.shape_636 = new cjs.Shape();
	this.shape_636.graphics.f("#FF3300").s().p("AiODHIgXjaIAbjyICqgiIBhBdIAkCIIgED9IiYBsg");
	this.shape_636.setTransform(-221.5,-1.1);

	this.shape_637 = new cjs.Shape();
	this.shape_637.graphics.f("#FF3300").s().p("AhoJBIiuhQIhkjmIGNudIFoNpIhnFDIiUBUIjLAlg");
	this.shape_637.setTransform(-196.9,-9.6);

	this.shape_638 = new cjs.Shape();
	this.shape_638.graphics.f("#FF3300").s().p("AhtDmIgDi+IghjhIBdiMICgDsIAZBGIAND5IifBgg");
	this.shape_638.setTransform(-216.3,-0.1);

	this.shape_639 = new cjs.Shape();
	this.shape_639.graphics.f("#FF3300").s().p("AieC9IAYizIAphVIgJjcIDsCJIgJC+IAiCJIhoB+g");
	this.shape_639.setTransform(-186.2,6.6);

	this.shape_640 = new cjs.Shape();
	this.shape_640.graphics.f("#FF3300").s().p("AiPKnIjEkqIFUxqIFTPNIg/FkIh7BjIi0BHg");
	this.shape_640.setTransform(-201,-15.1);

	this.shape_641 = new cjs.Shape();
	this.shape_641.graphics.f("#FF3300").s().p("Ah+ESIANjWIgGiwIDIi/IgVBNIAvClIAUC5IiMC8g");
	this.shape_641.setTransform(-195.5,-41.7);

	this.shape_642 = new cjs.Shape();
	this.shape_642.graphics.f("#FF3300").s().p("AifEcIAflSIg+huIBMiCIExEcIhIDVIhyBcg");
	this.shape_642.setTransform(-200.3,-39.1);

	this.shape_643 = new cjs.Shape();
	this.shape_643.graphics.f("#FF3300").s().p("AicEQIgIlkIBKgdIBSjwICtCXIgmCBIgKFqIiYBBg");
	this.shape_643.setTransform(-186.7,-32);

	this.shape_644 = new cjs.Shape();
	this.shape_644.graphics.f("#FF3300").s().p("AhyEXIg7kfIBtjJIAlioICDCOIBGGSIiSDTg");
	this.shape_644.setTransform(-220.6,-14.3);

	this.shape_645 = new cjs.Shape();
	this.shape_645.graphics.f("#FF3300").s().p("AhpB6IgtixIEFkRIgMCeIA0B4Ig6D2IhaCFg");
	this.shape_645.setTransform(-184.8,-0.5);

	this.shape_646 = new cjs.Shape();
	this.shape_646.graphics.f("#FF3300").s().p("AiiEFIAPi7IAjirIAckEIDoD1IgDDEIASDDIiiBPg");
	this.shape_646.setTransform(-211.6,4.9);

	this.shape_647 = new cjs.Shape();
	this.shape_647.graphics.f("#FF3300").s().p("AhXEZIhGjwIDOj9IgIgUIBdhLIhVBfIBtD5Ig/EPg");
	this.shape_647.setTransform(-203.1,-36.1);

	this.shape_648 = new cjs.Shape();
	this.shape_648.graphics.f("#FF3300").s().p("AiKCiIA5g7IA2jfICmkIIhdD+IBXCUIgICSIhODdg");
	this.shape_648.setTransform(-198.9,-27.5);

	this.shape_649 = new cjs.Shape();
	this.shape_649.graphics.f("#FF3300").s().p("AhLCdIglhnIgqg/ICWleICGE9IgnCkIBACrIhaBDg");
	this.shape_649.setTransform(-226.9,-25.7);

	this.shape_650 = new cjs.Shape();
	this.shape_650.graphics.f("#FF3300").s().p("Ai2CCIAtggIBniIIACjkICPCIIBEClIAEDlIh/ADg");
	this.shape_650.setTransform(-201.1,-21.8);

	this.shape_651 = new cjs.Shape();
	this.shape_651.graphics.f("#FF3300").s().p("Ag+ClIhjgEIAojWIgylMID7EwIBcBIIiiDtIgUCfg");
	this.shape_651.setTransform(-199.4,-36.6);

	this.shape_652 = new cjs.Shape();
	this.shape_652.graphics.f("#FF3300").s().p("AgdDMIhKA9IgpjLIAnjXIAniAICqCFIAdA+IAMFwg");
	this.shape_652.setTransform(-209.7,-18.2);

	this.shape_653 = new cjs.Shape();
	this.shape_653.graphics.f("#FF3300").s().p("AAGEzIADgGIh8haIAqljIAcByIBbktIgXBpIBdEAIhrEPIAqAfg");
	this.shape_653.setTransform(-204.8,-29.9);

	this.shape_654 = new cjs.Shape();
	this.shape_654.graphics.f("#FF3300").s().p("AiJCjIAljPIAsiDICSicIg+ELIBLgYIAjDqIhNC6g");
	this.shape_654.setTransform(-220,-39.3);

	this.shape_655 = new cjs.Shape();
	this.shape_655.graphics.f("#FF3300").s().p("AgZJFIh8ieIiplDIDbtHIGiNkIhdD4IhcFiIjOAJg");
	this.shape_655.setTransform(-199.4,-13);

	this.shape_656 = new cjs.Shape();
	this.shape_656.graphics.f("#FF3300").s().p("AiKEvIBvl2IAFhCIhSjXIDZGKIAaETIj8Akg");
	this.shape_656.setTransform(-215.3,-18.7);

	this.shape_657 = new cjs.Shape();
	this.shape_657.graphics.f("#FF3300").s().p("AiUBlIA2jjIgUALIAkhQIgQBFIC+hhIA1BrIiUEYIB8A9g");
	this.shape_657.setTransform(-194.7,-33.2);

	this.shape_658 = new cjs.Shape();
	this.shape_658.graphics.f("#FF3300").s().p("AhFCsIAVjGIBjjVIAbidIAjC2IgCEjIgeA6IjBEGg");
	this.shape_658.setTransform(-217.5,-16.4);

	this.shape_659 = new cjs.Shape();
	this.shape_659.graphics.f("#FF3300").s().p("AAMEgIirknIAmjlIgkiPICIB5IC1FGIgJE4g");
	this.shape_659.setTransform(-195.4,-47.1);

	this.shape_660 = new cjs.Shape();
	this.shape_660.graphics.f("#FF3300").s().p("AhyCEIgBhMIA9jAIgFi+ICvAcIg1JRIiRAgg");
	this.shape_660.setTransform(-195.8,-32.7);

	this.shape_661 = new cjs.Shape();
	this.shape_661.graphics.f("#FF3300").s().p("AgrD3IgxmWIAYgIIg8hGICKgiIB3CsIhNCWIAvDdg");
	this.shape_661.setTransform(-200.9,-61.6);

	this.shape_662 = new cjs.Shape();
	this.shape_662.graphics.f("#FF3300").s().p("AiUBNIgXh4ICohiIArgnIAwhSIBUglIiEB3IgbAtIg7DOIB8Dlg");
	this.shape_662.setTransform(-200.1,-14.5);

	this.shape_663 = new cjs.Shape();
	this.shape_663.graphics.f("#FF3300").s().p("AAZg4IiUAgIBsiyIichFID2hRIhaCWIC8BOIiNHdg");
	this.shape_663.setTransform(-229.7,-11.1);

	this.shape_664 = new cjs.Shape();
	this.shape_664.graphics.f("#FF3300").s().p("AhvgZIgmhjIAXigIEGBIIg9EPIACAgIiFDCgACIjUIAAgCIAOAFgACIjUg");
	this.shape_664.setTransform(-183.3,-40.7);

	this.shape_665 = new cjs.Shape();
	this.shape_665.graphics.f("#FF3300").s().p("AhpCaIAZAEIgHiOIA7APICGCYIi6gZIAFBOgAhiANIAIgUIgIiMIBihYIhaDkIADAXg");
	this.shape_665.setTransform(-178.6,-53.8);

	this.shape_666 = new cjs.Shape();
	this.shape_666.graphics.f("#FF3300").s().p("AhgCSIgOAaIArmyIgZhzICvGaIgLBYIhxEBgABTAhIAcjYIgYDhgABTAhg");
	this.shape_666.setTransform(-201.7,-26.7);

	this.shape_667 = new cjs.Shape();
	this.shape_667.graphics.f("#FF3300").s().p("ABOFoIACgFIhjgUIhAlBIhfjGIE3i8IhJEWIBtBSIhZFvIBjASg");
	this.shape_667.setTransform(-195.1,-63.4);

	this.shape_668 = new cjs.Shape();
	this.shape_668.graphics.f("#FF3300").s().p("AAZE/IibgmIBgjkIgHgRIA/l7IARDaIhJCyIBBCvIBkgdIgpCRg");
	this.shape_668.setTransform(-206.3,-32.3);

	this.shape_669 = new cjs.Shape();
	this.shape_669.graphics.f("#FF3300").s().p("AhqCdIAKAFIgpDUgAhgCiIBPmOIiCALICHiUIAYDZICIEOIgZCPgAhgCig");
	this.shape_669.setTransform(-196.9,-33.7);

	this.shape_670 = new cjs.Shape();
	this.shape_670.graphics.f("#FF3300").s().p("Ai9CJIA6jsICmhvIADgHICZhhIicBoIiVEYIB/huIArFjgAhljiIgeB/IggAVgAiDhjg");
	this.shape_670.setTransform(-186.1,-30.1);

	this.shape_671 = new cjs.Shape();
	this.shape_671.graphics.f("#FF3300").s().p("AgTg6IgRglIAfgRIgOA2ICEE+IjhAigAAZiCIA5gjIALB3gAAFicIAUAaIgeASgAAZiCgAhpklIBpCEIgZAcgAAAihIAJgNIgEASg");
	this.shape_671.setTransform(-199.8,-33.7);

	this.shape_672 = new cjs.Shape();
	this.shape_672.graphics.f("#FF3300").s().p("AgiCVIAEhiIgiACIAQjMIBeCZIg6BdIA9gDIAQA8g");
	this.shape_672.setTransform(-200.4,-77);

	this.shape_673 = new cjs.Shape();
	this.shape_673.graphics.f("#FF3300").s().p("AiACKIgunLIESC3IAuB9IAMC6IheAQIBvBaIigArg");
	this.shape_673.setTransform(-186.5,-24.3);

	this.shape_674 = new cjs.Shape();
	this.shape_674.graphics.f("#FF3300").s().p("AglBeIADAfIhcDLgAgiB9IASgpIgPBAgAgiB9gAguARIA0goIgrB1gAhMkEIDKhDIjFCWIAZDCIgQAKgAguARg");
	this.shape_674.setTransform(-201,-56.7);

	this.shape_675 = new cjs.Shape();
	this.shape_675.graphics.f("#FF3300").s().p("AAAAbIAyAPIgnBVgAgwAMIATgHIgLhDIAbhAIAjBnIgXAeIABAUg");
	this.shape_675.setTransform(-188.4,-83.8);

	this.shape_676 = new cjs.Shape();
	this.shape_676.graphics.f("#FF3300").s().p("Ag7hWIAvgWIA1g3IgPBhIgMAiIgoA5IBWBrIhrAgg");
	this.shape_676.setTransform(-183.7,-103.6);

	this.shape_677 = new cjs.Shape();
	this.shape_677.graphics.f("#FF3300").s().p("AgRgUIgegFIAYgkIgCgFIADACIAmhAIAgCnIAAANIguBNg");
	this.shape_677.setTransform(-219.5,-66.2);

	this.shape_678 = new cjs.Shape();
	this.shape_678.graphics.f("#FF3300").s().p("AAaB0IAKAAIA2ApgAAkB0Ig0gmIgXiEIBSCqgAgng2IgyhmIAIAPIBLAcIghA7g");
	this.shape_678.setTransform(-195.6,-67.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3,p:{scaleY:3.512,x:-93.9,y:108.2}},{t:this.instance_2,p:{scaleY:3.512,x:-95.7,y:109.6}},{t:this.text_1,p:{scaleY:3.022,x:-94.7,y:84.8,text:"Mg",lineHeight:22.25,lineWidth:49,scaleX:3.514,font:"19px 'Arial'",color:"#000000"}}]},1).to({state:[]},1).to({state:[{t:this.instance_3,p:{scaleY:3.513,x:-90.6,y:100.3}},{t:this.instance_2,p:{scaleY:3.513,x:-92.4,y:101.8}},{t:this.text_1,p:{scaleY:2.502,x:-94.2,y:77,text:"فحم",lineHeight:23.25,lineWidth:50,scaleX:3.514,font:"19px 'Arial'",color:"#000000"}}]},3).to({state:[]},1).to({state:[{t:this.shape_11}]},13).to({state:[]},1).to({state:[{t:this.instance_11},{t:this.shape_12},{t:this.text_2},{t:this.text_1,p:{scaleY:3.167,x:-58.8,y:112.4,text:"مخفف",lineHeight:10.9,lineWidth:19,scaleX:3.167,font:"8px 'Arial'",color:"#FFFFFF"}}]},19).to({state:[]},1).to({state:[{t:this.shape_13}]},31).to({state:[]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15}]},4).to({state:[{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113}]},2).to({state:[{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232}]},2).to({state:[{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347}]},2).to({state:[{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445}]},1).to({state:[{t:this.shape_678},{t:this.shape_677},{t:this.shape_676},{t:this.shape_675},{t:this.shape_674},{t:this.shape_673},{t:this.shape_672},{t:this.shape_671},{t:this.shape_670},{t:this.shape_669},{t:this.shape_668},{t:this.shape_667},{t:this.shape_666},{t:this.shape_665},{t:this.shape_664},{t:this.shape_663},{t:this.shape_662},{t:this.shape_661},{t:this.shape_660},{t:this.shape_659},{t:this.shape_658},{t:this.shape_657},{t:this.shape_656},{t:this.shape_655},{t:this.shape_654},{t:this.shape_653},{t:this.shape_652},{t:this.shape_651},{t:this.shape_650},{t:this.shape_649},{t:this.shape_648},{t:this.shape_647},{t:this.shape_646},{t:this.shape_645},{t:this.shape_644},{t:this.shape_643},{t:this.shape_642},{t:this.shape_641},{t:this.shape_640},{t:this.shape_639},{t:this.shape_638},{t:this.shape_637},{t:this.shape_636},{t:this.shape_635},{t:this.shape_634},{t:this.shape_633},{t:this.shape_632},{t:this.shape_631},{t:this.shape_630},{t:this.shape_629},{t:this.shape_628},{t:this.shape_627},{t:this.shape_626},{t:this.shape_625},{t:this.shape_624},{t:this.shape_623},{t:this.shape_622},{t:this.shape_621},{t:this.shape_620},{t:this.shape_619},{t:this.shape_618},{t:this.shape_617},{t:this.shape_616},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613},{t:this.shape_612},{t:this.shape_611},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605},{t:this.shape_604},{t:this.shape_603},{t:this.shape_602},{t:this.shape_601},{t:this.shape_600},{t:this.shape_599},{t:this.shape_598},{t:this.shape_597},{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564}]},1).to({state:[{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445}]},1).to({state:[]},2).wait(2));

	// Layer_4
	this.shape_679 = new cjs.Shape();
	this.shape_679.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],53), null, new cjs.Matrix2D(-1.166,0,0,1.703,112.5,-114.9)).s().p("AxkR9MAAAgj5MAjIAAAIAAEHIjsAAIAAK9IDsAAIAAPfImgAAIAAFWg");
	this.shape_679.setTransform(-94.7,39.5);

	this.shape_680 = new cjs.Shape();
	this.shape_680.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],74), null, new cjs.Matrix2D(0.728,0,0,0.728,-127.7,-120)).s().p("Az8SxMAAAglhMAiQAAAIAAOYIFpAAIAAXJg");
	this.shape_680.setTransform(-102.3,42.7);

	this.instance_12 = new lib.Layer0();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-347.1,23.7,0.907,0.907);

	this.instance_13 = new lib.tube0٤();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-347.1,-97.5,0.366,0.294);

	this.instance_14 = new lib.tube0٤();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-182.8,-99.5,0.366,0.294);

	this.instance_15 = new lib.tube0٤();
	this.instance_15.parent = this;
	this.instance_15.setTransform(-268.9,-99.5,0.366,0.294);

	this.instance_16 = new lib.Final_lab_tools٣٢();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-329.5,123.4,0.907,0.907);

	this.instance_17 = new lib.tube0٢pngcopy();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-327.5,-91.7,0.366,0.294);

	this.instance_18 = new lib.tube0٢pngcopy();
	this.instance_18.parent = this;
	this.instance_18.setTransform(-163.3,-93.6,0.366,0.294);

	this.instance_19 = new lib.tube0٢pngcopy();
	this.instance_19.parent = this;
	this.instance_19.setTransform(-249.3,-93.6,0.366,0.294);

	this.shape_681 = new cjs.Shape();
	this.shape_681.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],102), null, new cjs.Matrix2D(0.366,0,0,0.294,-49.4,-134.7)).s().p("AntVDMAAAgqFIPbAAIAAGzIjYAAIAAJlIDYAAIAAZtg");
	this.shape_681.setTransform(-35.6,41.1);

	this.shape_682 = new cjs.Shape();
	this.shape_682.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],103), null, new cjs.Matrix2D(0.366,0,0,0.294,-61.5,-145.1)).s().p("ApmWsMAAAgtXITNAAIAAHuIhCAAIAAmzIvbAAMAAAAqFIPbAAIAA5tIBCAAIAAcEg");
	this.shape_682.setTransform(-41.1,45.7);

	this.instance_20 = new lib.Final_lab_tools٣٧pngcopy();
	this.instance_20.parent = this;
	this.instance_20.setTransform(-94,-30,1,0.886);

	this.shape_683 = new cjs.Shape();
	this.shape_683.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],70), null, new cjs.Matrix2D(1,0,0,0.886,-67,-57.6)).s().p("AqdJAIAAx/IU7AAIAACBIjEAAIAAMdIDEAAIAADhg");
	this.shape_683.setTransform(-55,-20.4);

	this.shape_684 = new cjs.Shape();
	this.shape_684.graphics.f().s("rgba(255,0,0,0)").ss(0.1,1,1).p("ANBhzIAPRPI6EAWIgb/NIaEgWIADD2");
	this.shape_684.setTransform(-39.4,22.7);

	this.shape_685 = new cjs.Shape();
	this.shape_685.graphics.f().s("#FF0000").ss(10.2,1,1).p("ABwgBQABBDggAxQgdArgoAGQgFAAgEAAQguAAgigvQgigwgBhEQAAhCAggxQAggwAvgBQAtAAAiAvQAiAwAABDg");
	this.shape_685.setTransform(-41.1,-8.1);

	this.shape_686 = new cjs.Shape();
	this.shape_686.graphics.f("#FF0000").s().p("AhNB1QgigwgBhEQAAhCAggxQAggwAvgBQAtAAAiAvQAiAwAABDQABBDggAxQgdArgoAGIgJAAIgBAAQgtAAgigvg");
	this.shape_686.setTransform(-41.1,-8.1);

	this.shape_687 = new cjs.Shape();
	this.shape_687.graphics.f("rgba(83,83,83,0.02)").s().p("AtPvbIaDgWIAED2Ip2AAIAAKIIJ/AAIAORPI6DAWgAgSnWQguAAghAxQggAwABBEQAABEAjAvQAhAwAvgBIAKAAQAngFAcgrQAhgxgBhEQgBhEgigvQghgvgtAAIgBAAg");
	this.shape_687.setTransform(-39.4,22.7);

	this.shape_688 = new cjs.Shape();
	this.shape_688.graphics.f().s("#FF0000").ss(10.2,1,1).p("AAKh8QBNAGA1ApQAvAjACAtQAAAFgBAFQAAABAAABQgFAzg5AgQg6AghNgGQhOgFg1gpQg0goAEgzQAEgzA5ghQA7ggBOAFg");
	this.shape_688.setTransform(-200.8,45.3);

	this.shape_689 = new cjs.Shape();
	this.shape_689.graphics.f("#FF0000").s().p("AgJB8QhOgFg1gpQg0goAEgzQAEgzA5ghQA7ggBOAFQBNAGA1ApQAvAjACAtIgBAKIAAACQgFAzg5AgQgyAbhAAAIgVgBg");
	this.shape_689.setTransform(-200.8,45.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_679}]},1).to({state:[]},1).to({state:[{t:this.shape_680}]},3).to({state:[]},1).to({state:[{t:this.shape_682},{t:this.shape_681},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12}]},19).to({state:[]},1).to({state:[{t:this.shape_683},{t:this.instance_20,p:{scaleX:1,scaleY:0.886,x:-94,y:-30}}]},45).to({state:[{t:this.shape_687},{t:this.shape_686},{t:this.shape_685},{t:this.shape_684}]},1).to({state:[{t:this.instance_20,p:{scaleX:1.243,scaleY:0.788,x:-97,y:69}}]},1).to({state:[{t:this.shape_689},{t:this.shape_688}]},4).wait(13));

	// Layer_3
	this.instance_21 = new lib.ClipGroup_1_0copy();
	this.instance_21.parent = this;
	this.instance_21.setTransform(-94.8,59.8,3.514,3.512,0,0,0,35.6,10.8);

	this.tabc_2 = new lib.Symbol1copy21();
	this.tabc_2.name = "tabc_2";
	this.tabc_2.parent = this;
	this.tabc_2.setTransform(-58.4,70.3,2.51,2.51,0,0,0,28.1,17.6);

	this.instance_22 = new lib.Symbol1copy12();
	this.instance_22.parent = this;
	this.instance_22.setTransform(-58.7,62.1,3.514,3.513,0,0,0,35.4,39);

	this.instance_23 = new lib.Symbol1copy13();
	this.instance_23.parent = this;
	this.instance_23.setTransform(-51.7,36.9,3.521,3.52,0,0,0,35.4,36.7);

	this.instance_24 = new lib.Group_2copy();
	this.instance_24.parent = this;
	this.instance_24.setTransform(-40.2,160.1,3.514,3.513,0,0,0,3.6,3.1);
	this.instance_24.alpha = 0.148;

	this.instance_25 = new lib.Group_3copy2();
	this.instance_25.parent = this;
	this.instance_25.setTransform(-143,160.3,3.514,3.513,0,0,0,4,3.1);
	this.instance_25.alpha = 0.148;

	this.instance_26 = new lib.Group_4copy2();
	this.instance_26.parent = this;
	this.instance_26.setTransform(-89.6,154.7,3.514,3.513,0,0,0,18.3,2.4);
	this.instance_26.alpha = 0.148;

	this.instance_27 = new lib.Group_5copy();
	this.instance_27.parent = this;
	this.instance_27.setTransform(-90.6,165.5,3.514,3.513,0,0,0,14.6,2.9);
	this.instance_27.alpha = 0.398;

	this.instance_28 = new lib.ClipGroup_7copy();
	this.instance_28.parent = this;
	this.instance_28.setTransform(-90.8,103.9,3.514,3.513,0,0,0,35.6,20.5);

	this.instance_29 = new lib.Group_6copy();
	this.instance_29.parent = this;
	this.instance_29.setTransform(-121.4,171.2,3.514,3.513,0,0,0,19.4,2.1);
	this.instance_29.alpha = 0.148;

	this.instance_30 = new lib.Group_7copy();
	this.instance_30.parent = this;
	this.instance_30.setTransform(-60.8,171.2,3.514,3.513,0,0,0,19.6,2.1);
	this.instance_30.alpha = 0.148;

	this.instance_31 = new lib.Symbol1copy14();
	this.instance_31.parent = this;
	this.instance_31.setTransform(-47.4,36.7,3.514,3.513,0,0,0,35.1,34);

	this.instance_32 = new lib.Symbol1copy16();
	this.instance_32.parent = this;
	this.instance_32.setTransform(-44.6,25.8,3.514,3.513,0,0,0,35.4,30.9);

	this.instance_33 = new lib.Symbol1copy17();
	this.instance_33.parent = this;
	this.instance_33.setTransform(-44.1,11,3.514,3.513,0,0,0,34.2,34);

	this.instance_34 = new lib.Symbol1copy18();
	this.instance_34.parent = this;
	this.instance_34.setTransform(-59.7,28.9,3.514,3.513,0,0,0,35.4,30.9);

	this.instance_35 = new lib.Symbol1copy19();
	this.instance_35.parent = this;
	this.instance_35.setTransform(-60.3,51.7,3.514,3.513,0,0,0,35.4,36.5);

	this.mekbar_1 = new lib.Symbol9();
	this.mekbar_1.name = "mekbar_1";
	this.mekbar_1.parent = this;
	this.mekbar_1.setTransform(-22.4,196.9,4.265,5.639,0,0,0,29.3,33);

	this.text_3 = new cjs.Text("HgO", "19px 'Arial'", "#FFFFFF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 23;
	this.text_3.lineWidth = 49;
	this.text_3.parent = this;
	this.text_3.setTransform(-76.9,56.6,3.015,3.015);

	this.shape_690 = new cjs.Shape();
	this.shape_690.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape_690.setTransform(-78.7,88.3,3.015,3.015);

	this.instance_36 = new lib.Front();
	this.instance_36.parent = this;
	this.instance_36.setTransform(-149,-71,3.019,3.018);

	this.instance_37 = new lib.Pathcopy();
	this.instance_37.parent = this;
	this.instance_37.setTransform(-72.1,-27.3,3.013,3.012,0,0,0,9,1.4);
	this.instance_37.alpha = 0.5;

	this.shape_691 = new cjs.Shape();
	this.shape_691.graphics.f("#42210B").s().p("AhEALQgdgEAAgHQAAgFAdgEQAdgFAnAAQAoAAAeAFQAcAEAAAFQAAAHgcAEQgdAEgpAAQgoAAgcgEg");
	this.shape_691.setTransform(-79.6,-22.5,3.013,3.012);

	this.instance_38 = new lib.Groupcopy2();
	this.instance_38.parent = this;
	this.instance_38.setTransform(-41.3,-62.2,3.013,3.012,0,0,0,3.8,15);
	this.instance_38.alpha = 0.5;

	this.shape_692 = new cjs.Shape();
	this.shape_692.graphics.f("#42210B").s().p("AhXCUIgBAAIgIgHIgCgDIgOj8QAAgOAhgKQAhgJAugBQAvABAhAJQAhAKAAAOIgPEAIgHAGg");
	this.shape_692.setTransform(-79.5,-65.6,3.013,3.012);

	this.instance_39 = new lib.Symbol42copy2();
	this.instance_39.parent = this;
	this.instance_39.setTransform(-76.1,106.1,3.019,3.018,0,0,0,22.8,25.5);
	this.instance_39.filters = [new cjs.ColorFilter(0.33, 0.33, 0.33, 1, 170.85, 0, 0, 0)];
	this.instance_39.cache(-2,-2,50,55);

	this.instance_40 = new lib.Mesh_0();
	this.instance_40.parent = this;
	this.instance_40.setTransform(-144,167.2,3.019,3.018);

	this.instance_41 = new lib.Mesh();
	this.instance_41.parent = this;
	this.instance_41.setTransform(-127.1,-56.7,3.019,3.018);

	this.instance_42 = new lib.Mesh_1();
	this.instance_42.parent = this;
	this.instance_42.setTransform(-147.3,-66,3.019,3.018);

	this.instance_43 = new lib.Mesh_2();
	this.instance_43.parent = this;
	this.instance_43.setTransform(-180.3,178.9,3.019,3.018);

	this.text_4 = new cjs.Text("3", "8px 'Arial'", "#FFFFFF");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 6;
	this.text_4.parent = this;
	this.text_4.setTransform(-24.9,104.5,2.988,2.989);

	this.text_5 = new cjs.Text("H  CO", "15px 'Arial'", "#FFFFFF");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.lineWidth = 49;
	this.text_5.parent = this;
	this.text_5.setTransform(-68.4,77,2.988,2.989);

	this.instance_44 = new lib.Symbol42();
	this.instance_44.parent = this;
	this.instance_44.setTransform(-67.6,123.3,2.989,2.989,0,0,0,22.8,25.5);
	this.instance_44.alpha = 0.379;
	this.instance_44.filters = [new cjs.ColorFilter(0.76953125, 1, 0.640625, 1, 0, 0, 0, 0)];
	this.instance_44.cache(-2,-2,50,55);

	this.shape_693 = new cjs.Shape();
	this.shape_693.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("Aq9UUMAAAgonIV7AAIAAAoIiNAAIAAIpICNAAIAAfWg");
	this.shape_693.setTransform(-67.6,82.5);

	this.shape_694 = new cjs.Shape();
	this.shape_694.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("Aq9UUMAAAgonIUeAAIAAJkIBdAAIAAfDg");
	this.shape_694.setTransform(-68,82.5);

	this.shape_695 = new cjs.Shape();
	this.shape_695.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("Aq9UUMAAAgonIV7AAIAADLIh4AAIAAF1IB4AAIAAfng");
	this.shape_695.setTransform(-67,82.5);

	this.shape_696 = new cjs.Shape();
	this.shape_696.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("Aq9UUMAAAgonIV7AAIAAAEIh4AAIAAI8IB4AAIAAfng");
	this.shape_696.setTransform(-68,82.5);

	this.instance_45 = new lib.Symbol41copy4();
	this.instance_45.parent = this;
	this.instance_45.setTransform(-68,66.4,2.989,2.989,0,0,0,34.5,51.1);

	this.instance_46 = new lib.Symbol41copy5();
	this.instance_46.parent = this;
	this.instance_46.setTransform(-67,66.4,2.989,2.989,0,0,0,34.5,51.1);

	this.instance_47 = new lib.Symbol42copy();
	this.instance_47.parent = this;
	this.instance_47.setTransform(-63.9,124.5,2.989,2.989,0,0,0,22.8,25.5);

	this.shape_697 = new cjs.Shape();
	this.shape_697.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],32), null, new cjs.Matrix2D(2.989,0,0,2.989,-103.1,-11.9)).s().p("AwGB4IAAjvIFGAAIAACvIV7AAIAAivIFMAAIAADvg");
	this.shape_697.setTransform(-64,208.5);

	this.shape_698 = new cjs.Shape();
	this.shape_698.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],29), null, new cjs.Matrix2D(2.989,0,0,2.989,-25.4,-103.1)).s().p("Aj9QHMAAAggNIH7AAMAAAAgNg");
	this.shape_698.setTransform(-89,66.4);

	this.shape_699 = new cjs.Shape();
	this.shape_699.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],31), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("Aq9UUIAAivMAAAgl4ITsAAIAAIaICPAAIAAdeIAACvgAn1NXIH7AAMAAAggOIn7AAg");
	this.shape_699.setTransform(-64.3,84);

	this.shape_700 = new cjs.Shape();
	this.shape_700.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.985,0,0,2.985,-70.1,-129.8)).s().p("Aq8USMAAAgojIV5AAIAAA6IhlAAIAAIPIBlAAIAAfag");
	this.shape_700.setTransform(-67.9,82.3);

	this.shape_701 = new cjs.Shape();
	this.shape_701.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.985,0,0,2.985,-70.1,-129.8)).s().p("Aq9USMAAAgojIV6AAIAAANIhrAAIAAJXIBrAAIAAe/g");
	this.shape_701.setTransform(-68.2,82.3);

	this.shape_702 = new cjs.Shape();
	this.shape_702.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.985,0,0,2.985,-70.1,-129.8)).s().p("Aq9USMAAAgojIV7AAIAAAEIh4AAIAAJYIB4AAIAAfHg");
	this.shape_702.setTransform(-68,82.3);

	this.becker_1 = new lib.Symbol29copy4();
	this.becker_1.name = "becker_1";
	this.becker_1.parent = this;
	this.becker_1.setTransform(-23.2,181.3,4.516,4.516,0,0,0,23.6,24.9);

	this.shape_703 = new cjs.Shape();
	this.shape_703.graphics.f("#FFFFFF").s().p("AglBEQgRgVAAgvQAAgdAHgSQAGgSAMgKQAMgKARAAQAOAAAKAGQAKAFAHAKQAGALAEAOQAEAPAAAYQAAAdgGATQgGASgMAKQgMAKgTAAQgXAAgOgSgAgWg4QgKAQAAAoQAAApAJAOQAKAOANAAQAOAAAKgOQAKgOAAgpQAAgpgKgNQgKgOgOAAQgNAAgJAMg");
	this.shape_703.setTransform(-161.1,91.6);

	this.shape_704 = new cjs.Shape();
	this.shape_704.graphics.f("#FFFFFF").s().p("AglBEQgRgVAAgvQAAgdAHgSQAGgSAMgKQAMgKARAAQAOAAAKAGQAKAFAHAKQAGALAEAOQAEAPAAAYQAAAdgGATQgGASgMAKQgMAKgTAAQgXAAgOgSgAgWg4QgKAQAAAoQAAApAJAOQAKAOANAAQAOAAAKgOQAKgOAAgpQAAgpgKgNQgKgOgOAAQgNAAgJAMg");
	this.shape_704.setTransform(-176.4,91.6);

	this.shape_705 = new cjs.Shape();
	this.shape_705.graphics.f("#FFFFFF").s().p("AgrBFQgJgFAAgHIABgFQACgEAHgIIALgMIgJgGQgCgDAAgEQAAgEADgFQADgGANgJQgKgEgGgJQgEgIAAgKQAAgQAMgLQALgLASAAQAOAAALAHIAXAAIAFAAIABABIABAEIgBAEIgBABIgFAAIgOAAQAGAJABAMQAAAPgMALQgLAKgSAAQgIAAgIgCIgHAGIgCAGQAAAAABABQAAAAAAABQAAAAABABQAAAAABABQABABAFABIAQABIAfACQAKABAHAHQAFAGAAAJQABANgMAMQgSAQgcAAQgWAAgPgKgAghAoQgDAFAAAEQAAAFAHAFQAMAHAUAAQAUAAAKgIQAKgHAAgIQAAgGgFgDQgHgCgRgBQgZAAgOgCIgIALgAgShCQgGAHABAOQAAASAHAKQAGAHAJAAQAIAAAGgGQAFgHAAgOQAAgSgHgKQgHgIgIAAQgIAAgGAHg");
	this.shape_705.setTransform(-126,89.9);

	this.shape_706 = new cjs.Shape();
	this.shape_706.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],10), null, new cjs.Matrix2D(0.699,0,0,0.699,-223.9,-222.2)).s().p("A7/M2IAA5rMAveAAAIAADdIIhAAIAAWOg");
	this.shape_706.setTransform(-135.8,69.8);

	this.instance_48 = new lib.Final_lab_tools٣١();
	this.instance_48.parent = this;
	this.instance_48.setTransform(-324,16,0.907,0.907);

	this.becker_1_1 = new lib.Symbol29copy5();
	this.becker_1_1.name = "becker_1_1";
	this.becker_1_1.parent = this;
	this.becker_1_1.setTransform(-23.2,181.3,4.516,4.516,0,0,0,23.6,24.9);

	this.shape_707 = new cjs.Shape();
	this.shape_707.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.822,-0.475,0.475,0.822,-463.3,2.8)).s().p("At0jYIAGgDIGJjjIAAAKIUpAAIAxBUIlTDEIwWJbg");
	this.shape_707.setTransform(110,103.6);

	this.shape_708 = new cjs.Shape();
	this.shape_708.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],9), null, new cjs.Matrix2D(0.95,0,0,0.95,-352.2,-279.4)).s().p("A2obkMAAAg3HIXAAAIAAGyIqAAAIAAEfIHRAAIAAHkIjRB5IAFAIIgFADIF/KXIQWpbIF8AAMAAAAhSg");
	this.shape_708.setTransform(57.7,124.7);

	this.shape_709 = new cjs.Shape();
	this.shape_709.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],97), null, new cjs.Matrix2D(1.222,0,0,1.222,-45.8,-176.6)).s().p("AnKbnMAAAgj8IFBAAIAAtIIlBAAIAAmJIOUAAMAAAA3Ng");
	this.shape_709.setTransform(21.9,72.7);

	this.shape_710 = new cjs.Shape();
	this.shape_710.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],11), null, new cjs.Matrix2D(-1.406,0,0,1.406,460.3,-494.9)).s().p("A9kcHIAA0YIN1AAMAAAgiHId1AAIAAhuIPfAAIAARjIs8AAIAAQVIM8AAIAAWVg");
	this.shape_710.setTransform(-120.1,-20.8);

	this.shape_711 = new cjs.Shape();
	this.shape_711.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],11), null, new cjs.Matrix2D(-1.406,0,0,1.406,416,-163.4)).s().p("AHLT0IAAmBIxLAAIAAnSIRLAAIAAm1I91AAIAAzfMAtUAAAIAAWAItiAAIAAH9IH3AAIAADYInyAAIAAGCINdAAIAAAQg");
	this.shape_711.setTransform(-75.9,-327.5);

	this.shape_712 = new cjs.Shape();
	this.shape_712.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],97), null, new cjs.Matrix2D(1.752,0,0,1.752,-65.6,-253.1)).s().p("EgKQAnjIAAvYIGMAAIAA7VImMAAIAAoyIHMAAIAAyzInMAAIAAozIUhAAMAAABPFg");
	this.shape_712.setTransform(40.7,-98.5);

	this.shape_713 = new cjs.Shape();
	this.shape_713.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],4), null, new cjs.Matrix2D(0.009,1,-1,0.009,260.6,-298.9)).s().p("AsJMUIE4gEIgBg7IAKAAMgAXgonIDWgCIAINJIAugBIABCGIApAAIABBwIBZgBIAAA2ICfgCIgBiqIAEAAIgIvKIDtgCMAAYAowIGwgDIAKR4I4JAOg");
	this.shape_713.setTransform(7.9,116.8);

	this.beaker_3 = new lib.Symbol29copy();
	this.beaker_3.name = "beaker_3";
	this.beaker_3.parent = this;
	this.beaker_3.setTransform(-16.8,194.9,4.829,4.829,0,0,0,24.3,23);

	this.instance_49 = new lib.Symbol31copy3();
	this.instance_49.parent = this;
	this.instance_49.setTransform(-214.2,165.8,4.127,4.127,0,0,0,64,38.3);

	this.shape_714 = new cjs.Shape();
	this.shape_714.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],80), null, new cjs.Matrix2D(1.423,0,0,1.363,-90.3,-115.1)).s().p("AuHSAMAAAggcIAAjiITbAAIAALXIAOAAIAABQIA0AAIAAA2IGkAAIAAg2IBOAAIAAXXg");
	this.shape_714.setTransform(-47.1,46.6);

	this.shape_715 = new cjs.Shape();
	this.shape_715.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],34), null, new cjs.Matrix2D(1.423,0,0,1.363,-115.2,-104.9)).s().p("AyAQZMAAAggxIGEAAMAAAAgbIcPAAIAA3WIBtAAIAAXsg");
	this.shape_715.setTransform(-61,59);

	this.instance_50 = new lib.Symbol31copy();
	this.instance_50.parent = this;
	this.instance_50.setTransform(-214.2,165.8,4.127,4.127,0,0,0,64,38.3);

	this.tabc_2_1 = new lib.Symbol1copy23();
	this.tabc_2_1.name = "tabc_2_1";
	this.tabc_2_1.parent = this;
	this.tabc_2_1.setTransform(-58.4,70.3,2.51,2.51,0,0,0,28.1,17.6);

	this.shape_716 = new cjs.Shape();
	this.shape_716.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],31), null, new cjs.Matrix2D(3.019,0,0,3.018,-70.9,-131.3)).s().p("ArEUhMAAAgpBIACAAITQAAIAAIKIC3AAIAAAGIAAcMIAADxIAAAxIAAADg");
	this.shape_716.setTransform(-60.3,88.5);

	this.shape_717 = new cjs.Shape();
	this.shape_717.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],30), null, new cjs.Matrix2D(3.019,0,0,3.018,-140.2,-12.1)).s().p("AgMB5IgEAAIAAjxIAEAAIAcAAIAADxg");
	this.shape_717.setTransform(12.3,202.5);

	this.shape_718 = new cjs.Shape();
	this.shape_718.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(3.019,0,0,3.018,-70.9,-131.3)).s().p("ALCUhIAAgxIAEAAIAAAxgALCP/IAA8MIAEAAIAAcMgArF0dIAAgDITQAAIAAADg");
	this.shape_718.setTransform(-60,88.2);

	this.shape_719 = new cjs.Shape();
	this.shape_719.graphics.f().s("#FF0000").ss(2,1,1).p("AAoMyIhP5j");
	this.shape_719.setTransform(10.5,181.2);

	this.shape_720 = new cjs.Shape();
	this.shape_720.graphics.f("rgba(51,51,51,0.02)").s().p("AwkufIGtohILQAAIPMf1QpoCGoxMGgAkl1sMAB9AkcQBkCBCAiNQhgxygbypQg3gjg2AAQg+AAg7Aug");
	this.shape_720.setTransform(20.8,165.1);

	this.shape_721 = new cjs.Shape();
	this.shape_721.graphics.lf(["#5C97B9","#EBF6F7","#5D99BC"],[0,0.463,1],11.3,-2,-11.6,-0.8).s().p("Ag0SHMgB8gkcQBuhXB3BLQAbSpBhRzQhEBKg7AAQg2AAgwg+gAA1SqIhP5jg");
	this.shape_721.setTransform(9.2,143.6);

	this.shape_722 = new cjs.Shape();
	this.shape_722.graphics.f("#3333FF").s().p("AiFmOIENg0IAAL4IkPCNg");
	this.shape_722.setTransform(20.7,80.2);

	this.shape_723 = new cjs.Shape();
	this.shape_723.graphics.f("#FF0000").s().p("AiFmKIENg8IAAMAIkPCNg");
	this.shape_723.setTransform(20.7,79.8);

	this.shape_724 = new cjs.Shape();
	this.shape_724.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],69), null, new cjs.Matrix2D(1,0,0,0.886,-84,-122.3)).s().p("AtHTHMAAAgmNIVJAAIAAGNIFGAAMAAAAgAg");
	this.shape_724.setTransform(-59,97.3);

	this.shape_725 = new cjs.Shape();
	this.shape_725.graphics.f().s("#999999").ss(7.6,1,1).p("AgBlpIADLT");
	this.shape_725.setTransform(-39.7,44.5);

	this.instance_51 = new lib.Tween20("synched",0);
	this.instance_51.parent = this;
	this.instance_51.setTransform(-46.5,146.5,1,2.038);
	this.instance_51._off = true;

	this.instance_52 = new lib.Tween21("synched",0);
	this.instance_52.parent = this;
	this.instance_52.setTransform(-46.5,210,1,0.022);

	this.shape_726 = new cjs.Shape();
	this.shape_726.graphics.f().s("#999999").ss(19.4,1,1).p("Arlg7IXLB3");
	this.shape_726.setTransform(-107.2,54.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21,p:{scaleY:3.512,x:-94.8,y:59.8}}]},1).to({state:[{t:this.tabc_2}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_30},{t:this.instance_29},{t:this.instance_21,p:{scaleY:3.513,x:-91.5,y:51.9}},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.mekbar_1}]},1).to({state:[{t:this.instance_43,p:{scaleX:3.019,scaleY:3.018,rotation:0,x:-180.3,y:178.9}},{t:this.instance_42,p:{scaleX:3.019,scaleY:3.018,rotation:0,x:-147.3,y:-66}},{t:this.instance_41,p:{scaleX:3.019,scaleY:3.018,rotation:0,x:-127.1,y:-56.7}},{t:this.instance_40,p:{scaleX:3.019,scaleY:3.018,x:-144,y:167.2,rotation:0}},{t:this.instance_39},{t:this.shape_692,p:{scaleX:3.013,scaleY:3.012,x:-79.5,y:-65.6}},{t:this.instance_38,p:{regX:3.8,regY:15,scaleX:3.013,scaleY:3.012,x:-41.3,y:-62.2}},{t:this.shape_691,p:{scaleX:3.013,scaleY:3.012,x:-79.6,y:-22.5}},{t:this.instance_37,p:{regX:9,regY:1.4,scaleX:3.013,scaleY:3.012,x:-72.1,y:-27.3}},{t:this.instance_36},{t:this.shape_690,p:{scaleX:3.015,scaleY:3.015,x:-78.7,y:88.3}},{t:this.text_3,p:{scaleX:3.015,scaleY:3.015,x:-76.9,y:56.6,text:"HgO",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.shape_693},{t:this.instance_40,p:{scaleX:2.989,scaleY:2.989,x:-134.8,y:183.8,rotation:0}},{t:this.instance_44,p:{x:-67.6,alpha:0.379,scaleX:2.989,scaleY:2.989,y:123.3}},{t:this.shape_690,p:{scaleX:2.988,scaleY:2.989,x:-68.2,y:107.3}},{t:this.text_5,p:{scaleX:2.988,scaleY:2.989,x:-68.4,y:77,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49}},{t:this.text_4,p:{x:-24.9,y:104.5,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.988,scaleY:2.989}},{t:this.text_3,p:{scaleX:2.988,scaleY:2.989,x:-82,y:110.3,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}}]},1).to({state:[{t:this.shape_694},{t:this.instance_44,p:{x:-67.9,alpha:0.93,scaleX:2.989,scaleY:2.989,y:123.3}},{t:this.shape_690,p:{scaleX:2.988,scaleY:2.989,x:-68.6,y:107.3}},{t:this.text_3,p:{scaleX:2.988,scaleY:2.989,x:-68.8,y:75.8,text:"NaOH",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.shape_695},{t:this.instance_44,p:{x:-67,alpha:0.719,scaleX:2.989,scaleY:2.989,y:123.3}},{t:this.shape_690,p:{scaleX:2.988,scaleY:2.989,x:-67.6,y:107.3}},{t:this.text_4,p:{x:-67.8,y:76.2,text:"Ca(OH)",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49,scaleX:2.988,scaleY:2.989}},{t:this.text_3,p:{scaleX:2.988,scaleY:2.989,x:-0.4,y:124.8,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}}]},1).to({state:[{t:this.shape_696},{t:this.instance_44,p:{x:-67.9,alpha:1,scaleX:2.989,scaleY:2.989,y:123.3}},{t:this.shape_690,p:{scaleX:2.988,scaleY:2.989,x:-68.6,y:107.3}},{t:this.text_3,p:{scaleX:2.988,scaleY:2.989,x:-68.8,y:77.1,text:"KOH",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.shape_699},{t:this.shape_698},{t:this.shape_697},{t:this.instance_40,p:{scaleX:2.989,scaleY:2.989,x:-131.2,y:185,rotation:0}},{t:this.instance_47},{t:this.shape_692,p:{scaleX:2.985,scaleY:2.984,x:-67.2,y:-42.1}},{t:this.instance_38,p:{regX:3,regY:14.7,scaleX:2.985,scaleY:2.984,x:-32.8,y:-45.7}},{t:this.shape_691,p:{scaleX:2.985,scaleY:2.984,x:-67.3,y:0.5}},{t:this.instance_37,p:{regX:8.7,regY:1.9,scaleX:2.985,scaleY:2.984,x:-62.5,y:-2.3}},{t:this.shape_690,p:{scaleX:2.987,scaleY:2.987,x:-62.6,y:111.3}},{t:this.text_4,p:{x:-60.3,y:71.2,text:"HCl",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49,scaleX:2.987,scaleY:2.987}},{t:this.text_3,p:{scaleX:2.987,scaleY:2.987,x:-63.6,y:111.4,text:"مخفف",font:"8px 'Arial'",lineHeight:10.9,lineWidth:19}}]},1).to({state:[{t:this.shape_700},{t:this.instance_44,p:{x:-67.9,alpha:1,scaleX:2.985,scaleY:2.985,y:123}},{t:this.shape_690,p:{scaleX:2.985,scaleY:2.984,x:-67.2,y:105.9}},{t:this.text_3,p:{scaleX:2.985,scaleY:2.984,x:-67.7,y:72.2,text:"HBr",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.shape_701},{t:this.instance_44,p:{x:-68.2,alpha:1,scaleX:2.985,scaleY:2.985,y:123}},{t:this.shape_690,p:{scaleX:2.985,scaleY:2.984,x:-67.5,y:105.8}},{t:this.text_4,p:{x:-68,y:70.1,text:"HNO",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49,scaleX:2.985,scaleY:2.776}},{t:this.text_3,p:{scaleX:2.985,scaleY:2.776,x:-24.1,y:112.1,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}}]},1).to({state:[{t:this.shape_702},{t:this.instance_44,p:{x:-68,alpha:1,scaleX:2.985,scaleY:2.985,y:123}},{t:this.shape_690,p:{scaleX:2.985,scaleY:2.984,x:-68.3,y:105.8}},{t:this.text_5,p:{scaleX:2.985,scaleY:2.984,x:-23.9,y:106,text:"4",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.text_4,p:{x:-85.5,y:106,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.985,scaleY:2.984}},{t:this.text_3,p:{scaleX:2.985,scaleY:2.984,x:-66.5,y:66,text:"H SO",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.becker_1}]},1).to({state:[{t:this.shape_706},{t:this.shape_705},{t:this.shape_704},{t:this.shape_703}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.becker_1_1}]},1).to({state:[{t:this.shape_708},{t:this.shape_707}]},1).to({state:[{t:this.shape_709}]},1).to({state:[{t:this.shape_711},{t:this.shape_710}]},1).to({state:[{t:this.shape_712}]},1).to({state:[{t:this.shape_713}]},1).to({state:[{t:this.beaker_3}]},1).to({state:[{t:this.instance_49}]},1).to({state:[{t:this.shape_715},{t:this.shape_714}]},1).to({state:[{t:this.mekbar_1}]},1).to({state:[{t:this.instance_50}]},1).to({state:[{t:this.tabc_2_1}]},1).to({state:[{t:this.instance_43,p:{scaleX:1.716,scaleY:2.214,rotation:-90,x:295,y:24.1}},{t:this.instance_42,p:{scaleX:1.716,scaleY:2.214,rotation:-90,x:114.5,y:10.4}},{t:this.instance_41,p:{scaleX:1.716,scaleY:2.214,rotation:-90,x:121.7,y:2.8}},{t:this.instance_40,p:{scaleX:1.717,scaleY:2.217,x:292.4,y:5.9,rotation:-90}}]},1).to({state:[{t:this.shape_718},{t:this.shape_717},{t:this.shape_716},{t:this.instance_43,p:{scaleX:3.019,scaleY:3.018,rotation:0,x:-164.2,y:202.1}},{t:this.instance_41,p:{scaleX:3.019,scaleY:3.018,rotation:0,x:-111,y:-33.5}}]},1).to({state:[{t:this.shape_721},{t:this.shape_720},{t:this.shape_719}]},1).to({state:[]},1).to({state:[{t:this.shape_722}]},10).to({state:[{t:this.shape_723}]},1).to({state:[]},1).to({state:[{t:this.shape_724}]},18).to({state:[{t:this.shape_725}]},1).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_52}]},3).to({state:[{t:this.shape_726}]},1).wait(13));
	this.timeline.addTween(cjs.Tween.get(this.instance_51).wait(73).to({_off:false},0).to({_off:true,scaleY:0.02,y:210},3).wait(14));

	// Symbol_41_copy_2
	this.instance_53 = new lib.Pathcopy();
	this.instance_53.parent = this;
	this.instance_53.setTransform(-69.4,-1.1,2.988,2.988,0,0,0,8.2,0.7);
	this.instance_53.alpha = 0.5;

	this.shape_727 = new cjs.Shape();
	this.shape_727.graphics.f("#42210B").s().p("AhEALQgdgEAAgHQAAgFAdgEQAdgFAnAAQAoAAAeAFQAcAEAAAFQAAAHgcAEQgdAEgpAAQgoAAgcgEg");
	this.shape_727.setTransform(-70,0.4,2.988,2.988);

	this.instance_54 = new lib.Groupcopy2();
	this.instance_54.parent = this;
	this.instance_54.setTransform(-40.4,-42.6,2.988,2.988,0,0,0,2.3,14.6);
	this.instance_54.alpha = 0.5;

	this.shape_728 = new cjs.Shape();
	this.shape_728.graphics.f("#42210B").s().p("AhXCUIgBAAIgIgHIgCgDIgOj8QAAgOAhgKQAhgJAugBQAvABAhAJQAhAKAAAOIgPEAIgHAGg");
	this.shape_728.setTransform(-69.9,-42.3,2.988,2.988);

	this.text_6 = new cjs.Text("2", "8px 'Arial'", "#FFFFFF");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 6;
	this.text_6.parent = this;
	this.text_6.setTransform(-81.5,113.7,2.988,2.988);

	this.text_7 = new cjs.Text("3", "8px 'Arial'", "#FFFFFF");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 6;
	this.text_7.parent = this;
	this.text_7.setTransform(-24.5,107.9,2.988,2.988);

	this.text_8 = new cjs.Text("H  CO", "15px 'Arial'", "#FFFFFF");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.lineWidth = 49;
	this.text_8.parent = this;
	this.text_8.setTransform(-68,80.3,2.988,2.988);

	this.shape_729 = new cjs.Shape();
	this.shape_729.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape_729.setTransform(-68.2,110.1,2.988,2.988);

	this.instance_55 = new lib.Symbol42();
	this.instance_55.parent = this;
	this.instance_55.setTransform(-67.1,127.3,2.989,2.989,0,0,0,22.8,25.5);
	this.instance_55.alpha = 0.379;
	this.instance_55.filters = [new cjs.ColorFilter(0.76953125, 1, 0.640625, 1, 0, 0, 0, 0)];
	this.instance_55.cache(-2,-2,50,55);

	this.instance_56 = new lib.Mesh_0();
	this.instance_56.parent = this;
	this.instance_56.setTransform(-134,188,2.989,2.989);

	this.instance_57 = new lib.Mesh();
	this.instance_57.parent = this;
	this.instance_57.setTransform(-118,-34,2.989,2.989);

	this.instance_58 = new lib.Mesh_2();
	this.instance_58.parent = this;
	this.instance_58.setTransform(-170,199,2.989,2.989);

	this.shape_730 = new cjs.Shape();
	this.shape_730.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],31), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("Aq9UUMAAAgonIADAAITnAAIAAIkICRAAIAAAQIAAfwIAAADg");
	this.shape_730.setTransform(-67.5,86.8);

	this.shape_731 = new cjs.Shape();
	this.shape_731.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],76), null, new cjs.Matrix2D(2.989,0,0,2.989,-70.2,-130)).s().p("AK7UUIAA/wIADAAIAAfwgAq90QIAAgDITnAAIAAADg");
	this.shape_731.setTransform(-67.2,86.5);

	this.text_9 = new cjs.Text("H  CO", "15px 'Arial'", "#FFFFFF");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.lineWidth = 49;
	this.text_9.parent = this;
	this.text_9.setTransform(-68,80.3,2.988,2.988);

	this.shape_732 = new cjs.Shape();
	this.shape_732.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape_732.setTransform(-68.2,110.1,2.988,2.988);

	this.text_10 = new cjs.Text("H  CO", "15px 'Arial'", "#FFFFFF");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.lineWidth = 49;
	this.text_10.parent = this;
	this.text_10.setTransform(-68,80.3,2.988,2.988);

	this.text_11 = new cjs.Text("H  CO", "15px 'Arial'", "#FFFFFF");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.lineWidth = 49;
	this.text_11.parent = this;
	this.text_11.setTransform(-68,80.3,2.988,2.988);

	this.shape_733 = new cjs.Shape();
	this.shape_733.graphics.f("#FF0000").s().p("AiwKlIAA1JIFhAAIAAVJg");
	this.shape_733.setTransform(20.8,50.9,0.87,1,0,0,-28.3);

	this.shape_734 = new cjs.Shape();
	this.shape_734.graphics.f("#0099CC").s().p("AiwKlIAA1JIFhAAIAAVJg");
	this.shape_734.setTransform(20.8,50.9,0.87,1,0,0,-28.3);

	this.red_paper = new lib.Symbolr1();
	this.red_paper.name = "red_paper";
	this.red_paper.parent = this;
	this.red_paper.setTransform(-64.1,99.2,3.98,3.98,0,0,0,23.4,20.7);

	this.blu_paper = new lib.Symbolb1();
	this.blu_paper.name = "blu_paper";
	this.blu_paper.parent = this;
	this.blu_paper.setTransform(-44.8,102.7,3.98,3.98,0,0,0,23.4,20.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_728},{t:this.instance_54},{t:this.shape_727},{t:this.instance_53}]},13).to({state:[]},10).to({state:[{t:this.shape_731},{t:this.shape_730},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_729,p:{scaleX:2.988,scaleY:2.988,x:-68.2,y:110.1}},{t:this.text_8,p:{x:-68,y:80.3,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49,scaleX:2.988,scaleY:2.988}},{t:this.text_7,p:{x:-24.5,y:107.9,text:"3",scaleX:2.988,scaleY:2.988,font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.text_6,p:{scaleX:2.988,scaleY:2.988,x:-81.5,y:113.7,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}}]},18).to({state:[{t:this.shape_730},{t:this.shape_731},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_732},{t:this.text_9,p:{x:-68,y:80.3,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49}},{t:this.text_8,p:{x:-24.5,y:107.9,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.988,scaleY:2.988}},{t:this.text_7,p:{x:-81.5,y:113.7,text:"2",scaleX:2.988,scaleY:2.988,font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.shape_729,p:{scaleX:2.938,scaleY:2.938,x:-66.7,y:112.6}},{t:this.text_6,p:{scaleX:2.938,scaleY:2.938,x:-65.9,y:80.9,text:"NaOH",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.shape_730},{t:this.shape_731},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_732},{t:this.text_10,p:{x:-68,y:80.3,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49}},{t:this.text_9,p:{x:-24.5,y:107.9,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.text_8,p:{x:-81.5,y:113.7,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.988,scaleY:2.988}},{t:this.shape_729,p:{scaleX:2.749,scaleY:2.749,x:-68.6,y:109.8}},{t:this.text_7,p:{x:-69.4,y:81,text:"Ca(OH)",scaleX:2.749,scaleY:2.749,font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}},{t:this.text_6,p:{scaleX:2.749,scaleY:2.749,x:-7.4,y:125.8,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}}]},1).to({state:[{t:this.shape_730},{t:this.shape_731},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_732},{t:this.text_9,p:{x:-68,y:80.3,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49}},{t:this.text_8,p:{x:-24.5,y:107.9,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.988,scaleY:2.988}},{t:this.text_7,p:{x:-81.5,y:113.7,text:"2",scaleX:2.988,scaleY:2.988,font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.shape_729,p:{scaleX:2.783,scaleY:2.783,x:-67.4,y:109.9}},{t:this.text_6,p:{scaleX:2.783,scaleY:2.783,x:-66.7,y:82,text:"KOH",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.shape_730},{t:this.shape_731},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_732},{t:this.text_9,p:{x:-68,y:80.3,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49}},{t:this.text_8,p:{x:-24.5,y:107.9,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.988,scaleY:2.988}},{t:this.text_7,p:{x:-81.5,y:113.7,text:"2",scaleX:2.988,scaleY:2.988,font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.shape_729,p:{scaleX:2.988,scaleY:2.987,x:-67.7,y:112}},{t:this.text_6,p:{scaleX:2.988,scaleY:2.987,x:-66.4,y:74.4,text:"HCl",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.shape_730},{t:this.shape_731},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_732},{t:this.text_9,p:{x:-68,y:80.3,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49}},{t:this.text_8,p:{x:-24.5,y:107.9,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.988,scaleY:2.988}},{t:this.text_7,p:{x:-81.5,y:113.7,text:"2",scaleX:2.988,scaleY:2.988,font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.shape_729,p:{scaleX:2.984,scaleY:3.148,x:-67.7,y:111}},{t:this.text_6,p:{scaleX:2.984,scaleY:3.148,x:-68.1,y:75.6,text:"HBr",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[{t:this.shape_730},{t:this.shape_731},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_732},{t:this.text_10,p:{x:-68,y:80.3,text:"H  CO",font:"15px 'Arial'",lineHeight:18.8,lineWidth:49}},{t:this.text_9,p:{x:-24.5,y:107.9,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.text_8,p:{x:-81.5,y:113.7,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:2.988,scaleY:2.988}},{t:this.shape_729,p:{scaleX:2.983,scaleY:2.983,x:-68.6,y:107.5}},{t:this.text_7,p:{x:-68.1,y:72.4,text:"HNO",scaleX:2.983,scaleY:2.775,font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}},{t:this.text_6,p:{scaleX:2.983,scaleY:2.775,x:-23.2,y:114.3,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}}]},1).to({state:[{t:this.shape_730},{t:this.shape_731},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.shape_732},{t:this.text_11},{t:this.text_10,p:{x:-24.5,y:107.9,text:"3",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.text_9,p:{x:-81.5,y:113.7,text:"2",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.shape_729,p:{scaleX:3.002,scaleY:3.002,x:-69.6,y:111.6}},{t:this.text_8,p:{x:-22.8,y:110,text:"4",font:"8px 'Arial'",lineHeight:10.9,lineWidth:6,scaleX:3.002,scaleY:3.002}},{t:this.text_7,p:{x:-84.8,y:110,text:"2",scaleX:3.002,scaleY:3.002,font:"8px 'Arial'",lineHeight:10.9,lineWidth:6}},{t:this.text_6,p:{scaleX:3.002,scaleY:3.002,x:-65.8,y:69.8,text:"H SO",font:"19px 'Arial'",lineHeight:23.25,lineWidth:49}}]},1).to({state:[]},1).to({state:[{t:this.shape_733}]},1).to({state:[{t:this.shape_733}]},1).to({state:[{t:this.shape_734}]},1).to({state:[{t:this.shape_734}]},1).to({state:[]},1).to({state:[{t:this.red_paper}]},6).to({state:[{t:this.blu_paper}]},1).to({state:[]},1).wait(28));

	// Symbol_41_copy_2
	this.shape_735 = new cjs.Shape();
	this.shape_735.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],8), null, new cjs.Matrix2D(0.98,0.421,-0.421,0.98,-104.8,-192)).s().p("A+WD5IDMAAIAAhcIEdAAIAAiGIOgAAIAAxwItkAAICumVIRTAAMAgHANyMgOeAhrg");
	this.shape_735.setTransform(63,167.3);
	this.shape_735._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_735).wait(72).to({_off:false},0).to({_off:true},5).wait(13));

	// Layer_5
	this.shape_736 = new cjs.Shape();
	this.shape_736.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.952,0.305,-0.305,0.952,-345.5,-482.1)).s().p("AgdFiQABgWgGgXQgLgvgsg7QgGgJgHgEQgKgEgGAFQgLgRgVgOQgOgJgagNIgxgWIghg7IgoAYIhSgjQgtgRgRgKQgKgGgjgWIi0iEQhIg0gjgdQhphUhShiQgOgPACgLQABgKARgLIBNgzQArgbAPgXQASgXABggIAtgaImZq3ICZhaIgIgMICHhQIAIANIAACqIBEAAIAAAUIAsAAIDZFxIAxgdQAFAIANAGQAKAEAXAAIAmACQAcACAMgGQAUACAbAHQAeAJAOACQA4ANAlgHQAhgMAQgCIAVAAIAUAAQAZgFANABQAOACAIAAQAKAAASgJIFhJaICIhQILJS8IoSLXg");
	this.shape_736.setTransform(134.8,173.5);

	this.shape_737 = new cjs.Shape();
	this.shape_737.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-359.9,-263.9)).s().p("AjeEKIoIAAIARhfIADgTIBKmhIH4AAIN3CcIAAF3g");
	this.shape_737.setTransform(11.4,45.9);

	this.shape_738 = new cjs.Shape();
	this.shape_738.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-372.8,-327.8)).s().p("AjmANIAAgZIHNAAIAAAZg");
	this.shape_738.setTransform(16,98.4);

	this.shape_739 = new cjs.Shape();
	this.shape_739.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-431.1,-432.7)).s().p("ADFTiIAAyCImpAAIAApEIpvAAIAAiRIH9AAIAAmwIgIAAInPAAIgmAAIAAj2IPFAAIAcAAIAAgpIBPAAIAAGeIFvAAIAAHCIFkAAIAAE0IICAAIkZY/gA2x17IADgSIBnAAIgDASg");
	this.shape_739.setTransform(74.3,203.4);

	this.shape_740 = new cjs.Shape();
	this.shape_740.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-431.1,-432.7)).s().p("ADFTjIAAyEImpAAIAApDIpvAAIAAiRIH8AAIAAmwIgIAAIAAAaInOAAIAAgaIgmAAIAAj3IPFAAIAbAAIAAgoIBQAAIAAGeIFvAAIAAHCIFkAAIAAE0IICAAIkZY/gA2x16IAEgTIBmAAIgDATg");
	this.shape_740.setTransform(104.3,-148.3);

	this.shape_741 = new cjs.Shape();
	this.shape_741.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-359.9,-259.6)).s().p("AjeE1IoIAAIARhfIADgTIBZn2IAIAAIVYDwIAAF4g");
	this.shape_741.setTransform(11.4,41.7);

	this.shape_742 = new cjs.Shape();
	this.shape_742.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-431.1,-401.8)).s().p("ADFYXIAAyCImpAAIAApEIpvAAIAAiRIH9AAIAAmwIgIAAInPAAIgmAAIAAj2IPFAAIAcAAIAAgpIBPAAIAAGeIFvAAIAAHCIFkAAIAAE0IICAAIkZY/gA2xxFIADgTIBnAAIgDATgA1B7BIAAgCIAJACg");
	this.shape_742.setTransform(74.3,172.4);

	this.shape_743 = new cjs.Shape();
	this.shape_743.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],5), null, new cjs.Matrix2D(0.952,0.394,-0.305,1.227,-264.3,-574)).s().p("ABNDvIgQgQIgQgPIgVgWIgLgLQhRhWhEhhIgbgoQgNgTABgPQACgNAQgNIBNhCQAjgcARgYIAHgMICgAAIAAAMIAlAAIAADaIglAAIAAD3g");
	this.shape_743.setTransform(233.4,3.3);

	this.shape_744 = new cjs.Shape();
	this.shape_744.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-359.9,-263.1)).s().p("AjeESIoIAAIARhfIADgTIBMmxIGeAAIPPCrIAAF4g");
	this.shape_744.setTransform(11.4,45.1);

	this.shape_745 = new cjs.Shape();
	this.shape_745.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.187,-0.508,0.11,0.862,-89.9,-30.7)).s().p("AgBgHIABgJIACAQIgDARg");
	this.shape_745.setTransform(7,4.9);

	this.shape_746 = new cjs.Shape();
	this.shape_746.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.431,-0.508,0.254,0.862,-237.1,-21.7)).s().p("AgGAAIAUgOIAAARIAAAAIgLATgAgNgQIACgFIgCAGg");
	this.shape_746.setTransform(22.7,-4.1);

	this.shape_747 = new cjs.Shape();
	this.shape_747.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.7,-0.508,0.412,0.862,-393.5,-9.8)).s().p("Ag1B0IgFAFIAAgSIAXgSIAAAwIgDADgAgCgsIAAAAIA9hbIAABbg");
	this.shape_747.setTransform(30,-15.9);

	this.shape_748 = new cjs.Shape();
	this.shape_748.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.845,-0.642,0.256,0.767,-390.3,79.6)).s().p("AgIgVIABgCIAfAAIAAAAIgvAvg");
	this.shape_748.setTransform(27.3,-18.1);

	this.shape_749 = new cjs.Shape();
	this.shape_749.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(1.038,-0.508,0.209,0.862,-495,-36.5)).s().p("AhzDLIDniZIhBC9IhvBJgAgyk3IBaAAIABAAIh3BOg");
	this.shape_749.setTransform(41,10.8);

	this.shape_750 = new cjs.Shape();
	this.shape_750.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.876,-0.508,0.114,0.862,-390.1,-13.8)).s().p("AhIBCIABgEIACgFIAahJIAHgVIAvgvIA+AAIABAAIgcBOIhDAzIgWASIgVAQIgIAGg");
	this.shape_750.setTransform(28.6,-11.9);

	this.shape_751 = new cjs.Shape();
	this.shape_751.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.273,-0.642,0.229,0.767,-145.5,83.8)).s().p("AgRHwIgYhNIghoyIB4kbIAdhFIAAK5IAAACIAAATIAAAPIhMECg");
	this.shape_751.setTransform(13.7,-25.7);

	this.shape_752 = new cjs.Shape();
	this.shape_752.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.767,-0.642,0.642,0.767,-472.9,130.2)).s().p("AiliTIhkAAIgXAAIEij0IDtDJIAzAqInHIcg");
	this.shape_752.setTransform(52.4,-68.7);

	this.shape_753 = new cjs.Shape();
	this.shape_753.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.383,-0.642,0.321,0.767,-211.4,87.4)).s().p("AheIUIAXAAIgLAagABCnuIgeBFIAAgjIA6hhIABgBIAAKoIgaBKIgCAFIgBADg");
	this.shape_753.setTransform(14.6,-25.8);

	this.shape_754 = new cjs.Shape();
	this.shape_754.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.623,-0.642,0.522,0.767,-364.7,110.1)).s().p("Ag5lKIgBABIAAgBIASgSIBjAAIAAIaIg9BbIggAAIgBAAIAAACIgPAuIgHAUg");
	this.shape_754.setTransform(30,-48.6);

	this.shape_755 = new cjs.Shape();
	this.shape_755.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.862,-0.508,0.508,0.862,-641.2,-32.1)).s().p("AhvB2IlEEUIl6m5ImDFKIAAgcIAfAAIAAi8ICwiVIkZlKIgGAGIASAUIiLB3IhcAAIgBAAIAAhbIHIodIgzgqIgCgDIA9g0IENE7IEXjuIEjFWIEOjnIDIDrIGIlNIM3V2ItZH5g");
	this.shape_755.setTransform(185.3,6.4);

	this.shape_756 = new cjs.Shape();
	this.shape_756.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],12), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-431.1,-401.8)).s().p("ADFYXIAAyCImpAAIAApEIpvAAIAAiRIH9AAIAAmwIgIAAIAAAaInPAAIAAgaIgmAAIAAj2IPFAAIAcAAIAAgpIBPAAIAAGeIFvAAIAAHCIFkAAIAAE0IICAAIkZY/gA2xxFIADgTIBnAAIgDATgA1B7BIAAgCIAJACg");
	this.shape_756.setTransform(74.3,172.4);

	this.shape_757 = new cjs.Shape();
	this.shape_757.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["RECOVER_RECOVER_exper_1_1_5_atlas_"],8), null, new cjs.Matrix2D(0.98,0.421,-0.421,0.98,-103.2,-192)).s().p("A+lDtIChl4IAACiIUGAAIAAxwItjAAICtmVIRTAAMAgHANyMgOdAhrg");
	this.shape_757.setTransform(61.5,167.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_736}]}).to({state:[{t:this.shape_739},{t:this.shape_738},{t:this.shape_737,p:{x:11.4,y:45.9}}]},1).to({state:[{t:this.shape_740},{t:this.shape_737,p:{x:41.4,y:-305.8}}]},29).to({state:[{t:this.shape_742},{t:this.shape_738},{t:this.shape_741}]},1).to({state:[{t:this.shape_743}]},7).to({state:[{t:this.shape_739},{t:this.shape_738},{t:this.shape_744}]},1).to({state:[]},10).to({state:[{t:this.shape_755},{t:this.shape_754},{t:this.shape_753},{t:this.shape_752},{t:this.shape_751},{t:this.shape_750},{t:this.shape_749},{t:this.shape_748},{t:this.shape_747},{t:this.shape_746},{t:this.shape_745}]},1).to({state:[{t:this.shape_756},{t:this.shape_741}]},10).to({state:[{t:this.shape_757}]},11).to({state:[{t:this.shape_757}]},2).to({state:[{t:this.shape_757}]},1).to({state:[]},13).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(16.8,22.4,236,302.2);


(lib.Scene_1_Layer_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.myhand = new lib.Symbol4copy2();
	this.myhand.name = "myhand";
	this.myhand.parent = this;
	this.myhand.setTransform(750.5,358.2,0.296,0.289,0,0,0,0.1,0.4);

	this.timeline.addTween(cjs.Tween.get(this.myhand).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_7, null, null);


// stage content:
(lib.RECOVER_RECOVER_exper_1_1_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_0 = function() {
		this.myhand = this.Layer_7.myhand;
		this.sett_en = this.setting_En.sett_en;
		this.sett = this.setting_ar.sett;
		this.intro_en = this.introd_En.intro_en;
		this.intro_ar = this.introd.intro_ar;
		this.upButton = this.Layer_3.upButton;
		this.resetButton3 = this.Layer_3.resetButton3;
		this.resetButton2 = this.Layer_3.resetButton2;
		this.myput_2 = this.Layer_15.myput_2;
		this.myput_3 = this.Layer_15.myput_3;
		this.myput_4 = this.Layer_15.myput_4;
		this.myput_5 = this.Layer_15.myput_5;
		this.coode_1 = this.tools_3.coode_1;
		this.hhml_12 = this.tools_3.hhml_12;
		this.myhod2 = this.tools_3.myhod2;
		this.becker_2 = this.tools_3.becker_2;
		this.arrow_1 = this.tools_3.arrow_1;
		this.arrow_6 = this.tools_3.arrow_6;
		this.arrow_2 = this.tools_3.arrow_2;
		this.arrow_3 = this.tools_3.arrow_3;
		this.arrow_5 = this.tools_3.arrow_5;
		this.arrow_4 = this.tools_3.arrow_4;
		this.hhml_22 = this.tools_3.hhml_22;
		this.myhod3 = this.tools_3.myhod3;
		this.arrow_7 = this.tools_3.arrow_7;
		this.emptyice = this.tools_3.emptyice;
		this.hanfi_1 = this.hanfia.hanfi_1;
		this.lahb_1 = this.tools_3_1.lahb_1;
		this.term_0 = this.tools_3_1.term_0;
		this.bt_ice_2 = this.tools_3_1.bt_ice_2;
		this.myput = this.put_2.myput;
		this.textbnt_1 = this.tools_bnt2.textbnt_1;
		this.bord_7 = this.فيديوهات.bord_7;
		this.bord_6 = this.روابط_خارجية.bord_6;
		this.bord_5 = this.اختبارات.bord_5;
		this.bord_4 = this.انشطة_تفاعلية.bord_4;
		this.bord_3 = this.الاستنتاج.bord_3;
		this.bord_2 = this.خطوات_التجربة.bord_2;
		this.btnen_1 = this.buttonss.btnen_1;
		this.btnen_2 = this.buttonss.btnen_2;
		this.btnen_3 = this.buttonss.btnen_3;
		this.btnen_4 = this.buttonss.btnen_4;
		this.btnen_5 = this.buttonss.btnen_5;
		this.btnen_6 = this.buttonss.btnen_6;
		this.btnen_7 = this.buttonss.btnen_7;
		this.borden_7 = this.vedio.borden_7;
		this.borden_6 = this.links.borden_6;
		this.borden_5 = this.test.borden_5;
		this.borden_4 = this.active.borden_4;
		this.borden_3 = this.concol.borden_3;
		this.borden_2 = this.steps.borden_2;
		this.borden_1 = this.tools.borden_1;
		this.maemly2 = this.navig_ar.maemly2;
		this.maemly_en = this.navig_en.maemly_en;
		this.maemly2_en = this.navig_en.maemly2_en;
		this.myput_hod = this.put_1.myput_hod;
		this.myput_1 = this.put_1.myput_1;
		this.term_point = this.put_1.term_point;
		this.settng = this.Layer_2.settng;
		this.yy = this.back_color.yy;
		var frequency = 3;
		stage.enableMouseOver(frequency);
		
		var root = this;
		var tx = -900;
		var ty = 0;
		var tz = -10;
		var zoomPercent = 90;
		var ttx = -3;
		var tty = -3;
		var ttz = 0;
		var tzoomPercent = 105;
		var tttx = 1400;
		var ttty = 2;
		var tttz = 0;
		var ttzoomPercent = 105;
		var cameraObj = AdobeAn.VirtualCamera.getCamera(exportRoot);
		var trx = 10;
		var ltrx = -10;
		var pls = 10;
		var cas = false;
		var rtx = 10;
		var rty = 0;
		var rtz = 0;
		
		var zoomPercent = 100;
		var zoomPercent2 = 100;
		var zoomPercent3 = 130;
		
		
		//	{
		
		//	createjs.Sound.play("sound_4");
		
		//   this.techer_1.gotoAndPlay(1);
		
		//	 }
		/*this.fsbtn.buttonMode = true;	
		 this.fsbtn.addEventListener("mouseover", fl_ClickTofsbtn.bind(this));
		function fl_ClickTofsbtn() {
			this.myhand.visible = false;
		   canvas.style.cursor = "pointer";
		}
		
		this.fsbtn.addEventListener("mouseout", fl_ClickToutfsbtn.bind(this));
		function fl_ClickToutfsbtn() {
			this.myhand.visible = true;
			 canvas.style.cursor = "none";
		
		}
		this.fsbtn.addEventListener("click", toggleFullscreen);
		
		function toggleFullscreen(event) {
		    var element = //document.body;
		
		    if (event instanceof HTMLElement) {
		        element = event;
		    }
		
		    var isFullscreen = //document.webkitIsFullScreen || //document.mozFullScreen || false;
		
		    element.requestFullScreen = element.requestFullScreen || element.webkitRequestFullScreen ||   element.mozRequestFullScreen || element.msRequestFullscreen || function () {
		        return false;
		    };
		    //document.cancelFullScreen = //document.cancelFullScreen || //document.webkitCancelFullScreen ||  //document.mozCancelFullScreen || //document.msExitFullscreen || function () {
		        return false;
		    };
		
		    isFullscreen ? //document.cancelFullScreen() : element.requestFullScreen();
		} */
		
		
		
		/*this.btnpro.addEventListener("click", btnprod.bind(this));
		function btnprod() {
			this.proo.visible = false;
			this.btnpro.visible = false;
			createjs.Sound.play("sound_1");
			this.techer_1.gotoAndPlay(10);
			canvas.style.cursor = "none";
		}*/
		
		
		
		/*this.tools.addEventListener("mouseover", fl_ClickToide.bind(this));
		function fl_ClickToide() {
			this.myhand.visible = false;
			canvas.style.cursor = "pointer";
		}
		
		this.tools.addEventListener("mouseout", fl_ClickTout.bind(this));
		function fl_ClickTout() {
			this.myhand.visible = true;
			canvas.style.cursor = "none";
		
		}*/
		
		
		
		
		////////////////////////////////////////////////////////////////////////////////
		// 
		/*this.maemly.addEventListener("mouseover", fl_overTomaemly.bind(this));
				function fl_overTomaemly() {
					this.myhand.visible = false;
					canvas.style.cursor = "pointer";
				
				}
				
				this.maemly.addEventListener("mouseout", fl_outTomaemly.bind(this));
				function fl_outTomaemly() {
					this.myhand.visible = true;
					canvas.style.cursor = "none";
				}*/
		
		
		
		
		
		this.addEventListener("tick", fl_CustomMouseCursor.bind(this));
		function fl_CustomMouseCursor() {
			var p = this.globalToLocal(stage.mouseX, stage.mouseY);
			this.myhand.x = p.x;
			this.myhand.y = p.y;
			// canvas.style.cursor = "none";
		}
		
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		//سحب الادوات
		
		
		// اجراءات التجربة
		
		
		this.hhml_12.addEventListener("mousedown", fl2_ClickToGoTohhml_12.bind(this));
		
		function fl2_ClickToGoTohhml_12(){
			if (this.myhand.currentFrame == 0){
			this.hhml_12.visible = false;
				this.myhand.gotoAndStop(29);
				this.myput_1.visible = true;	
				this.arrow_1.visible = false;
			}
		}
		
		this.myput_1.addEventListener("click", fl2_ClickTo_2.bind(this));
		
		function fl2_ClickTo_2(){
			
			if(this.myhand.currentFrame == 29){
			this.hhml_22.visible = true;
				this.myhand.gotoAndStop(0);
				this.myput_1.visible = false;	
				this.arrow_2.visible = true;
			}
		}
		this.stage.addEventListener("click", fl2_ClickTo_3.bind(this));
		
		function fl2_ClickTo_3(){
			
			if(this.myhand.currentFrame == 29){
			this.hhml_12.visible = true;
				this.myhand.gotoAndStop(0);
				this.myput_1.visible = false;	
			}
		}
		
		////////////////////////////////// step 2 
		
		this.lahb_1.addEventListener("mousedown", lightlhb.bind(this));
		
		function lightlhb(){
			if (this.myhand.currentFrame == 0){
			    this.lahb_1.visible = false;
				this.myhand.gotoAndStop(27);
				this.myput_2.visible = true;	
				this.arrow_2.visible = false;
			}
		}
		
		this.myput_2.addEventListener("click", fl2_ClickTo_m2.bind(this));
		
		function fl2_ClickTo_m2(){
			
			if(this.myhand.currentFrame == 27){
			    this.hhml_22.gotoAndStop(1);
				this.myhand.gotoAndStop(0);
				this.myput_2.visible = false;	
				this.arrow_3.visible = true;
			}
		}
		this.stage.addEventListener("click", mylast1.bind(this));
		
		function mylast1(){
			
			if(this.myhand.currentFrame == 27){
			    this.lahb_1.visible = true;
				this.myhand.gotoAndStop(0);
				this.myput_2.visible = false;	
			}
		}
		////////////////////////////////////// step 3
		this.myhod2.addEventListener("mousedown", catchhod.bind(this));
		
		function catchhod(){
			if (this.myhand.currentFrame == 0){
			    this.myhod2.visible = false;
				this.myhand.gotoAndStop(33);
				this.myput_hod.visible = true;	
				this.arrow_3.visible = false;
			}
		}
		
		this.myput_hod.addEventListener("click", puthodhere.bind(this));
		
		function puthodhere(){
			
			if(this.myhand.currentFrame == 33){
			    this.myhod3.visible = true;
				this.myhand.gotoAndStop(0);
				this.myput_hod.visible = false;	
				this.arrow_4.visible = true;
			}
		}
		this.stage.addEventListener("click", lasthod2.bind(this));
		
		function lasthod2(){
			
			if(this.myhand.currentFrame == 33){
			    this.myhod2.visible = true;
				this.myhand.gotoAndStop(0);
				this.myput_hod.visible = false;	
			}
		}
		
		///////////////////step4
		this.hanfi_1.addEventListener("click", fl2_ClickToGoTohanfi_1.bind(this));
		
			function fl2_ClickToGoTohanfi_1() {
					this.hanfi_1.play();
		
				if (this.myhod3.visible == true && this.myhod3.currentFrame < 43) {
		          this.myhod3.play();
				  this.arrow_5.visible = true;
		}
		if (this.hanfi_1.currentFrame == 1){
				
					this.myhod3.stop();
			        this.arrow_4.visible = false;
				
				}
				
				
			}
		
		////////////////////////////// step 5
		this.myhod3.addEventListener("mousedown", fl2_ClickToGoTo3.bind(this));
		
		function fl2_ClickToGoTo3(){
			if(this.myhand.currentFrame == 0  && this.myhod3.currentFrame > 0   ){
			  this.myhod3.visible = false;
				this.myhand.gotoAndStop(36);
				this.myput_3.visible = true;	
				this.arrow_5.visible = false;
			}
		}
		
		this.myput_3.addEventListener("click", fl2_ClickTomyput_3.bind(this));
		
		function fl2_ClickTomyput_3(){
			
			if(this.myhand.currentFrame == 36){
			   this.hhml_22.gotoAndStop(2);
				this.myhand.gotoAndStop(0);
				this.myput_3.visible = false;	
				this.arrow_6.visible = true;
			}
		}
		this.stage.addEventListener("click", fl2_ClickTo_hod_43.bind(this));
		
		function fl2_ClickTo_hod_43(){
			
			if(this.myhand.currentFrame == 36){
		        this.myhod3.visible = true;
				this.myhod3.gotoAndStop(15);
				this.myhand.gotoAndStop(0);
				this.myput_3.visible = false;	
			}
		}
		
		///////////////////////////////////// step 6
		this.becker_2.addEventListener("mousedown", fl2_ClickTobecker_332.bind(this));
		
		function fl2_ClickTobecker_332(){
			if(this.myhand.currentFrame == 0 ){
			    this.becker_2.visible = false;
				this.myhand.gotoAndStop(23);
				this.myput_4.visible = true;	
				this.arrow_6.visible = false;
			}
		}
		
		this.myput_4.addEventListener("click", fl2_ClickTomyput_443.bind(this));
		
		function fl2_ClickTomyput_443(){
			
			if (this.myhand.currentFrame == 23){
			    this.hhml_22.gotoAndStop(3);
				this.myhand.gotoAndStop(0);
				this.myput_4.visible = false;	
				this.arrow_7.visible = true;
			}
		}
		this.stage.addEventListener("click", fl2_ClickTo_hod_4g3.bind(this));
		
		function fl2_ClickTo_hod_4g3(){
			
			if(this.myhand.currentFrame ==23){
		        this.becker_2.visible = true;
			 
				this.myhand.gotoAndStop(0);
				this.myput_4.visible = false;	
			}
		}
			///////////////////////////////step 7
		
		this.bt_ice_2.addEventListener("mousedown", fl2_ClickTobt_ice_2.bind(this));
		
		function fl2_ClickTobt_ice_2(){
			if(this.myhand.currentFrame == 0 ){
			    this.bt_ice_2.visible = false;
				this.myhand.gotoAndStop(2);
				this.myput_5.visible = true;	
				this.arrow_7.visible = false;
			}
		}
		
		this.myput_5.addEventListener("click", fl2_ClickTomyput_55.bind(this));
		
		function fl2_ClickTomyput_55(){
			
			if(this.myhand.currentFrame == 2){
			   this.hhml_22.gotoAndPlay(4);		
			   this.myput_5.visible = false;	
			   
			}
		}
		this.stage.addEventListener("click", fl2_ClickTo_hod_4g83.bind(this));
		
		function fl2_ClickTo_hod_4g83(){
			
			if(this.myhand.currentFrame ==2){
		        this.bt_ice_2.visible = false;	 
				this.myhand.gotoAndStop(0);
				this.myput_5.visible = false;	
			}
		}
		
		this.stage.addEventListener("click", putice1.bind(this));
		
		function putice1(){
			
			if(this.myhand.currentFrame ==37){
		        this.emptyice.visible = true;	 
				this.myhand.gotoAndStop(0);
				this.myput_4.visible = false;	
			}
		}
		
		
		
		this.term_0.addEventListener("mousedown", holdterm.bind(this));
		
		function holdterm(){
			if(this.myhand.currentFrame == 0 ){
			    this.term_0.visible = false;
				this.myhand.gotoAndStop(40);
				this.term_point.visible = true;
		
			}
		}
		
		this.term_point.addEventListener("click", putterm.bind(this));
		
		function putterm(){
			
			if(this.myhand.currentFrame == 40){
			   this.hhml_22.gotoAndStop(10);		
			   this.term_point.visible = false;	
			   
			}
		}
		this.stage.addEventListener("click", finalterm.bind(this));
		
		function finalterm(){
			
			if(this.myhand.currentFrame ==40){
		        this.term_0.visible = false;	 
				this.myhand.gotoAndStop(0);
		
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Camera
	this.___camera___instance = new lib.___Camera___();
	this.___camera___instance.name = "___camera___instance";
	this.___camera___instance.parent = this;
	this.___camera___instance.setTransform(669.8,400);
	this.___camera___instance.depth = 0;
	this.___camera___instance.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.___camera___instance).wait(1));

	// Layer_7_obj_
	this.Layer_7 = new lib.Scene_1_Layer_7();
	this.Layer_7.name = "Layer_7";
	this.Layer_7.parent = this;
	this.Layer_7.setTransform(787.8,404.9,1,1,0,0,0,787.8,404.9);
	this.Layer_7.depth = 0;
	this.Layer_7.isAttachedToCamera = 1
	this.Layer_7.isAttachedToMask = 0
	this.Layer_7.layerDepth = 0
	this.Layer_7.layerIndex = 0
	this.Layer_7.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_7).wait(1));

	// setting_En_obj_
	this.setting_En = new lib.Scene_1_setting_En();
	this.setting_En.name = "setting_En";
	this.setting_En.parent = this;
	this.setting_En.setTransform(517.3,235.9,1,1,0,0,0,517.3,235.9);
	this.setting_En.depth = -100;
	this.setting_En.isAttachedToCamera = 1
	this.setting_En.isAttachedToMask = 0
	this.setting_En.layerDepth = 0
	this.setting_En.layerIndex = 1
	this.setting_En.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.setting_En).wait(1));

	// setting_ar_obj_
	this.setting_ar = new lib.Scene_1_setting_ar();
	this.setting_ar.name = "setting_ar";
	this.setting_ar.parent = this;
	this.setting_ar.setTransform(517.3,235.9,1,1,0,0,0,517.3,235.9);
	this.setting_ar.depth = -100;
	this.setting_ar.isAttachedToCamera = 1
	this.setting_ar.isAttachedToMask = 0
	this.setting_ar.layerDepth = 0
	this.setting_ar.layerIndex = 2
	this.setting_ar.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.setting_ar).wait(1));

	// introd_En_obj_
	this.introd_En = new lib.Scene_1_introd_En();
	this.introd_En.name = "introd_En";
	this.introd_En.parent = this;
	this.introd_En.setTransform(517.3,235.9,1,1,0,0,0,517.3,235.9);
	this.introd_En.depth = -100;
	this.introd_En.isAttachedToCamera = 1
	this.introd_En.isAttachedToMask = 0
	this.introd_En.layerDepth = 0
	this.introd_En.layerIndex = 3
	this.introd_En.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.introd_En).wait(1));

	// introd_obj_
	this.introd = new lib.Scene_1_introd();
	this.introd.name = "introd";
	this.introd.parent = this;
	this.introd.setTransform(517.3,235.9,1,1,0,0,0,517.3,235.9);
	this.introd.depth = -100;
	this.introd.isAttachedToCamera = 1
	this.introd.isAttachedToMask = 0
	this.introd.layerDepth = 0
	this.introd.layerIndex = 4
	this.introd.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.introd).wait(1));

	// Layer_3_obj_
	this.Layer_3 = new lib.Scene_1_Layer_3();
	this.Layer_3.name = "Layer_3";
	this.Layer_3.parent = this;
	this.Layer_3.setTransform(1083.7,641.6,1,1,0,0,0,1083.7,641.6);
	this.Layer_3.depth = -100;
	this.Layer_3.isAttachedToCamera = 1
	this.Layer_3.isAttachedToMask = 0
	this.Layer_3.layerDepth = 0
	this.Layer_3.layerIndex = 5
	this.Layer_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_3).wait(1));

	// tools_hagb_obj_
	this.tools_hagb = new lib.Scene_1_tools_hagb();
	this.tools_hagb.name = "tools_hagb";
	this.tools_hagb.parent = this;
	this.tools_hagb.setTransform(1655,365,1,1,0,0,0,1655,365);
	this.tools_hagb.depth = 0;
	this.tools_hagb.isAttachedToCamera = 0
	this.tools_hagb.isAttachedToMask = 0
	this.tools_hagb.layerDepth = 0
	this.tools_hagb.layerIndex = 6
	this.tools_hagb.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.tools_hagb).wait(1));

	// Layer_15_obj_
	this.Layer_15 = new lib.Scene_1_Layer_15();
	this.Layer_15.name = "Layer_15";
	this.Layer_15.parent = this;
	this.Layer_15.setTransform(631.5,465.4,1,1,0,0,0,631.5,465.4);
	this.Layer_15.depth = 0;
	this.Layer_15.isAttachedToCamera = 0
	this.Layer_15.isAttachedToMask = 0
	this.Layer_15.layerDepth = 0
	this.Layer_15.layerIndex = 7
	this.Layer_15.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_15).wait(1));

	// tools_3_obj_
	this.tools_3 = new lib.Scene_1_tools_3();
	this.tools_3.name = "tools_3";
	this.tools_3.parent = this;
	this.tools_3.setTransform(757.9,342.7,1,1,0,0,0,757.9,342.7);
	this.tools_3.depth = 0;
	this.tools_3.isAttachedToCamera = 0
	this.tools_3.isAttachedToMask = 0
	this.tools_3.layerDepth = 0
	this.tools_3.layerIndex = 8
	this.tools_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.tools_3).wait(1));

	// hanfia_obj_
	this.hanfia = new lib.Scene_1_hanfia();
	this.hanfia.name = "hanfia";
	this.hanfia.parent = this;
	this.hanfia.setTransform(276.4,495.1,1,1,0,0,0,276.4,495.1);
	this.hanfia.depth = 0;
	this.hanfia.isAttachedToCamera = 0
	this.hanfia.isAttachedToMask = 0
	this.hanfia.layerDepth = 0
	this.hanfia.layerIndex = 9
	this.hanfia.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.hanfia).wait(1));

	// tools_3_obj_
	this.tools_3_1 = new lib.Scene_1_tools_3_1();
	this.tools_3_1.name = "tools_3_1";
	this.tools_3_1.parent = this;
	this.tools_3_1.setTransform(943.2,518.6,1,1,0,0,0,943.2,518.6);
	this.tools_3_1.depth = 0;
	this.tools_3_1.isAttachedToCamera = 0
	this.tools_3_1.isAttachedToMask = 0
	this.tools_3_1.layerDepth = 0
	this.tools_3_1.layerIndex = 10
	this.tools_3_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.tools_3_1).wait(1));

	// put_2_obj_
	this.put_2 = new lib.Scene_1_put_2();
	this.put_2.name = "put_2";
	this.put_2.parent = this;
	this.put_2.setTransform(952.1,530.7,1,1,0,0,0,952.1,530.7);
	this.put_2.depth = 0;
	this.put_2.isAttachedToCamera = 0
	this.put_2.isAttachedToMask = 0
	this.put_2.layerDepth = 0
	this.put_2.layerIndex = 11
	this.put_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.put_2).wait(1));

	// tools_bnt2_obj_
	this.tools_bnt2 = new lib.Scene_1_tools_bnt2();
	this.tools_bnt2.name = "tools_bnt2";
	this.tools_bnt2.parent = this;
	this.tools_bnt2.setTransform(1682.7,703.9,1,1,0,0,0,1682.7,703.9);
	this.tools_bnt2.depth = 0;
	this.tools_bnt2.isAttachedToCamera = 0
	this.tools_bnt2.isAttachedToMask = 0
	this.tools_bnt2.layerDepth = 0
	this.tools_bnt2.layerIndex = 12
	this.tools_bnt2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.tools_bnt2).wait(1));

	// فيديوهات_obj_
	this.فيديوهات = new lib.Scene_1_فيديوهات();
	this.فيديوهات.name = "فيديوهات";
	this.فيديوهات.parent = this;
	this.فيديوهات.setTransform(-397.9,138.8,1,1,0,0,0,-397.9,138.8);
	this.فيديوهات.depth = 0;
	this.فيديوهات.isAttachedToCamera = 0
	this.فيديوهات.isAttachedToMask = 0
	this.فيديوهات.layerDepth = 0
	this.فيديوهات.layerIndex = 13
	this.فيديوهات.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.فيديوهات).wait(1));

	// روابط_خارجية_obj_
	this.روابط_خارجية = new lib.Scene_1_روابط_خارجية();
	this.روابط_خارجية.name = "روابط_خارجية";
	this.روابط_خارجية.parent = this;
	this.روابط_خارجية.setTransform(-296.2,200,1,1,0,0,0,-296.2,200);
	this.روابط_خارجية.depth = 0;
	this.روابط_خارجية.isAttachedToCamera = 0
	this.روابط_خارجية.isAttachedToMask = 0
	this.روابط_خارجية.layerDepth = 0
	this.روابط_خارجية.layerIndex = 14
	this.روابط_خارجية.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.روابط_خارجية).wait(1));

	// اختبارات_obj_
	this.اختبارات = new lib.Scene_1_اختبارات();
	this.اختبارات.name = "اختبارات";
	this.اختبارات.parent = this;
	this.اختبارات.setTransform(-296.2,200,1,1,0,0,0,-296.2,200);
	this.اختبارات.depth = 0;
	this.اختبارات.isAttachedToCamera = 0
	this.اختبارات.isAttachedToMask = 0
	this.اختبارات.layerDepth = 0
	this.اختبارات.layerIndex = 15
	this.اختبارات.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.اختبارات).wait(1));

	// انشطة_تفاعلية_obj_
	this.انشطة_تفاعلية = new lib.Scene_1_انشطة_تفاعلية();
	this.انشطة_تفاعلية.name = "انشطة_تفاعلية";
	this.انشطة_تفاعلية.parent = this;
	this.انشطة_تفاعلية.setTransform(-296.2,200,1,1,0,0,0,-296.2,200);
	this.انشطة_تفاعلية.depth = 0;
	this.انشطة_تفاعلية.isAttachedToCamera = 0
	this.انشطة_تفاعلية.isAttachedToMask = 0
	this.انشطة_تفاعلية.layerDepth = 0
	this.انشطة_تفاعلية.layerIndex = 16
	this.انشطة_تفاعلية.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.انشطة_تفاعلية).wait(1));

	// الاستنتاج_obj_
	this.الاستنتاج = new lib.Scene_1_الاستنتاج();
	this.الاستنتاج.name = "الاستنتاج";
	this.الاستنتاج.parent = this;
	this.الاستنتاج.setTransform(-398.4,138.5,1,1,0,0,0,-398.4,138.5);
	this.الاستنتاج.depth = 0;
	this.الاستنتاج.isAttachedToCamera = 0
	this.الاستنتاج.isAttachedToMask = 0
	this.الاستنتاج.layerDepth = 0
	this.الاستنتاج.layerIndex = 17
	this.الاستنتاج.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.الاستنتاج).wait(1));

	// خطوات_التجربة_obj_
	this.خطوات_التجربة = new lib.Scene_1_خطوات_التجربة();
	this.خطوات_التجربة.name = "خطوات_التجربة";
	this.خطوات_التجربة.parent = this;
	this.خطوات_التجربة.setTransform(-397.9,138.8,1,1,0,0,0,-397.9,138.8);
	this.خطوات_التجربة.depth = 0;
	this.خطوات_التجربة.isAttachedToCamera = 0
	this.خطوات_التجربة.isAttachedToMask = 0
	this.خطوات_التجربة.layerDepth = 0
	this.خطوات_التجربة.layerIndex = 18
	this.خطوات_التجربة.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.خطوات_التجربة).wait(1));

	// buttonss_obj_
	this.buttonss = new lib.Scene_1_buttonss();
	this.buttonss.name = "buttonss";
	this.buttonss.parent = this;
	this.buttonss.setTransform(-580.4,308.9,1,1,0,0,0,-580.4,308.9);
	this.buttonss.depth = 0;
	this.buttonss.isAttachedToCamera = 0
	this.buttonss.isAttachedToMask = 0
	this.buttonss.layerDepth = 0
	this.buttonss.layerIndex = 19
	this.buttonss.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.buttonss).wait(1));

	// vedio_obj_
	this.vedio = new lib.Scene_1_vedio();
	this.vedio.name = "vedio";
	this.vedio.parent = this;
	this.vedio.setTransform(-296.2,200,1,1,0,0,0,-296.2,200);
	this.vedio.depth = 0;
	this.vedio.isAttachedToCamera = 0
	this.vedio.isAttachedToMask = 0
	this.vedio.layerDepth = 0
	this.vedio.layerIndex = 20
	this.vedio.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.vedio).wait(1));

	// links_obj_
	this.links = new lib.Scene_1_links();
	this.links.name = "links";
	this.links.parent = this;
	this.links.setTransform(-296.2,200,1,1,0,0,0,-296.2,200);
	this.links.depth = 0;
	this.links.isAttachedToCamera = 0
	this.links.isAttachedToMask = 0
	this.links.layerDepth = 0
	this.links.layerIndex = 21
	this.links.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.links).wait(1));

	// test_obj_
	this.test = new lib.Scene_1_test();
	this.test.name = "test";
	this.test.parent = this;
	this.test.setTransform(-296.2,200,1,1,0,0,0,-296.2,200);
	this.test.depth = 0;
	this.test.isAttachedToCamera = 0
	this.test.isAttachedToMask = 0
	this.test.layerDepth = 0
	this.test.layerIndex = 22
	this.test.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.test).wait(1));

	// active_obj_
	this.active = new lib.Scene_1_active();
	this.active.name = "active";
	this.active.parent = this;
	this.active.setTransform(-296.2,200,1,1,0,0,0,-296.2,200);
	this.active.depth = 0;
	this.active.isAttachedToCamera = 0
	this.active.isAttachedToMask = 0
	this.active.layerDepth = 0
	this.active.layerIndex = 23
	this.active.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.active).wait(1));

	// concol_obj_
	this.concol = new lib.Scene_1_concol();
	this.concol.name = "concol";
	this.concol.parent = this;
	this.concol.setTransform(-398.4,138.5,1,1,0,0,0,-398.4,138.5);
	this.concol.depth = 0;
	this.concol.isAttachedToCamera = 0
	this.concol.isAttachedToMask = 0
	this.concol.layerDepth = 0
	this.concol.layerIndex = 24
	this.concol.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.concol).wait(1));

	// steps_obj_
	this.steps = new lib.Scene_1_steps();
	this.steps.name = "steps";
	this.steps.parent = this;
	this.steps.setTransform(-397.9,138.8,1,1,0,0,0,-397.9,138.8);
	this.steps.depth = 0;
	this.steps.isAttachedToCamera = 0
	this.steps.isAttachedToMask = 0
	this.steps.layerDepth = 0
	this.steps.layerIndex = 25
	this.steps.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.steps).wait(1));

	// tools_obj_
	this.tools = new lib.Scene_1_tools();
	this.tools.name = "tools";
	this.tools.parent = this;
	this.tools.setTransform(-238.3,317.2,1,1,0,0,0,-238.3,317.2);
	this.tools.depth = 0;
	this.tools.isAttachedToCamera = 0
	this.tools.isAttachedToMask = 0
	this.tools.layerDepth = 0
	this.tools.layerIndex = 26
	this.tools.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.tools).wait(1));

	// sabora_tol_obj_
	this.sabora_tol = new lib.Scene_1_sabora_tol();
	this.sabora_tol.name = "sabora_tol";
	this.sabora_tol.parent = this;
	this.sabora_tol.setTransform(-316.1,523.1,1,1,0,0,0,-316.1,523.1);
	this.sabora_tol.depth = 0;
	this.sabora_tol.isAttachedToCamera = 0
	this.sabora_tol.isAttachedToMask = 0
	this.sabora_tol.layerDepth = 0
	this.sabora_tol.layerIndex = 27
	this.sabora_tol.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.sabora_tol).wait(1));

	// navig_ar_obj_
	this.navig_ar = new lib.Scene_1_navig_ar();
	this.navig_ar.name = "navig_ar";
	this.navig_ar.parent = this;
	this.navig_ar.setTransform(69.3,128.7,1,1,0,0,0,69.3,128.7);
	this.navig_ar.depth = 0;
	this.navig_ar.isAttachedToCamera = 0
	this.navig_ar.isAttachedToMask = 0
	this.navig_ar.layerDepth = 0
	this.navig_ar.layerIndex = 28
	this.navig_ar.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.navig_ar).wait(1));

	// navig_en_obj_
	this.navig_en = new lib.Scene_1_navig_en();
	this.navig_en.name = "navig_en";
	this.navig_en.parent = this;
	this.navig_en.setTransform(560.3,135.1,1,1,0,0,0,560.3,135.1);
	this.navig_en.depth = 0;
	this.navig_en.isAttachedToCamera = 0
	this.navig_en.isAttachedToMask = 0
	this.navig_en.layerDepth = 0
	this.navig_en.layerIndex = 29
	this.navig_en.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.navig_en).wait(1));

	// put_1_obj_
	this.put_1 = new lib.Scene_1_put_1();
	this.put_1.name = "put_1";
	this.put_1.parent = this;
	this.put_1.setTransform(492.3,537,1,1,0,0,0,492.3,537);
	this.put_1.depth = 0;
	this.put_1.isAttachedToCamera = 0
	this.put_1.isAttachedToMask = 0
	this.put_1.layerDepth = 0
	this.put_1.layerIndex = 30
	this.put_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.put_1).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.Scene_1_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(1045.5,-32.9,1,1,0,0,0,1045.5,-32.9);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 31
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(1));

	// back_color_obj_
	this.back_color = new lib.Scene_1_back_color();
	this.back_color.name = "back_color";
	this.back_color.parent = this;
	this.back_color.setTransform(90.3,71.1,1,1,0,0,0,90.3,71.1);
	this.back_color.depth = 0;
	this.back_color.isAttachedToCamera = 0
	this.back_color.isAttachedToMask = 0
	this.back_color.layerDepth = 0
	this.back_color.layerIndex = 32
	this.back_color.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.back_color).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.2,344.7,2797.3,856.3);
// library properties:
lib.properties = {
	id: '4F448B9DCA1C3C4C9B1569A019AA38C5',
	width: 1300,
	height: 800,
	fps: 24,
	color: "#BABABA",
	opacity: 1.00,
	manifest: [
		{src:"images/RECOVER_RECOVER_exper_1_1_5_atlas_.png?1591190143395", id:"RECOVER_RECOVER_exper_1_1_5_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['4F448B9DCA1C3C4C9B1569A019AA38C5'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Virtual camera API : 

AdobeAn.VirtualCamera = new function() {
	var _camera = new Object();
	function VirtualCamera(timeline) {
	this.timeline = timeline;
	this.camera = timeline.___camera___instance;
	this.centerX = lib.properties.width / 2;
	this.centerY = lib.properties.height / 2;
	this.camAxisX = this.camera.x;
	this.camAxisY = this.camera.y;
	if(timeline.___camera___instance == null || timeline.___camera___instance == undefined )
	{
		timeline.___camera___instance = new cjs.MovieClip();
		timeline.___camera___instance.visible = false;
		timeline.___camera___instance.parent = timeline;
		timeline.___camera___instance.setTransform(this.centerX, this.centerY);
	}
	this.camera = timeline.___camera___instance;
}

VirtualCamera.prototype.moveBy = function(x, y, z) {
z = typeof z !== 'undefined' ? z : 0;
	var position = this.___getCamPosition___();
	var rotAngle = this.getRotation()*Math.PI/180;
	var sinTheta = Math.sin(rotAngle);
	var cosTheta = Math.cos(rotAngle);
	var offX= x*cosTheta + y*sinTheta;
	var offY = y*cosTheta - x*sinTheta;
	this.camAxisX = this.camAxisX - x;
	this.camAxisY = this.camAxisY - y;
	var posX = position.x + offX;
	var posY = position.y + offY;
	this.camera.x = this.centerX - posX;
	this.camera.y = this.centerY - posY;
	this.camera.depth += z;
};

VirtualCamera.prototype.setPosition = function(x, y, z) {
	z = typeof z !== 'undefined' ? z : 0;

	const MAX_X = 10000;
	const MIN_X = -10000;
	const MAX_Y = 10000;
	const MIN_Y = -10000;
	const MAX_Z = 10000;
	const MIN_Z = -5000;

	if(x > MAX_X)
	  x = MAX_X;
	else if(x < MIN_X)
	  x = MIN_X;
	if(y > MAX_Y)
	  y = MAX_Y;
	else if(y < MIN_Y)
	  y = MIN_Y;
	if(z > MAX_Z)
	  z = MAX_Z;
	else if(z < MIN_Z)
	  z = MIN_Z;

	var rotAngle = this.getRotation()*Math.PI/180;
	var sinTheta = Math.sin(rotAngle);
	var cosTheta = Math.cos(rotAngle);
	var offX= x*cosTheta + y*sinTheta;
	var offY = y*cosTheta - x*sinTheta;
	
	this.camAxisX = this.centerX - x;
	this.camAxisY = this.centerY - y;
	this.camera.x = this.centerX - offX;
	this.camera.y = this.centerY - offY;
	this.camera.depth = z;
};

VirtualCamera.prototype.getPosition = function() {
	var loc = new Object();
	loc['x'] = this.centerX - this.camAxisX;
	loc['y'] = this.centerY - this.camAxisY;
	loc['z'] = this.camera.depth;
	return loc;
};

VirtualCamera.prototype.resetPosition = function() {
	this.setPosition(0, 0);
};

VirtualCamera.prototype.zoomBy = function(zoom) {
	this.setZoom( (this.getZoom() * zoom) / 100);
};

VirtualCamera.prototype.setZoom = function(zoom) {
	const MAX_zoom = 10000;
	const MIN_zoom = 1;
	if(zoom > MAX_zoom)
	zoom = MAX_zoom;
	else if(zoom < MIN_zoom)
	zoom = MIN_zoom;
	this.camera.scaleX = 100 / zoom;
	this.camera.scaleY = 100 / zoom;
};

VirtualCamera.prototype.getZoom = function() {
	return 100 / this.camera.scaleX;
};

VirtualCamera.prototype.resetZoom = function() {
	this.setZoom(100);
};

VirtualCamera.prototype.rotateBy = function(angle) {
	this.setRotation( this.getRotation() + angle );
};

VirtualCamera.prototype.setRotation = function(angle) {
	const MAX_angle = 180;
	const MIN_angle = -179;
	if(angle > MAX_angle)
		angle = MAX_angle;
	else if(angle < MIN_angle)
		angle = MIN_angle;
	this.camera.rotation = -angle;
};

VirtualCamera.prototype.getRotation = function() {
	return -this.camera.rotation;
};

VirtualCamera.prototype.resetRotation = function() {
this.setRotation(0);
};

VirtualCamera.prototype.reset = function() {
	this.resetPosition();
	this.resetZoom();
	this.resetRotation();
	this.unpinCamera();
};
VirtualCamera.prototype.setZDepth = function(zDepth) {
	const MAX_zDepth = 10000;
	const MIN_zDepth = -5000;
	if(zDepth > MAX_zDepth)
		zDepth = MAX_zDepth;
	else if(zDepth < MIN_zDepth)
		zDepth = MIN_zDepth;
	this.camera.depth = zDepth;
}
VirtualCamera.prototype.getZDepth = function() {
	return this.camera.depth;
}
VirtualCamera.prototype.resetZDepth = function() {
	this.camera.depth = 0;
}

VirtualCamera.prototype.pinCameraToObject = function(obj, offsetX, offsetY, offsetZ) {

	offsetX = typeof offsetX !== 'undefined' ? offsetX : 0;

	offsetY = typeof offsetY !== 'undefined' ? offsetY : 0;

	offsetZ = typeof offsetZ !== 'undefined' ? offsetZ : 0;
	if(obj === undefined)
		return;
	this.camera.pinToObject = obj;
	this.camera.pinToObject.pinOffsetX = offsetX;
	this.camera.pinToObject.pinOffsetY = offsetY;
	this.camera.pinToObject.pinOffsetZ = offsetZ;
};

VirtualCamera.prototype.setPinOffset = function(offsetX, offsetY, offsetZ) {
if(this.camera.pinToObject != undefined) {
this.camera.pinToObject.pinOffsetX = offsetX;
this.camera.pinToObject.pinOffsetY = offsetY;
this.camera.pinToObject.pinOffsetZ = offsetZ;
}
};

VirtualCamera.prototype.unpinCamera = function() {
this.camera.pinToObject = undefined;
};

this.getCamera = function(timeline) {
	timeline = typeof timeline !== 'undefined' ? timeline : null;
	if(timeline === null) timeline = exportRoot;
	if(_camera[timeline] == undefined)
	_camera[timeline] = new VirtualCamera(timeline);
	return _camera[timeline];
}

this.getCameraAsMovieClip = function(timeline) {
	timeline = typeof timeline !== 'undefined' ? timeline : null;
	if(timeline === null) timeline = exportRoot;
	return this.getCamera(timeline).camera;
}
VirtualCamera.prototype.___getCamPosition___ = function() {
	var loc = new Object();
	loc['x'] = this.centerX - this.camera.x;
	loc['y'] = this.centerY - this.camera.y;
	loc['z'] = this.depth;
	return loc;
};
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;